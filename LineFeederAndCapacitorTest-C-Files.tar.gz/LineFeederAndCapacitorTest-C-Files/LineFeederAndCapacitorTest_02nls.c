/* Non Linear Systems */
#include "LineFeederAndCapacitorTest_model.h"
#include "LineFeederAndCapacitorTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

/*
 equation index: 15
 type: SIMPLE_ASSIGN
 loa2._v[2] = line1.line.line.i_p[1] * line1.line.line.L * loa1.omega + gri.terminal.v[2]
 */
void LineFeederAndCapacitorTest_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */ = (data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */)) + data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
  TRACE_POP
}
/*
 equation index: 16
 type: SIMPLE_ASSIGN
 loa1._i[2] = -homotopy(DIVISION(loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */)),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 17
 type: SIMPLE_ASSIGN
 loa._i[1] = -homotopy(loa2.v[1] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_17(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,17};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */ = (-homotopy((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 18
 type: SIMPLE_ASSIGN
 loa3._i[1] = -homotopy(DIVISION(loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_18(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,18};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 19
 type: SIMPLE_ASSIGN
 loa._i[2] = -homotopy(loa2.v[2] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_19(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,19};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */ = (-homotopy((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 20
 type: SIMPLE_ASSIGN
 loa1._i[1] = -homotopy(DIVISION(loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 21
 type: SIMPLE_ASSIGN
 loa2._i[1] = -homotopy(loa2.v[1] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */ = (-homotopy((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 22
 type: SIMPLE_ASSIGN
 loa2._i[2] = -homotopy(loa2.v[2] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */ = (-homotopy((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 23
 type: SIMPLE_ASSIGN
 loa3._i[2] = -homotopy(DIVISION(loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */)),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 24
 type: SIMPLE_ASSIGN
 line1._line._line._i_p[2] = (-loa.i[2]) - loa1.i[2] - loa2.i[2] - loa3.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */ = (-data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */) - data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */ - data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */ - data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */;
  TRACE_POP
}

void residualFunc27(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,27};
  /* iteration variables */
  data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */ = xloc[0];
  data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */ = xloc[1];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_15(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_16(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_17(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_18(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_19(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_20(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_21(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_22(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_23(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_24(data, threadData);
  /* body */
  res[0] = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */ + (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */)) - data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;

  res[1] = data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */ + data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */ + data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */ + data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */ + data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */;
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS27(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+2] = {0,2,2};
  const int rowIndex[4] = {0,1,0,1};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((2+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(4*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 4;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(2*sizeof(int));
  inSysData->sparsePattern.maxColors = 2;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (2+1)*sizeof(int));
  
  for(i=2;i<2+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 4*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[1] = 1;
  inSysData->sparsePattern.colorCols[0] = 2;
}
void initializeStaticDataNLS27(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for loa2.v[1] */
  sysData->nominal[i] = data->modelData->realVarsData[61].attribute /* loa2._v[1] */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[61].attribute /* loa2._v[1] */.min;
  sysData->max[i++]   = data->modelData->realVarsData[61].attribute /* loa2._v[1] */.max;
  /* static nls data for line1.line.line.i_p[1] */
  sysData->nominal[i] = data->modelData->realVarsData[32].attribute /* line1._line._line._i_p[1] */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[32].attribute /* line1._line._line._i_p[1] */.min;
  sysData->max[i++]   = data->modelData->realVarsData[32].attribute /* line1._line._line._i_p[1] */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS27(sysData);
}

void getIterationVarsNLS27(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  array[1] = data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */;
}

/* inner equations */

/*
 equation index: 93
 type: SIMPLE_ASSIGN
 loa2._v[1] = gri.terminal.v[1] - line1.line.line.i_p[2] * line1.line.line.L * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_93(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,93};
  data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */ = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */ - ((data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */)));
  TRACE_POP
}
/*
 equation index: 94
 type: SIMPLE_ASSIGN
 loa._i[1] = (-loa2.v[1]) * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_94(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,94};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}
/*
 equation index: 95
 type: SIMPLE_ASSIGN
 loa1._i[1] = DIVISION((-loa2.v[2]) * loa1.Q - loa2.v[1] * loa1.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_95(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,95};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */ = DIVISION_SIM(((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 96
 type: SIMPLE_ASSIGN
 loa._i[2] = (-loa2.v[2]) * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_96(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,96};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */ = ((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}
/*
 equation index: 97
 type: SIMPLE_ASSIGN
 loa1._i[2] = DIVISION(loa2.v[1] * loa1.Q - loa2.v[2] * loa1.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_97(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,97};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */ = DIVISION_SIM((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 98
 type: SIMPLE_ASSIGN
 loa2._i[1] = (-loa2.v[1]) * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_98(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,98};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}
/*
 equation index: 99
 type: SIMPLE_ASSIGN
 loa3._i[1] = DIVISION((-loa2.v[2]) * loa3.Q - loa2.v[1] * loa3.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_99(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,99};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */ = DIVISION_SIM(((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 100
 type: SIMPLE_ASSIGN
 loa2._i[2] = (-loa2.v[2]) * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_100(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,100};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */ = ((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}
/*
 equation index: 101
 type: SIMPLE_ASSIGN
 loa3._i[2] = DIVISION(loa2.v[1] * loa3.Q - loa2.v[2] * loa3.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_101(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,101};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */ = DIVISION_SIM((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])),(tmp0 * tmp0) + (tmp1 * tmp1),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 102
 type: SIMPLE_ASSIGN
 line1._line._line._i_p[1] = (-loa.i[1]) - loa1.i[1] - loa2.i[1] - loa3.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_102(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,102};
  data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */ = (-data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */) - data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */ - data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */ - data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */;
  TRACE_POP
}

void residualFunc117(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,117};
  /* iteration variables */
  data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */ = xloc[0];
  data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */ = xloc[1];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_93(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_94(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_95(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_96(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_97(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_98(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_99(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_100(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_101(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_102(data, threadData);
  /* body */
  res[0] = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */ + (-data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */) - ((data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */)));

  res[1] = data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */ + data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */ + data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */ + data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */ + data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */;
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS117(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+2] = {0,2,2};
  const int rowIndex[4] = {0,1,0,1};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((2+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(4*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 4;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(2*sizeof(int));
  inSysData->sparsePattern.maxColors = 2;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (2+1)*sizeof(int));
  
  for(i=2;i<2+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 4*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[1] = 1;
  inSysData->sparsePattern.colorCols[0] = 2;
}
void initializeStaticDataNLS117(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for loa2.v[2] */
  sysData->nominal[i] = data->modelData->realVarsData[62].attribute /* loa2._v[2] */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[62].attribute /* loa2._v[2] */.min;
  sysData->max[i++]   = data->modelData->realVarsData[62].attribute /* loa2._v[2] */.max;
  /* static nls data for line1.line.line.i_p[2] */
  sysData->nominal[i] = data->modelData->realVarsData[33].attribute /* line1._line._line._i_p[2] */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[33].attribute /* line1._line._line._i_p[2] */.min;
  sysData->max[i++]   = data->modelData->realVarsData[33].attribute /* line1._line._line._i_p[2] */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS117(sysData);
}

void getIterationVarsNLS117(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  array[1] = data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */;
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void LineFeederAndCapacitorTest_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[0].equationIndex = 27;
  nonLinearSystemData[0].size = 2;
  nonLinearSystemData[0].homotopySupport = 0;
  nonLinearSystemData[0].mixedSystem = 0;
  nonLinearSystemData[0].residualFunc = residualFunc27;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = NULL;
  nonLinearSystemData[0].initialAnalyticalJacobian = NULL;
  nonLinearSystemData[0].jacobianIndex = -1;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS27;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS27;
  nonLinearSystemData[0].checkConstraints = NULL;
  
  nonLinearSystemData[1].equationIndex = 117;
  nonLinearSystemData[1].size = 2;
  nonLinearSystemData[1].homotopySupport = 0;
  nonLinearSystemData[1].mixedSystem = 0;
  nonLinearSystemData[1].residualFunc = residualFunc117;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = LineFeederAndCapacitorTest_functionJacNLSJac6_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = LineFeederAndCapacitorTest_initialAnalyticJacobianNLSJac6;
  nonLinearSystemData[1].jacobianIndex = 1;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS117;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS117;
  nonLinearSystemData[1].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

