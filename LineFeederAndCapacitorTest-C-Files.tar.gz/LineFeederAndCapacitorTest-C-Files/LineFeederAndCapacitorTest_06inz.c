/* Initialization */
#include "LineFeederAndCapacitorTest_model.h"
#include "LineFeederAndCapacitorTest_11mix.h"
#include "LineFeederAndCapacitorTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void LineFeederAndCapacitorTest_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 line1._line._line._heatPort._Q_flow = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[31] /* line1._line._line._heatPort._Q_flow variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 feeder2._i[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  data->localData[0]->realVars[19] /* feeder2._i[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 feeder2._i[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[18] /* feeder2._i[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 feeder1._i[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[17] /* feeder1._i[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 5
 type: SIMPLE_ASSIGN
 feeder1._i[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  data->localData[0]->realVars[16] /* feeder1._i[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 6
 type: SIMPLE_ASSIGN
 line1._line._line._R_actual = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[30] /* line1._line._line._R_actual variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 7
 type: SIMPLE_ASSIGN
 gri._sou._thetaRel = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  data->localData[0]->realVars[25] /* gri._sou._thetaRel variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 8
 type: SIMPLE_ASSIGN
 loa1._Q = loa1.P_nominal * tan(acos(loa1.pf))
 */
void LineFeederAndCapacitorTest_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  modelica_real tmp0;
  tmp0 = data->simulationInfo->realParameter[36];
  if(!(tmp0 >= -1.0 && tmp0 <= 1.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of acos(loa1.pf) outside the domain -1.0 <= %g <= 1.0", tmp0);
  }
  data->localData[0]->realVars[42] /* loa1._Q variable */ = (data->simulationInfo->realParameter[34]) * (tan(acos(tmp0)));
  TRACE_POP
}

/*
 equation index: 9
 type: SIMPLE_ASSIGN
 gri._terminal._v[1] = gri.sou.V * cos(gri.sou.phiSou)
 */
void LineFeederAndCapacitorTest_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */ = (data->simulationInfo->realParameter[3]) * (cos(data->simulationInfo->realParameter[5]));
  TRACE_POP
}

/*
 equation index: 10
 type: SIMPLE_ASSIGN
 gri._terminal._v[2] = gri.sou.V * sin(gri.sou.phiSou)
 */
void LineFeederAndCapacitorTest_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */ = (data->simulationInfo->realParameter[3]) * (sin(data->simulationInfo->realParameter[5]));
  TRACE_POP
}

/*
 equation index: 11
 type: SIMPLE_ASSIGN
 loa3._Q = loa3.P_nominal * tan(-acos(loa3.pf))
 */
void LineFeederAndCapacitorTest_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  modelica_real tmp1;
  tmp1 = data->simulationInfo->realParameter[41];
  if(!(tmp1 >= -1.0 && tmp1 <= 1.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of acos(loa3.pf) outside the domain -1.0 <= %g <= 1.0", tmp1);
  }
  data->localData[0]->realVars[65] /* loa3._Q variable */ = (data->simulationInfo->realParameter[39]) * (tan((-acos(tmp1))));
  TRACE_POP
}

/*
 equation index: 12
 type: SIMPLE_ASSIGN
 der(loa1._omega) = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  data->localData[0]->realVars[6] /* der(loa1._omega) DUMMY_DER */ = 0.0;
  TRACE_POP
}

/*
 equation index: 13
 type: SIMPLE_ASSIGN
 loa1._omega = 6.283185307179586 * gri.sou.f
 */
void LineFeederAndCapacitorTest_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */ = (6.283185307179586) * (data->simulationInfo->realParameter[4]);
  TRACE_POP
}

/*
 equation index: 14
 type: SIMPLE_ASSIGN
 der(loa1._theRef) = loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  data->localData[0]->realVars[7] /* der(loa1._theRef) DUMMY_DER */ = data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */;
  TRACE_POP
}

void LineFeederAndCapacitorTest_eqFunction_15(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_16(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_17(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_18(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_19(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_20(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_21(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_22(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_23(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_24(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_26(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_25(DATA*,threadData_t*);
/*
 equation index: 27
 indexNonlinear: 0
 type: NONLINEAR
 
 vars: {loa2._v[1], line1._line._line._i_p[1]}
 eqns: {15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 25}
 */
void LineFeederAndCapacitorTest_eqFunction_27(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,27};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 27 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[1] = data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */;
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,27};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 27 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */ = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */ = data->simulationInfo->nonlinearSystemData[0].nlsx[1];
  TRACE_POP
}

/*
 equation index: 28
 type: SIMPLE_ASSIGN
 gri._sou._phi = atan2(gri.terminal.v[2], gri.terminal.v[1]) - atan2(-line1.line.line.i_p[2], -line1.line.line.i_p[1])
 */
void LineFeederAndCapacitorTest_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,28};
  data->localData[0]->realVars[24] /* gri._sou._phi variable */ = atan2(data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */, data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */) - atan2((-data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */), (-data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 29
 type: SIMPLE_ASSIGN
 gri._P._cosPhi = cos(gri.sou.phi)
 */
void LineFeederAndCapacitorTest_eqFunction_29(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,29};
  data->localData[0]->realVars[21] /* gri._P._cosPhi variable */ = cos(data->localData[0]->realVars[24] /* gri._sou._phi variable */);
  TRACE_POP
}

/*
 equation index: 30
 type: SIMPLE_ASSIGN
 gri._sou._S[2] = gri.terminal.v[2] * line1.line.line.i_p[1] - gri.terminal.v[1] * line1.line.line.i_p[2]
 */
void LineFeederAndCapacitorTest_eqFunction_30(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,30};
  data->localData[0]->realVars[23] /* gri._sou._S[2] variable */ = (data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */) * (data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) - ((data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */) * (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 31
 type: SIMPLE_ASSIGN
 gri._sou._S[1] = gri.terminal.v[1] * line1.line.line.i_p[1] + gri.terminal.v[2] * line1.line.line.i_p[2]
 */
void LineFeederAndCapacitorTest_eqFunction_31(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,31};
  data->localData[0]->realVars[22] /* gri._sou._S[1] variable */ = (data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */) * (data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) + (data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */) * (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */);
  TRACE_POP
}

/*
 equation index: 32
 type: SIMPLE_ASSIGN
 gri._P._apparent = Modelica.Fluid.Utilities.regRoot(gri.sou.S[2] ^ 2.0 + gri.sou.S[1] ^ 2.0, 0.01)
 */
void LineFeederAndCapacitorTest_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[23] /* gri._sou._S[2] variable */;
  tmp1 = data->localData[0]->realVars[22] /* gri._sou._S[1] variable */;
  data->localData[0]->realVars[20] /* gri._P._apparent variable */ = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp0 * tmp0) + (tmp1 * tmp1), 0.01);
  TRACE_POP
}

/*
 equation index: 33
 type: SIMPLE_ASSIGN
 loa3._S[2] = loa2.v[1] * loa3.i[2] - loa2.v[2] * loa3.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  data->localData[0]->realVars[67] /* loa3._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 34
 type: SIMPLE_ASSIGN
 loa3._S[1] = (-loa2.v[1]) * loa3.i[1] - loa2.v[2] * loa3.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  data->localData[0]->realVars[66] /* loa3._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 35
 type: SIMPLE_ASSIGN
 loa2._S[2] = loa2.v[1] * loa2.i[2] - loa2.v[2] * loa2.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  data->localData[0]->realVars[57] /* loa2._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 36
 type: SIMPLE_ASSIGN
 loa2._S[1] = (-loa2.v[1]) * loa2.i[1] - loa2.v[2] * loa2.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  data->localData[0]->realVars[56] /* loa2._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 37
 type: SIMPLE_ASSIGN
 line1._line._VoltageLosses = DIVISION(abs(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)), smooth(1, if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) > 1.0) then Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) else if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) < -1.0) then Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) else 0.25 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) * (-3.0 + (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) ^ 2.0) * (Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05)) + 0.5 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) + Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05))))
 */
void LineFeederAndCapacitorTest_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_boolean tmp10;
  modelica_real tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_boolean tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_boolean tmp37;
  modelica_real tmp38;
  modelica_boolean tmp39;
  modelica_real tmp40;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
  tmp5 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
  tmp6 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp7 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp8 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
  tmp9 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
  tmp10 = Greater(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp6 * tmp6) + (tmp7 * tmp7), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp8 * tmp8) + (tmp9 * tmp9), 1e-05),1.0);
  tmp39 = (modelica_boolean)tmp10;
  if(tmp39)
  {
    tmp11 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
    tmp12 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
    tmp40 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp11 * tmp11) + (tmp12 * tmp12), 1e-05);
  }
  else
  {
    tmp13 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
    tmp14 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
    tmp15 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
    tmp16 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
    tmp17 = Less(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp13 * tmp13) + (tmp14 * tmp14), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp15 * tmp15) + (tmp16 * tmp16), 1e-05),-1.0);
    tmp37 = (modelica_boolean)tmp17;
    if(tmp37)
    {
      tmp18 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp19 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp38 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp18 * tmp18) + (tmp19 * tmp19), 1e-05);
    }
    else
    {
      tmp20 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp21 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp22 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp23 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp24 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp25 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp26 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp27 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp28 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp24 * tmp24) + (tmp25 * tmp25), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp26 * tmp26) + (tmp27 * tmp27), 1e-05);
      tmp29 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp30 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp31 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp32 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp33 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp34 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp35 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp36 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp38 = (0.25) * ((omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp20 * tmp20) + (tmp21 * tmp21), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp22 * tmp22) + (tmp23 * tmp23), 1e-05)) * ((-3.0 + (tmp28 * tmp28)) * (omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp29 * tmp29) + (tmp30 * tmp30), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp31 * tmp31) + (tmp32 * tmp32), 1e-05)))) + (0.5) * (omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp33 * tmp33) + (tmp34 * tmp34), 1e-05) + omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp35 * tmp35) + (tmp36 * tmp36), 1e-05));
    }
    tmp40 = tmp38;
  }
  data->localData[0]->realVars[28] /* line1._line._VoltageLosses variable */ = DIVISION_SIM(fabs(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp2 * tmp2) + (tmp3 * tmp3), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp4 * tmp4) + (tmp5 * tmp5), 1e-05)),tmp40,"smooth(1, if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) > 1.0) then Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) else if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) < -1.0) then Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) else 0.25 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) * (-3.0 + (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) ^ 2.0) * (Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05)) + 0.5 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) + Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)))",equationIndexes);
  TRACE_POP
}

/*
 equation index: 62
 type: LINEAR
 
 <var>der(loa2._v[1])</var>
 <var>der(line1._line._line._i_p[1])</var>
 <row>

 </row>
 <matrix>
 </matrix>
 */
void LineFeederAndCapacitorTest_eqFunction_62(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,62};
  /* Linear equation system */
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving linear system 62 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  data->simulationInfo->linearSystemData[0].x[0] = data->localData[1]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */;
  data->simulationInfo->linearSystemData[0].x[1] = data->localData[1]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */;
  retValue = solve_linear_system(data, threadData, 0);
  
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,62};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving linear system 62 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ = data->simulationInfo->linearSystemData[0].x[0];
  data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ = data->simulationInfo->linearSystemData[0].x[1];
  TRACE_POP
}

/*
 equation index: 63
 type: SIMPLE_ASSIGN
 loa._S[2] = loa2.v[1] * loa.i[2] - loa2.v[2] * loa.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_63(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,63};
  data->localData[0]->realVars[36] /* loa._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 64
 type: SIMPLE_ASSIGN
 loa._S[1] = (-loa2.v[1]) * loa.i[1] - loa2.v[2] * loa.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_64(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,64};
  data->localData[0]->realVars[35] /* loa._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 65
 type: SIMPLE_ASSIGN
 loa1._S[2] = loa2.v[1] * loa1.i[2] - loa2.v[2] * loa1.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_65(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,65};
  data->localData[0]->realVars[44] /* loa1._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 66
 type: SIMPLE_ASSIGN
 loa1._S[1] = (-loa2.v[1]) * loa1.i[1] - loa2.v[2] * loa1.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_66(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,66};
  data->localData[0]->realVars[43] /* loa1._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 67
 type: SIMPLE_ASSIGN
 line1._line._cableTemp._port._Q_flow = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_67(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,67};
  data->localData[0]->realVars[29] /* line1._line._cableTemp._port._Q_flow variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 68
 type: SIMPLE_ASSIGN
 loa3._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_68(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,68};
  data->localData[0]->realVars[72] /* loa3._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 69
 type: SIMPLE_ASSIGN
 loa3._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_69(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,69};
  data->localData[0]->realVars[64] /* loa3._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 70
 type: SIMPLE_ASSIGN
 loa3._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_70(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,70};
  data->localData[0]->realVars[75] /* loa3._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 71
 type: SIMPLE_ASSIGN
 loa3._q[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_71(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,71};
  data->localData[0]->realVars[74] /* loa3._q[2] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 72
 type: SIMPLE_ASSIGN
 loa3._q[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_72(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,72};
  data->localData[0]->realVars[73] /* loa3._q[1] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 73
 type: SIMPLE_ASSIGN
 loa3._Y[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_73(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,73};
  data->localData[0]->realVars[69] /* loa3._Y[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 74
 type: SIMPLE_ASSIGN
 loa3._Y[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_74(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,74};
  data->localData[0]->realVars[68] /* loa3._Y[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 75
 type: SIMPLE_ASSIGN
 loa2._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_75(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,75};
  data->localData[0]->realVars[60] /* loa2._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 76
 type: SIMPLE_ASSIGN
 loa2._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_76(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,76};
  data->localData[0]->realVars[55] /* loa2._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 77
 type: SIMPLE_ASSIGN
 loa2._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_77(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,77};
  data->localData[0]->realVars[63] /* loa2._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 78
 type: SIMPLE_ASSIGN
 loa1._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_78(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,78};
  data->localData[0]->realVars[49] /* loa1._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 79
 type: SIMPLE_ASSIGN
 loa1._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_79(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,79};
  data->localData[0]->realVars[41] /* loa1._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 80
 type: SIMPLE_ASSIGN
 loa1._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_80(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,80};
  data->localData[0]->realVars[54] /* loa1._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 81
 type: SIMPLE_ASSIGN
 loa1._psi[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_81(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,81};
  data->localData[0]->realVars[52] /* loa1._psi[2] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 82
 type: SIMPLE_ASSIGN
 loa1._psi[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_82(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,82};
  data->localData[0]->realVars[51] /* loa1._psi[1] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 83
 type: SIMPLE_ASSIGN
 loa1._Z[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_83(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,83};
  data->localData[0]->realVars[46] /* loa1._Z[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 84
 type: SIMPLE_ASSIGN
 loa1._Z[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_84(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,84};
  data->localData[0]->realVars[45] /* loa1._Z[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 85
 type: SIMPLE_ASSIGN
 loa._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_85(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,85};
  data->localData[0]->realVars[39] /* loa._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 86
 type: SIMPLE_ASSIGN
 loa._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_86(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,86};
  data->localData[0]->realVars[34] /* loa._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 87
 type: SIMPLE_ASSIGN
 loa._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_87(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,87};
  data->localData[0]->realVars[40] /* loa._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 88
 type: SIMPLE_ASSIGN
 loa1._theRef = 6.283185307179586 * gri.sou.f * time
 */
void LineFeederAndCapacitorTest_eqFunction_88(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,88};
  data->localData[0]->realVars[53] /* loa1._theRef DUMMY_STATE */ = (6.283185307179586) * ((data->simulationInfo->realParameter[4]) * (data->localData[0]->timeValue));
  TRACE_POP
}

/*
 equation index: 89
 type: ALGORITHM
 
   assert(line1.line.L >= 0.0, "The parameters R,L,C must be positive. Check cable properties and size.");
 */
void LineFeederAndCapacitorTest_eqFunction_89(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,89};
  modelica_boolean tmp41;
  static const MMC_DEFSTRINGLIT(tmp42,71,"The parameters R,L,C must be positive. Check cable properties and size.");
  static int tmp43 = 0;
  {
    tmp41 = GreaterEq(data->simulationInfo->realParameter[7],0.0);
    if(!tmp41)
    {
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",61,3,61,108,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.L >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_withEquationIndexes(threadData, info, equationIndexes, MMC_STRINGDATA(MMC_REFSTRINGLIT(tmp42)));
      }
    }
  }
  TRACE_POP
}
void LineFeederAndCapacitorTest_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  LineFeederAndCapacitorTest_eqFunction_1(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_2(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_3(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_4(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_5(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_6(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_7(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_8(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_9(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_10(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_11(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_12(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_13(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_14(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_27(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_28(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_29(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_30(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_31(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_32(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_33(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_34(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_35(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_36(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_37(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_62(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_63(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_64(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_65(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_66(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_67(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_68(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_69(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_70(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_71(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_72(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_73(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_74(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_75(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_76(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_77(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_78(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_79(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_80(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_81(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_82(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_83(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_84(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_85(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_86(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_87(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_88(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_89(data, threadData);
  TRACE_POP
}


int LineFeederAndCapacitorTest_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  LineFeederAndCapacitorTest_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

