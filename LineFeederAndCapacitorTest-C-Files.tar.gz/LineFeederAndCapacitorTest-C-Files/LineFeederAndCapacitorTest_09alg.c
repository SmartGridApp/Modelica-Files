/* Algebraic */
#include "LineFeederAndCapacitorTest_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void LineFeederAndCapacitorTest_eqFunction_117(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_118(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_119(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_120(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_121(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_122(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_123(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_124(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_125(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_126(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_127(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_128(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_153(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_154(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_155(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_156(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_157(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_158(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_92(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_91(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_90(DATA* data, threadData_t *threadData);
extern void LineFeederAndCapacitorTest_eqFunction_159(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  LineFeederAndCapacitorTest_eqFunction_117(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_118(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_119(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_120(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_121(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_122(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_123(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_124(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_125(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_126(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_127(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_128(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_153(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_154(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_155(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_156(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_157(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_158(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_92(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_91(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_90(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_159(data, threadData);
}
/* for continuous time variables */
int LineFeederAndCapacitorTest_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  
  data->simulationInfo->callStatistics.functionAlgebraics++;
  
  functionAlg_system0(data, threadData);

  LineFeederAndCapacitorTest_function_savePreSynchronous(data, threadData);
  
  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
