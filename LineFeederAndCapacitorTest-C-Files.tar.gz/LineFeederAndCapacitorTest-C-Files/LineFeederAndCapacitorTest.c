/* Main Simulation File */
#include "LineFeederAndCapacitorTest_model.h"

#define prefixedName_performSimulation LineFeederAndCapacitorTest_performSimulation
#define prefixedName_updateContinuousSystem LineFeederAndCapacitorTest_updateContinuousSystem
#include <simulation/solver/perform_simulation.c>

#define prefixedName_performQSSSimulation LineFeederAndCapacitorTest_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c>

/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int LineFeederAndCapacitorTest_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
 equation index: 90
 type: SIMPLE_ASSIGN
 loa1._omega = 6.283185307179586 * gri.sou.f
 */
void LineFeederAndCapacitorTest_eqFunction_90(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,90};
  data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */ = (6.283185307179586) * (data->simulationInfo->realParameter[4]);
  TRACE_POP
}
/*
 equation index: 91
 type: SIMPLE_ASSIGN
 der(loa1._omega) = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_91(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,91};
  data->localData[0]->realVars[6] /* der(loa1._omega) DUMMY_DER */ = 0.0;
  TRACE_POP
}
/*
 equation index: 92
 type: SIMPLE_ASSIGN
 der(loa1._theRef) = loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_92(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,92};
  data->localData[0]->realVars[7] /* der(loa1._theRef) DUMMY_DER */ = data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */;
  TRACE_POP
}
void LineFeederAndCapacitorTest_eqFunction_93(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_94(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_95(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_96(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_97(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_98(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_99(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_100(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_101(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_102(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_104(DATA*,threadData_t*);
void LineFeederAndCapacitorTest_eqFunction_103(DATA*,threadData_t*);
/*
 equation index: 117
 indexNonlinear: 1
 type: NONLINEAR
 
 vars: {loa2._v[2], line1._line._line._i_p[2]}
 eqns: {93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 104, 103}
 */
void LineFeederAndCapacitorTest_eqFunction_117(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,117};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 117 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[1] = data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */;
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,117};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 117 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */ = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */ = data->simulationInfo->nonlinearSystemData[1].nlsx[1];
  TRACE_POP
}
/*
 equation index: 118
 type: SIMPLE_ASSIGN
 $cse2 = atan2(-line1.line.line.i_p[2], -line1.line.line.i_p[1])
 */
void LineFeederAndCapacitorTest_eqFunction_118(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,118};
  data->localData[0]->realVars[15] /* $cse2 variable */ = atan2((-data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */), (-data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 119
 type: SIMPLE_ASSIGN
 gri._sou._phi = $cse1 - $cse2
 */
void LineFeederAndCapacitorTest_eqFunction_119(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,119};
  data->localData[0]->realVars[24] /* gri._sou._phi variable */ = data->localData[0]->realVars[14] /* $cse1 variable */ - data->localData[0]->realVars[15] /* $cse2 variable */;
  TRACE_POP
}
/*
 equation index: 120
 type: SIMPLE_ASSIGN
 gri._P._cosPhi = cos(gri.sou.phi)
 */
void LineFeederAndCapacitorTest_eqFunction_120(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,120};
  data->localData[0]->realVars[21] /* gri._P._cosPhi variable */ = cos(data->localData[0]->realVars[24] /* gri._sou._phi variable */);
  TRACE_POP
}
/*
 equation index: 121
 type: SIMPLE_ASSIGN
 gri._sou._S[2] = gri.terminal.v[2] * line1.line.line.i_p[1] - gri.terminal.v[1] * line1.line.line.i_p[2]
 */
void LineFeederAndCapacitorTest_eqFunction_121(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,121};
  data->localData[0]->realVars[23] /* gri._sou._S[2] variable */ = (data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */) * (data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) - ((data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */) * (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 122
 type: SIMPLE_ASSIGN
 gri._sou._S[1] = gri.terminal.v[1] * line1.line.line.i_p[1] + gri.terminal.v[2] * line1.line.line.i_p[2]
 */
void LineFeederAndCapacitorTest_eqFunction_122(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,122};
  data->localData[0]->realVars[22] /* gri._sou._S[1] variable */ = (data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */) * (data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) + (data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */) * (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */);
  TRACE_POP
}
/*
 equation index: 123
 type: SIMPLE_ASSIGN
 gri._P._apparent = Modelica.Fluid.Utilities.regRoot(gri.sou.S[2] ^ 2.0 + gri.sou.S[1] ^ 2.0, 0.01)
 */
void LineFeederAndCapacitorTest_eqFunction_123(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,123};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = data->localData[0]->realVars[23] /* gri._sou._S[2] variable */;
  tmp1 = data->localData[0]->realVars[22] /* gri._sou._S[1] variable */;
  data->localData[0]->realVars[20] /* gri._P._apparent variable */ = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp0 * tmp0) + (tmp1 * tmp1), 0.01);
  TRACE_POP
}
/*
 equation index: 124
 type: SIMPLE_ASSIGN
 loa3._S[2] = loa2.v[1] * loa3.i[2] - loa2.v[2] * loa3.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_124(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,124};
  data->localData[0]->realVars[67] /* loa3._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 125
 type: SIMPLE_ASSIGN
 loa3._S[1] = (-loa2.v[1]) * loa3.i[1] - loa2.v[2] * loa3.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_125(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,125};
  data->localData[0]->realVars[66] /* loa3._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[70] /* loa3._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[71] /* loa3._i[2] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 126
 type: SIMPLE_ASSIGN
 loa2._S[2] = loa2.v[1] * loa2.i[2] - loa2.v[2] * loa2.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_126(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,126};
  data->localData[0]->realVars[57] /* loa2._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 127
 type: SIMPLE_ASSIGN
 loa2._S[1] = (-loa2.v[1]) * loa2.i[1] - loa2.v[2] * loa2.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_127(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,127};
  data->localData[0]->realVars[56] /* loa2._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[58] /* loa2._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[59] /* loa2._i[2] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 128
 type: SIMPLE_ASSIGN
 line1._line._VoltageLosses = DIVISION(abs(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)), smooth(1, if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) > 1.0) then Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) else if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) < -1.0) then Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) else 0.25 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) * (-3.0 + (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) ^ 2.0) * (Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05)) + 0.5 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) + Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05))))
 */
void LineFeederAndCapacitorTest_eqFunction_128(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,128};
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_boolean tmp10;
  modelica_real tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_boolean tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_boolean tmp37;
  modelica_real tmp38;
  modelica_boolean tmp39;
  modelica_real tmp40;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
  tmp5 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
  tmp6 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp7 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp8 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
  tmp9 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
  tmp10 = Greater(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp6 * tmp6) + (tmp7 * tmp7), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp8 * tmp8) + (tmp9 * tmp9), 1e-05),1.0);
  tmp39 = (modelica_boolean)tmp10;
  if(tmp39)
  {
    tmp11 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
    tmp12 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
    tmp40 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp11 * tmp11) + (tmp12 * tmp12), 1e-05);
  }
  else
  {
    tmp13 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
    tmp14 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
    tmp15 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
    tmp16 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
    tmp17 = Less(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp13 * tmp13) + (tmp14 * tmp14), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp15 * tmp15) + (tmp16 * tmp16), 1e-05),-1.0);
    tmp37 = (modelica_boolean)tmp17;
    if(tmp37)
    {
      tmp18 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp19 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp38 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp18 * tmp18) + (tmp19 * tmp19), 1e-05);
    }
    else
    {
      tmp20 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp21 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp22 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp23 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp24 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp25 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp26 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp27 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp28 = omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp24 * tmp24) + (tmp25 * tmp25), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp26 * tmp26) + (tmp27 * tmp27), 1e-05);
      tmp29 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp30 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp31 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp32 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp33 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
      tmp34 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
      tmp35 = data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */;
      tmp36 = data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */;
      tmp38 = (0.25) * ((omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp20 * tmp20) + (tmp21 * tmp21), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp22 * tmp22) + (tmp23 * tmp23), 1e-05)) * ((-3.0 + (tmp28 * tmp28)) * (omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp29 * tmp29) + (tmp30 * tmp30), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp31 * tmp31) + (tmp32 * tmp32), 1e-05)))) + (0.5) * (omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp33 * tmp33) + (tmp34 * tmp34), 1e-05) + omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp35 * tmp35) + (tmp36 * tmp36), 1e-05));
    }
    tmp40 = tmp38;
  }
  data->localData[0]->realVars[28] /* line1._line._VoltageLosses variable */ = DIVISION_SIM(fabs(omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp2 * tmp2) + (tmp3 * tmp3), 1e-05) - omc_Modelica_Fluid_Utilities_regRoot(threadData, (tmp4 * tmp4) + (tmp5 * tmp5), 1e-05)),tmp40,"smooth(1, if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) > 1.0) then Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) else if noEvent(Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) < -1.0) then Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) else 0.25 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) * (-3.0 + (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)) ^ 2.0) * (Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05) - Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05)) + 0.5 * (Modelica.Fluid.Utilities.regRoot(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0, 1e-05) + Modelica.Fluid.Utilities.regRoot(gri.terminal.v[1] ^ 2.0 + gri.terminal.v[2] ^ 2.0, 1e-05)))",equationIndexes);
  TRACE_POP
}
/*
 equation index: 153
 type: LINEAR
 
 <var>der(loa2._v[1])</var>
 <var>der(line1._line._line._i_p[1])</var>
 <row>

 </row>
 <matrix>
 </matrix>
 */
void LineFeederAndCapacitorTest_eqFunction_153(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,153};
  /* Linear equation system */
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving linear system 153 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  data->simulationInfo->linearSystemData[1].x[0] = data->localData[1]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */;
  data->simulationInfo->linearSystemData[1].x[1] = data->localData[1]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */;
  retValue = solve_linear_system(data, threadData, 1);
  
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,153};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving linear system 153 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ = data->simulationInfo->linearSystemData[1].x[0];
  data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ = data->simulationInfo->linearSystemData[1].x[1];
  TRACE_POP
}
/*
 equation index: 154
 type: SIMPLE_ASSIGN
 loa1._S[2] = loa2.v[1] * loa1.i[2] - loa2.v[2] * loa1.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_154(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,154};
  data->localData[0]->realVars[44] /* loa1._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 155
 type: SIMPLE_ASSIGN
 loa1._S[1] = (-loa2.v[1]) * loa1.i[1] - loa2.v[2] * loa1.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_155(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,155};
  data->localData[0]->realVars[43] /* loa1._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[47] /* loa1._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[48] /* loa1._i[2] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 156
 type: SIMPLE_ASSIGN
 loa._S[2] = loa2.v[1] * loa.i[2] - loa2.v[2] * loa.i[1]
 */
void LineFeederAndCapacitorTest_eqFunction_156(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,156};
  data->localData[0]->realVars[36] /* loa._S[2] variable */ = (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 157
 type: SIMPLE_ASSIGN
 loa._S[1] = (-loa2.v[1]) * loa.i[1] - loa2.v[2] * loa.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_157(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,157};
  data->localData[0]->realVars[35] /* loa._S[1] variable */ = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[37] /* loa._i[1] DUMMY_STATE */) - ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[38] /* loa._i[2] DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 158
 type: SIMPLE_ASSIGN
 loa1._theRef = 6.283185307179586 * gri.sou.f * time
 */
void LineFeederAndCapacitorTest_eqFunction_158(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,158};
  data->localData[0]->realVars[53] /* loa1._theRef DUMMY_STATE */ = (6.283185307179586) * ((data->simulationInfo->realParameter[4]) * (data->localData[0]->timeValue));
  TRACE_POP
}
/*
 equation index: 159
 type: ALGORITHM
 
   assert(line1.line.L >= 0.0, "The parameters R,L,C must be positive. Check cable properties and size.");
 */
void LineFeederAndCapacitorTest_eqFunction_159(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,159};
  modelica_boolean tmp41;
  static const MMC_DEFSTRINGLIT(tmp42,71,"The parameters R,L,C must be positive. Check cable properties and size.");
  static int tmp43 = 0;
  {
    tmp41 = GreaterEq(data->simulationInfo->realParameter[7],0.0);
    if(!tmp41)
    {
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",61,3,61,108,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.L >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_withEquationIndexes(threadData, info, equationIndexes, MMC_STRINGDATA(MMC_REFSTRINGLIT(tmp42)));
      }
    }
  }
  TRACE_POP
}


int LineFeederAndCapacitorTest_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  LineFeederAndCapacitorTest_functionLocalKnownVars(data, threadData);
  LineFeederAndCapacitorTest_eqFunction_90(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_91(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_92(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_117(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_118(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_119(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_120(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_121(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_122(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_123(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_124(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_125(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_126(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_127(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_128(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_153(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_154(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_155(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_156(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_157(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_158(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_159(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int LineFeederAndCapacitorTest_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


int LineFeederAndCapacitorTest_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  LineFeederAndCapacitorTest_functionLocalKnownVars(data, threadData);
  /* no ODE systems */

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "LineFeederAndCapacitorTest_12jac.h"
#include "LineFeederAndCapacitorTest_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks LineFeederAndCapacitorTest_callback = {
   (int (*)(DATA *, threadData_t *, void *)) LineFeederAndCapacitorTest_performSimulation,
   (int (*)(DATA *, threadData_t *, void *)) LineFeederAndCapacitorTest_performQSSSimulation,
   LineFeederAndCapacitorTest_updateContinuousSystem,
   LineFeederAndCapacitorTest_callExternalObjectDestructors,
   LineFeederAndCapacitorTest_initialNonLinearSystem,
   LineFeederAndCapacitorTest_initialLinearSystem,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   LineFeederAndCapacitorTest_initializeStateSets,
   #else
   NULL,
   #endif
   LineFeederAndCapacitorTest_initializeDAEmodeData,
   LineFeederAndCapacitorTest_functionODE,
   LineFeederAndCapacitorTest_functionAlgebraics,
   LineFeederAndCapacitorTest_functionDAE,
   LineFeederAndCapacitorTest_functionLocalKnownVars,
   LineFeederAndCapacitorTest_input_function,
   LineFeederAndCapacitorTest_input_function_init,
   LineFeederAndCapacitorTest_input_function_updateStartValues,
   LineFeederAndCapacitorTest_output_function,
   LineFeederAndCapacitorTest_function_storeDelayed,
   LineFeederAndCapacitorTest_updateBoundVariableAttributes,
   LineFeederAndCapacitorTest_functionInitialEquations,
   LineFeederAndCapacitorTest_functionRemovedInitialEquations,
   LineFeederAndCapacitorTest_updateBoundParameters,
   LineFeederAndCapacitorTest_checkForAsserts,
   LineFeederAndCapacitorTest_function_ZeroCrossingsEquations,
   LineFeederAndCapacitorTest_function_ZeroCrossings,
   LineFeederAndCapacitorTest_function_updateRelations,
   LineFeederAndCapacitorTest_checkForDiscreteChanges,
   LineFeederAndCapacitorTest_zeroCrossingDescription,
   LineFeederAndCapacitorTest_relationDescription,
   LineFeederAndCapacitorTest_function_initSample,
   LineFeederAndCapacitorTest_INDEX_JAC_A,
   LineFeederAndCapacitorTest_INDEX_JAC_B,
   LineFeederAndCapacitorTest_INDEX_JAC_C,
   LineFeederAndCapacitorTest_INDEX_JAC_D,
   LineFeederAndCapacitorTest_initialAnalyticJacobianA,
   LineFeederAndCapacitorTest_initialAnalyticJacobianB,
   LineFeederAndCapacitorTest_initialAnalyticJacobianC,
   LineFeederAndCapacitorTest_initialAnalyticJacobianD,
   LineFeederAndCapacitorTest_functionJacA_column,
   LineFeederAndCapacitorTest_functionJacB_column,
   LineFeederAndCapacitorTest_functionJacC_column,
   LineFeederAndCapacitorTest_functionJacD_column,
   LineFeederAndCapacitorTest_linear_model_frame,
   LineFeederAndCapacitorTest_linear_model_datarecovery_frame,
   LineFeederAndCapacitorTest_mayer,
   LineFeederAndCapacitorTest_lagrange,
   LineFeederAndCapacitorTest_pickUpBoundsForInputsInOptimization,
   LineFeederAndCapacitorTest_setInputData,
   LineFeederAndCapacitorTest_getTimeGrid,
   LineFeederAndCapacitorTest_symbolicInlineSystem,
   LineFeederAndCapacitorTest_function_initSynchronous,
   LineFeederAndCapacitorTest_function_updateSynchronous,
   LineFeederAndCapacitorTest_function_equationsSynchronous,
   NULL
   #ifdef FMU_EXPERIMENTAL
   ,LineFeederAndCapacitorTest_functionODE_Partial
   ,LineFeederAndCapacitorTest_functionFMIJacobian
   #endif
   ,LineFeederAndCapacitorTest_inputNames


};

void LineFeederAndCapacitorTest_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &LineFeederAndCapacitorTest_callback;
  data->modelData->modelName = "LineFeederAndCapacitorTest";
  data->modelData->modelFilePrefix = "LineFeederAndCapacitorTest";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "/home/bhaskar/Modelica/Modelica-Files";
  data->modelData->modelGUID = "{0247fd90-9fea-4a3b-9e29-2a76fb1e9c00}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "LineFeederAndCapacitorTest_init.c"
    ;
  static const char contents_info[] =
    #include "LineFeederAndCapacitorTest_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "LineFeederAndCapacitorTest_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "LineFeederAndCapacitorTest_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  
  data->modelData->nStates = 0;
  data->modelData->nVariablesReal = 76;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 42;
  data->modelData->nParametersInteger = 13;
  data->modelData->nParametersBoolean = 11;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  
  data->modelData->nAliasReal = 89;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 0;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "LineFeederAndCapacitorTest_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 9;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 276;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 2;
  data->modelData->nNonLinearSystems = 2;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 7;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    LineFeederAndCapacitorTest_setupDataStruc(&data, threadData);
    res = _main_SimulationRuntime(argc, argv, &data, threadData);
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

