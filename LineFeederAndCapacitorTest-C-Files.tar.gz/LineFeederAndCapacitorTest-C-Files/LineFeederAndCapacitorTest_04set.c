/* Initial State Set */
#include "LineFeederAndCapacitorTest_model.h"
#include "LineFeederAndCapacitorTest_11mix.h"
#include "LineFeederAndCapacitorTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void LineFeederAndCapacitorTest_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

