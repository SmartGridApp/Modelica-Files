/* Linear Systems */
#include "LineFeederAndCapacitorTest_model.h"
#include "LineFeederAndCapacitorTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* initial linear systems */

/*
 equation index: 38
 type: SIMPLE_ASSIGN
 der(loa2._v[2]) = line1.line.line.L * (line1.line.line.i_p[1] * $DER.loa1.omega + $DER.line1.line.line.i_p[1] * loa1.omega)
 */
void LineFeederAndCapacitorTest_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */ = (data->simulationInfo->realParameter[22]) * ((data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */) * (data->localData[0]->realVars[6] /* der(loa1._omega) DUMMY_DER */) + (data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 39
 type: SIMPLE_ASSIGN
 der(loa._i[1]) = -homotopy(DIVISION(loa2.v[1] * (-loa.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) + $DER.loa2.v[1] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[2] /* der(loa._i[1]) DUMMY_DER */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (((-data->simulationInfo->realParameter[32])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 40
 type: SIMPLE_ASSIGN
 der(loa._i[2]) = -homotopy(DIVISION(loa2.v[2] * (-loa.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) + $DER.loa2.v[2] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_40(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,40};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[3] /* der(loa._i[2]) DUMMY_DER */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (((-data->simulationInfo->realParameter[32])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) + (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 41
 type: SIMPLE_ASSIGN
 der(loa1._i[2]) = -homotopy(DIVISION(($DER.loa2.v[2] * loa1.P_nominal - $DER.loa2.v[1] * loa1.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_41(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,41};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[5] /* der(loa1._i[2]) DUMMY_DER */ = (-homotopy(DIVISION_SIM(((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * ((tmp0 * tmp0) + (tmp1 * tmp1)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 42
 type: SIMPLE_ASSIGN
 der(loa1._i[1]) = -homotopy(DIVISION(($DER.loa2.v[2] * loa1.Q + $DER.loa2.v[1] * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_42(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,42};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[4] /* der(loa1._i[1]) DUMMY_DER */ = (-homotopy(DIVISION_SIM(((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->simulationInfo->realParameter[34])) * ((tmp0 * tmp0) + (tmp1 * tmp1)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 43
 type: SIMPLE_ASSIGN
 der(loa2._i[1]) = -homotopy(DIVISION(loa2.v[1] * (-loa2.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) + $DER.loa2.v[1] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_43(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,43};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[8] /* der(loa2._i[1]) DUMMY_DER */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (((-data->simulationInfo->realParameter[37])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 44
 type: SIMPLE_ASSIGN
 der(loa2._i[2]) = -homotopy(DIVISION(loa2.v[2] * (-loa2.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) + $DER.loa2.v[2] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[9] /* der(loa2._i[2]) DUMMY_DER */ = (-homotopy(DIVISION_SIM((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (((-data->simulationInfo->realParameter[37])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) + (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}
/*
 equation index: 45
 type: SIMPLE_ASSIGN
 der(loa3._i[1]) = -homotopy(DIVISION(($DER.loa2.v[2] * loa3.Q + $DER.loa2.v[1] * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_45(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,45};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[12] /* der(loa3._i[1]) DUMMY_DER */ = (-homotopy(DIVISION_SIM(((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->simulationInfo->realParameter[39])) * ((tmp0 * tmp0) + (tmp1 * tmp1)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 46
 type: SIMPLE_ASSIGN
 der(loa3._i[2]) = -homotopy(DIVISION(($DER.loa2.v[2] * loa3.P_nominal - $DER.loa2.v[1] * loa3.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,46};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[13] /* der(loa3._i[2]) DUMMY_DER */ = (-homotopy(DIVISION_SIM(((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * ((tmp0 * tmp0) + (tmp1 * tmp1)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes), 0.0));
  TRACE_POP
}
/*
 equation index: 47
 type: SIMPLE_ASSIGN
 der(line1._line._line._i_p[2]) = (-$DER.loa.i[2]) - $DER.loa1.i[2] - $DER.loa2.i[2] - $DER.loa3.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_47(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,47};
  data->localData[0]->realVars[1] /* der(line1._line._line._i_p[2]) DUMMY_DER */ = (-data->localData[0]->realVars[3] /* der(loa._i[2]) DUMMY_DER */) - data->localData[0]->realVars[5] /* der(loa1._i[2]) DUMMY_DER */ - data->localData[0]->realVars[9] /* der(loa2._i[2]) DUMMY_DER */ - data->localData[0]->realVars[13] /* der(loa3._i[2]) DUMMY_DER */;
  TRACE_POP
}

void residualFunc62(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,62};
  data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ = xloc[0];
  data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ = xloc[1];
  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_38(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_39(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_40(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_41(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_42(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_43(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_44(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_45(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_46(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_47(data, threadData);
  res[0] = data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ + (data->simulationInfo->realParameter[22]) * ((data->localData[0]->realVars[1] /* der(line1._line._line._i_p[2]) DUMMY_DER */) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */) + (data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */) * (data->localData[0]->realVars[6] /* der(loa1._omega) DUMMY_DER */));

  res[1] = data->localData[0]->realVars[12] /* der(loa3._i[1]) DUMMY_DER */ + data->localData[0]->realVars[8] /* der(loa2._i[1]) DUMMY_DER */ + data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ + data->localData[0]->realVars[4] /* der(loa1._i[1]) DUMMY_DER */ + data->localData[0]->realVars[2] /* der(loa._i[1]) DUMMY_DER */;
  TRACE_POP
}
void initializeStaticLSData62(void *inData, threadData_t *threadData, void *systemData)
{
  DATA* data = (DATA*) inData;
  LINEAR_SYSTEM_DATA* linearSystemData = (LINEAR_SYSTEM_DATA*) systemData;
  int i=0;
  /* static ls data for der(loa2.v[1]) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.max;
  /* static ls data for der(line1.line.line.i_p[1]) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.max;
}
/* parameter linear systems */
/* model linear systems */

/*
 equation index: 129
 type: SIMPLE_ASSIGN
 der(loa2._v[2]) = line1.line.line.L * $DER.line1.line.line.i_p[1] * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_129(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,129};
  data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */ = (data->simulationInfo->realParameter[22]) * ((data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}
/*
 equation index: 130
 type: SIMPLE_ASSIGN
 der(loa._i[2]) = DIVISION((-loa2.v[2]) * (-loa.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - $DER.loa2.v[2] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_130(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,130};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[3] /* der(loa._i[2]) DUMMY_DER */ = DIVISION_SIM(((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[32])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) - ((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 131
 type: SIMPLE_ASSIGN
 der(loa2._i[2]) = DIVISION((-loa2.v[2]) * (-loa2.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - $DER.loa2.v[2] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_131(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,131};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[9] /* der(loa2._i[2]) DUMMY_DER */ = DIVISION_SIM(((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[37])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) - ((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 132
 type: SIMPLE_ASSIGN
 der(loa3._i[1]) = DIVISION((loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]) - ($DER.loa2.v[2] * loa3.Q + $DER.loa2.v[1] * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_132(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,132};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[12] /* der(loa3._i[1]) DUMMY_DER */ = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */)) - (((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->simulationInfo->realParameter[39])) * ((tmp0 * tmp0) + (tmp1 * tmp1))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 133
 type: SIMPLE_ASSIGN
 der(loa1._i[1]) = DIVISION((loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]) - ($DER.loa2.v[2] * loa1.Q + $DER.loa2.v[1] * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_133(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,133};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[4] /* der(loa1._i[1]) DUMMY_DER */ = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */)) - (((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->simulationInfo->realParameter[34])) * ((tmp0 * tmp0) + (tmp1 * tmp1))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 134
 type: SIMPLE_ASSIGN
 der(loa1._i[2]) = DIVISION((loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]) - ($DER.loa2.v[2] * loa1.P_nominal - $DER.loa2.v[1] * loa1.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_134(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,134};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[5] /* der(loa1._i[2]) DUMMY_DER */ = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */)) - (((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * ((tmp0 * tmp0) + (tmp1 * tmp1))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 135
 type: SIMPLE_ASSIGN
 der(loa3._i[2]) = DIVISION((loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]) - ($DER.loa2.v[2] * loa3.P_nominal - $DER.loa2.v[1] * loa3.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_135(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,135};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp3 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp4 = (tmp2 * tmp2) + (tmp3 * tmp3);
  data->localData[0]->realVars[13] /* der(loa3._i[2]) DUMMY_DER */ = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */)) - (((data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * ((tmp0 * tmp0) + (tmp1 * tmp1))),(tmp4 * tmp4),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}
/*
 equation index: 136
 type: SIMPLE_ASSIGN
 der(loa2._i[1]) = DIVISION((-loa2.v[1]) * (-loa2.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - $DER.loa2.v[1] * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_136(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,136};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[8] /* der(loa2._i[1]) DUMMY_DER */ = DIVISION_SIM(((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[37])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 137
 type: SIMPLE_ASSIGN
 der(loa._i[1]) = DIVISION((-loa2.v[1]) * (-loa.P_nominal) * (2.0 * loa2.v[1] * $DER.loa2.v[1] + 2.0 * loa2.v[2] * $DER.loa2.v[2]), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - $DER.loa2.v[1] * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_137(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,137};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  data->localData[0]->realVars[2] /* der(loa._i[1]) DUMMY_DER */ = DIVISION_SIM(((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[32])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (data->localData[0]->realVars[11] /* der(loa2._v[2]) DUMMY_DER */))),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes) - ((data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 138
 type: SIMPLE_ASSIGN
 der(line1._line._line._i_p[2]) = (-$DER.loa.i[2]) - $DER.loa1.i[2] - $DER.loa2.i[2] - $DER.loa3.i[2]
 */
void LineFeederAndCapacitorTest_eqFunction_138(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,138};
  data->localData[0]->realVars[1] /* der(line1._line._line._i_p[2]) DUMMY_DER */ = (-data->localData[0]->realVars[3] /* der(loa._i[2]) DUMMY_DER */) - data->localData[0]->realVars[5] /* der(loa1._i[2]) DUMMY_DER */ - data->localData[0]->realVars[9] /* der(loa2._i[2]) DUMMY_DER */ - data->localData[0]->realVars[13] /* der(loa3._i[2]) DUMMY_DER */;
  TRACE_POP
}

void residualFunc153(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,153};
  data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ = xloc[0];
  data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ = xloc[1];
  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_129(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_130(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_131(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_132(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_133(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_134(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_135(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_136(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_137(data, threadData);

  /* local constraints */
  LineFeederAndCapacitorTest_eqFunction_138(data, threadData);
  res[0] = data->localData[0]->realVars[10] /* der(loa2._v[1]) DUMMY_DER */ + (data->simulationInfo->realParameter[22]) * ((data->localData[0]->realVars[1] /* der(line1._line._line._i_p[2]) DUMMY_DER */) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));

  res[1] = data->localData[0]->realVars[12] /* der(loa3._i[1]) DUMMY_DER */ + data->localData[0]->realVars[8] /* der(loa2._i[1]) DUMMY_DER */ + data->localData[0]->realVars[0] /* der(line1._line._line._i_p[1]) DUMMY_DER */ + data->localData[0]->realVars[4] /* der(loa1._i[1]) DUMMY_DER */ + data->localData[0]->realVars[2] /* der(loa._i[1]) DUMMY_DER */;
  TRACE_POP
}
void initializeStaticLSData153(void *inData, threadData_t *threadData, void *systemData)
{
  DATA* data = (DATA*) inData;
  LINEAR_SYSTEM_DATA* linearSystemData = (LINEAR_SYSTEM_DATA*) systemData;
  int i=0;
  /* static ls data for der(loa2.v[1]) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[10].attribute /* der(loa2._v[1]) */.max;
  /* static ls data for der(line1.line.line.i_p[1]) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[0].attribute /* der(line1._line._line._i_p[1]) */.max;
}
/* inline linear systems */
/* jacobians linear systems */

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize linear systems */
void LineFeederAndCapacitorTest_initialLinearSystem(int nLinearSystems, LINEAR_SYSTEM_DATA* linearSystemData)
{
  /* initial linear systems */
  assertStreamPrint(NULL, nLinearSystems > 0, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[0].equationIndex = 62;
  linearSystemData[0].size = 2;
  linearSystemData[0].nnz = 0;
  linearSystemData[0].method = 1;
  linearSystemData[0].residualFunc = residualFunc62;
  linearSystemData[0].strictTearingFunctionCall = NULL;
  linearSystemData[0].analyticalJacobianColumn = LineFeederAndCapacitorTest_functionJacLSJac5_column;
  linearSystemData[0].initialAnalyticalJacobian = LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac5;
  linearSystemData[0].jacobianIndex = 0;
  linearSystemData[0].setA = NULL;//setLinearMatrixA62;
  linearSystemData[0].setb = NULL; //setLinearVectorb62;
  linearSystemData[0].initializeStaticLSData = initializeStaticLSData62;
  /* parameter linear systems */
  /* model linear systems */
  assertStreamPrint(NULL, nLinearSystems > 1, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[1].equationIndex = 153;
  linearSystemData[1].size = 2;
  linearSystemData[1].nnz = 0;
  linearSystemData[1].method = 1;
  linearSystemData[1].residualFunc = residualFunc153;
  linearSystemData[1].strictTearingFunctionCall = NULL;
  linearSystemData[1].analyticalJacobianColumn = LineFeederAndCapacitorTest_functionJacLSJac7_column;
  linearSystemData[1].initialAnalyticalJacobian = LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac7;
  linearSystemData[1].jacobianIndex = 2;
  linearSystemData[1].setA = NULL;//setLinearMatrixA153;
  linearSystemData[1].setb = NULL; //setLinearVectorb153;
  linearSystemData[1].initializeStaticLSData = initializeStaticLSData153;
  /* inline linear systems */
  /* jacobians linear systems */
}

#if defined(__cplusplus)
}
#endif

