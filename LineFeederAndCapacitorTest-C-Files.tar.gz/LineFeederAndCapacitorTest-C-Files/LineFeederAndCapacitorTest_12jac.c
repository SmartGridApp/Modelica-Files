/* Jacobians */
#include "LineFeederAndCapacitorTest_model.h"
#include "LineFeederAndCapacitorTest_12jac.h"

int LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac7(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_LSJac7;
  const int colPtrIndex[1+2] = {0,2,2};
  const int rowIndex[4] = {0,1,0,1};
  int i = 0;
  
  data->simulationInfo->analyticJacobians[index].sizeCols = 2;
  data->simulationInfo->analyticJacobians[index].sizeRows = 2;
  data->simulationInfo->analyticJacobians[index].sizeTmpVars = 12;
  data->simulationInfo->analyticJacobians[index].seedVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].resultVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].tmpVars = (modelica_real*) calloc(12,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex = (unsigned int*) malloc((2+1)*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.index = (unsigned int*) malloc(4*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.numberOfNoneZeros = 4;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols = (unsigned int*) malloc(2*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.maxColors = 2;
  data->simulationInfo->analyticJacobians[index].jacobian = NULL;
  
  /* write lead index of compressed sparse column */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex, colPtrIndex, (2+1)*sizeof(int));
  
  for(i=2;i<2+1;++i)
    data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i] += data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.index, rowIndex, 4*sizeof(int));
  
  /* write color array */
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[1] = 1;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[0] = 2;
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_initialAnalyticJacobianNLSJac6(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_NLSJac6;
  const int colPtrIndex[1+2] = {0,2,2};
  const int rowIndex[4] = {0,1,0,1};
  int i = 0;
  
  data->simulationInfo->analyticJacobians[index].sizeCols = 2;
  data->simulationInfo->analyticJacobians[index].sizeRows = 2;
  data->simulationInfo->analyticJacobians[index].sizeTmpVars = 12;
  data->simulationInfo->analyticJacobians[index].seedVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].resultVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].tmpVars = (modelica_real*) calloc(12,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex = (unsigned int*) malloc((2+1)*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.index = (unsigned int*) malloc(4*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.numberOfNoneZeros = 4;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols = (unsigned int*) malloc(2*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.maxColors = 2;
  data->simulationInfo->analyticJacobians[index].jacobian = NULL;
  
  /* write lead index of compressed sparse column */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex, colPtrIndex, (2+1)*sizeof(int));
  
  for(i=2;i<2+1;++i)
    data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i] += data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.index, rowIndex, 4*sizeof(int));
  
  /* write color array */
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[1] = 1;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[0] = 2;
  TRACE_POP
  return 0;
}

int LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac5(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_LSJac5;
  const int colPtrIndex[1+2] = {0,2,2};
  const int rowIndex[4] = {0,1,0,1};
  int i = 0;
  
  data->simulationInfo->analyticJacobians[index].sizeCols = 2;
  data->simulationInfo->analyticJacobians[index].sizeRows = 2;
  data->simulationInfo->analyticJacobians[index].sizeTmpVars = 12;
  data->simulationInfo->analyticJacobians[index].seedVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].resultVars = (modelica_real*) calloc(2,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].tmpVars = (modelica_real*) calloc(12,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex = (unsigned int*) malloc((2+1)*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.index = (unsigned int*) malloc(4*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.numberOfNoneZeros = 4;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols = (unsigned int*) malloc(2*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.maxColors = 2;
  data->simulationInfo->analyticJacobians[index].jacobian = NULL;
  
  /* write lead index of compressed sparse column */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex, colPtrIndex, (2+1)*sizeof(int));
  
  for(i=2;i<2+1;++i)
    data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i] += data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.index, rowIndex, 4*sizeof(int));
  
  /* write color array */
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[1] = 1;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[0] = 2;
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_initialAnalyticJacobianA(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int LineFeederAndCapacitorTest_initialAnalyticJacobianB(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int LineFeederAndCapacitorTest_initialAnalyticJacobianC(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int LineFeederAndCapacitorTest_initialAnalyticJacobianD(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}


/*
 equation index: 141
 type: SIMPLE_ASSIGN
 der(loa2._v._2._$pDERLSJac7._dummyVarLSJac7) = line1.line.line.L * $DER_line1_line_line_i_p_1SeedLSJac7 * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_141(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,141};
  $P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7 = (data->simulationInfo->realParameter[22]) * (($P$DER_line1_line_line_i_p_1SeedLSJac7) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 142
 type: SIMPLE_ASSIGN
 der(loa._i._2._$pDERLSJac7._dummyVarLSJac7) = loa.P_nominal * (loa2.v[2] * DIVISION(2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - DIVISION($DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0))
 */
void LineFeederAndCapacitorTest_eqFunction_142(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,142};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  tmp0 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp1 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  tmp3 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp4 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 = (data->simulationInfo->realParameter[32]) * ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)),(tmp2 * tmp2),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes)) - DIVISION_SIM($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7,(tmp3 * tmp3) + (tmp4 * tmp4),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}

/*
 equation index: 143
 type: SIMPLE_ASSIGN
 der(loa2._i._2._$pDERLSJac7._dummyVarLSJac7) = loa2.P_nominal * (loa2.v[2] * DIVISION(2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - DIVISION($DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0))
 */
void LineFeederAndCapacitorTest_eqFunction_143(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,143};
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  tmp5 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp6 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp7 = (tmp5 * tmp5) + (tmp6 * tmp6);
  tmp8 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp9 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa2$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 = (data->simulationInfo->realParameter[37]) * ((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)),(tmp7 * tmp7),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes)) - DIVISION_SIM($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7,(tmp8 * tmp8) + (tmp9 * tmp9),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}

/*
 equation index: 144
 type: SIMPLE_ASSIGN
 der(loa3._i._1._$pDERLSJac7._dummyVarLSJac7) = DIVISION((loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal) * 2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) + ((-$DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) * loa3.Q - $DER_loa2_v_1SeedLSJac7 * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_144(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,144};
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  tmp10 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp11 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp12 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp13 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp14 = (tmp12 * tmp12) + (tmp13 * tmp13);
  $P$DER$Ploa3$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7))) + (((-$P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - (($P$DER_loa2_v_1SeedLSJac7) * (data->simulationInfo->realParameter[39]))) * ((tmp10 * tmp10) + (tmp11 * tmp11)),(tmp14 * tmp14),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 145
 type: SIMPLE_ASSIGN
 der(loa1._i._1._$pDERLSJac7._dummyVarLSJac7) = DIVISION((loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal) * 2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) + ((-$DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) * loa1.Q - $DER_loa2_v_1SeedLSJac7 * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_145(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,145};
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  tmp15 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp16 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp17 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp18 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp19 = (tmp17 * tmp17) + (tmp18 * tmp18);
  $P$DER$Ploa1$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7))) + (((-$P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - (($P$DER_loa2_v_1SeedLSJac7) * (data->simulationInfo->realParameter[34]))) * ((tmp15 * tmp15) + (tmp16 * tmp16)),(tmp19 * tmp19),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 146
 type: SIMPLE_ASSIGN
 der(loa1._i._2._$pDERLSJac7._dummyVarLSJac7) = DIVISION((loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q) * 2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) + ($DER_loa2_v_1SeedLSJac7 * loa1.Q - $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7 * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_146(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,146};
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  tmp20 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp21 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp22 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp23 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp24 = (tmp22 * tmp22) + (tmp23 * tmp23);
  $P$DER$Ploa1$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7))) + (($P$DER_loa2_v_1SeedLSJac7) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - (($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7) * (data->simulationInfo->realParameter[34]))) * ((tmp20 * tmp20) + (tmp21 * tmp21)),(tmp24 * tmp24),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 147
 type: SIMPLE_ASSIGN
 der(loa3._i._2._$pDERLSJac7._dummyVarLSJac7) = DIVISION((loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q) * 2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7) + ($DER_loa2_v_1SeedLSJac7 * loa3.Q - $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7 * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_147(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,147};
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  tmp25 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp26 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp27 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp28 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp29 = (tmp27 * tmp27) + (tmp28 * tmp28);
  $P$DER$Ploa3$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7))) + (($P$DER_loa2_v_1SeedLSJac7) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - (($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7) * (data->simulationInfo->realParameter[39]))) * ((tmp25 * tmp25) + (tmp26 * tmp26)),(tmp29 * tmp29),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 148
 type: SIMPLE_ASSIGN
 der(loa2._i._1._$pDERLSJac7._dummyVarLSJac7) = loa2.P_nominal * (loa2.v[1] * DIVISION(2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - DIVISION($DER_loa2_v_1SeedLSJac7, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0))
 */
void LineFeederAndCapacitorTest_eqFunction_148(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,148};
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  tmp30 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp31 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp32 = (tmp30 * tmp30) + (tmp31 * tmp31);
  tmp33 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp34 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa2$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 = (data->simulationInfo->realParameter[37]) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)),(tmp32 * tmp32),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes)) - DIVISION_SIM($P$DER_loa2_v_1SeedLSJac7,(tmp33 * tmp33) + (tmp34 * tmp34),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}

/*
 equation index: 149
 type: SIMPLE_ASSIGN
 der(loa._i._1._$pDERLSJac7._dummyVarLSJac7) = loa.P_nominal * (loa2.v[1] * DIVISION(2.0 * (loa2.v[1] * $DER_loa2_v_1SeedLSJac7 + loa2.v[2] * $DER.loa2.v.2.$pDERLSJac7.dummyVarLSJac7), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - DIVISION($DER_loa2_v_1SeedLSJac7, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0))
 */
void LineFeederAndCapacitorTest_eqFunction_149(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,149};
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_real tmp39;
  tmp35 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp36 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp37 = (tmp35 * tmp35) + (tmp36 * tmp36);
  tmp38 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp39 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 = (data->simulationInfo->realParameter[32]) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($P$DER_loa2_v_1SeedLSJac7) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7)),(tmp37 * tmp37),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes)) - DIVISION_SIM($P$DER_loa2_v_1SeedLSJac7,(tmp38 * tmp38) + (tmp39 * tmp39),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes));
  TRACE_POP
}

/*
 equation index: 150
 type: SIMPLE_ASSIGN
 der(line1._line._line._i_p._2._$pDERLSJac7._dummyVarLSJac7) = (-$DER.loa.i.2.$pDERLSJac7.dummyVarLSJac7) - $DER.loa1.i.2.$pDERLSJac7.dummyVarLSJac7 - $DER.loa2.i.2.$pDERLSJac7.dummyVarLSJac7 - $DER.loa3.i.2.$pDERLSJac7.dummyVarLSJac7
 */
void LineFeederAndCapacitorTest_eqFunction_150(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,150};
  $P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac7$PdummyVarLSJac7 = (-$P$DER$Ploa$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7) - $P$DER$Ploa1$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 - $P$DER$Ploa2$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 - $P$DER$Ploa3$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7;
  TRACE_POP
}

/*
 equation index: 151
 type: SIMPLE_ASSIGN
 $res._1._$pDERLSJac7._dummyVarLSJac7 = $DER_loa2_v_1SeedLSJac7 + line1.line.line.L * $DER.line1.line.line.i_p.2.$pDERLSJac7.dummyVarLSJac7 * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_151(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,151};
  $P$res$P1$P$pDERLSJac7$PdummyVarLSJac7 = $P$DER_loa2_v_1SeedLSJac7 + (data->simulationInfo->realParameter[22]) * (($P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac7$PdummyVarLSJac7) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 152
 type: SIMPLE_ASSIGN
 $res._2._$pDERLSJac7._dummyVarLSJac7 = $DER.loa.i.1.$pDERLSJac7.dummyVarLSJac7 + $DER.loa1.i.1.$pDERLSJac7.dummyVarLSJac7 + $DER_line1_line_line_i_p_1SeedLSJac7 + $DER.loa2.i.1.$pDERLSJac7.dummyVarLSJac7 + $DER.loa3.i.1.$pDERLSJac7.dummyVarLSJac7
 */
void LineFeederAndCapacitorTest_eqFunction_152(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,152};
  $P$res$P2$P$pDERLSJac7$PdummyVarLSJac7 = $P$DER$Ploa$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 + $P$DER$Ploa1$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 + $P$DER_line1_line_line_i_p_1SeedLSJac7 + $P$DER$Ploa2$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 + $P$DER$Ploa3$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7;
  TRACE_POP
}
int LineFeederAndCapacitorTest_functionJacLSJac7_column(void* inData, threadData_t *threadData)
{
  TRACE_PUSH

  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_LSJac7;
  LineFeederAndCapacitorTest_eqFunction_141(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_142(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_143(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_144(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_145(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_146(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_147(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_148(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_149(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_150(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_151(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_152(data, threadData);
  
  TRACE_POP
  return 0;
}

/*
 equation index: 105
 type: SIMPLE_ASSIGN
 loa2._v._1._$pDERNLSJac6._dummyVarNLSJac6 = (-line1_line_line_i_p_2SeedNLSJac6) * line1.line.line.L * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_105(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,105};
  $Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = ((-$Pline1_line_line_i_p_2SeedNLSJac6)) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 106
 type: SIMPLE_ASSIGN
 loa._i._1._$pDERNLSJac6._dummyVarNLSJac6 = (-loa2.v[1]) * (-loa.P_nominal) * DIVISION(2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_106(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,106};
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_real tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  tmp40 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp41 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp42 = (tmp40 * tmp40) + (tmp41 * tmp41);
  tmp43 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp44 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $Ploa$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[32])) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6)),(tmp42 * tmp42),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes))) - (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp43 * tmp43) + (tmp44 * tmp44),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 107
 type: SIMPLE_ASSIGN
 loa1._i._1._$pDERNLSJac6._dummyVarNLSJac6 = DIVISION((loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal) * 2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6) + ((-loa2_v_2SeedNLSJac6) * loa1.Q - loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_107(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,107};
  modelica_real tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_real tmp48;
  modelica_real tmp49;
  tmp45 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp46 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp47 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp48 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp49 = (tmp47 * tmp47) + (tmp48 * tmp48);
  $Ploa1$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6))) + (((-$Ploa2_v_2SeedNLSJac6)) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (data->simulationInfo->realParameter[34]))) * ((tmp45 * tmp45) + (tmp46 * tmp46)),(tmp49 * tmp49),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 108
 type: SIMPLE_ASSIGN
 loa._i._2._$pDERNLSJac6._dummyVarNLSJac6 = (-loa2.v[2]) * (-loa.P_nominal) * DIVISION(2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - loa2_v_2SeedNLSJac6 * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_108(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,108};
  modelica_real tmp50;
  modelica_real tmp51;
  modelica_real tmp52;
  modelica_real tmp53;
  modelica_real tmp54;
  tmp50 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp51 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp52 = (tmp50 * tmp50) + (tmp51 * tmp51);
  tmp53 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp54 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $Ploa$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 = ((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[32])) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6)),(tmp52 * tmp52),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes))) - (($Ploa2_v_2SeedNLSJac6) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp53 * tmp53) + (tmp54 * tmp54),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 109
 type: SIMPLE_ASSIGN
 loa1._i._2._$pDERNLSJac6._dummyVarNLSJac6 = DIVISION((loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q) * 2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6) + (loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * loa1.Q - loa2_v_2SeedNLSJac6 * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_109(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,109};
  modelica_real tmp55;
  modelica_real tmp56;
  modelica_real tmp57;
  modelica_real tmp58;
  modelica_real tmp59;
  tmp55 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp56 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp57 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp58 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp59 = (tmp57 * tmp57) + (tmp58 * tmp58);
  $Ploa1$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6))) + (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (data->localData[0]->realVars[42] /* loa1._Q variable */) - (($Ploa2_v_2SeedNLSJac6) * (data->simulationInfo->realParameter[34]))) * ((tmp55 * tmp55) + (tmp56 * tmp56)),(tmp59 * tmp59),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 110
 type: SIMPLE_ASSIGN
 loa2._i._1._$pDERNLSJac6._dummyVarNLSJac6 = (-loa2.v[1]) * (-loa2.P_nominal) * DIVISION(2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_110(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,110};
  modelica_real tmp60;
  modelica_real tmp61;
  modelica_real tmp62;
  modelica_real tmp63;
  modelica_real tmp64;
  tmp60 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp61 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp62 = (tmp60 * tmp60) + (tmp61 * tmp61);
  tmp63 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp64 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $Ploa2$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = ((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[37])) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6)),(tmp62 * tmp62),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes))) - (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp63 * tmp63) + (tmp64 * tmp64),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 111
 type: SIMPLE_ASSIGN
 loa3._i._1._$pDERNLSJac6._dummyVarNLSJac6 = DIVISION((loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal) * 2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6) + ((-loa2_v_2SeedNLSJac6) * loa3.Q - loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_111(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,111};
  modelica_real tmp65;
  modelica_real tmp66;
  modelica_real tmp67;
  modelica_real tmp68;
  modelica_real tmp69;
  tmp65 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp66 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp67 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp68 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp69 = (tmp67 * tmp67) + (tmp68 * tmp68);
  $Ploa3$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6))) + (((-$Ploa2_v_2SeedNLSJac6)) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (data->simulationInfo->realParameter[39]))) * ((tmp65 * tmp65) + (tmp66 * tmp66)),(tmp69 * tmp69),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 112
 type: SIMPLE_ASSIGN
 loa2._i._2._$pDERNLSJac6._dummyVarNLSJac6 = (-loa2.v[2]) * (-loa2.P_nominal) * DIVISION(2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0) - loa2_v_2SeedNLSJac6 * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_112(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,112};
  modelica_real tmp70;
  modelica_real tmp71;
  modelica_real tmp72;
  modelica_real tmp73;
  modelica_real tmp74;
  tmp70 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp71 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp72 = (tmp70 * tmp70) + (tmp71 * tmp71);
  tmp73 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp74 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $Ploa2$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 = ((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * (((-data->simulationInfo->realParameter[37])) * (DIVISION_SIM((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6)),(tmp72 * tmp72),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes))) - (($Ploa2_v_2SeedNLSJac6) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp73 * tmp73) + (tmp74 * tmp74),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 113
 type: SIMPLE_ASSIGN
 loa3._i._2._$pDERNLSJac6._dummyVarNLSJac6 = DIVISION((loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q) * 2.0 * (loa2.v[1] * loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 + loa2.v[2] * loa2_v_2SeedNLSJac6) + (loa2.v.1.$pDERNLSJac6.dummyVarNLSJac6 * loa3.Q - loa2_v_2SeedNLSJac6 * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0)
 */
void LineFeederAndCapacitorTest_eqFunction_113(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,113};
  modelica_real tmp75;
  modelica_real tmp76;
  modelica_real tmp77;
  modelica_real tmp78;
  modelica_real tmp79;
  tmp75 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp76 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp77 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp78 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp79 = (tmp77 * tmp77) + (tmp78 * tmp78);
  $Ploa3$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 = DIVISION_SIM(((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * ((2.0) * ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * ($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) + (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * ($Ploa2_v_2SeedNLSJac6))) + (($Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * (data->localData[0]->realVars[65] /* loa3._Q variable */) - (($Ploa2_v_2SeedNLSJac6) * (data->simulationInfo->realParameter[39]))) * ((tmp75 * tmp75) + (tmp76 * tmp76)),(tmp79 * tmp79),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0",equationIndexes);
  TRACE_POP
}

/*
 equation index: 114
 type: SIMPLE_ASSIGN
 line1._line._line._i_p._1._$pDERNLSJac6._dummyVarNLSJac6 = (-loa.i.1.$pDERNLSJac6.dummyVarNLSJac6) - loa1.i.1.$pDERNLSJac6.dummyVarNLSJac6 - loa2.i.1.$pDERNLSJac6.dummyVarNLSJac6 - loa3.i.1.$pDERNLSJac6.dummyVarNLSJac6
 */
void LineFeederAndCapacitorTest_eqFunction_114(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,114};
  $Pline1$Pline$Pline$Pi_p$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = (-$Ploa$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6) - $Ploa1$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 - $Ploa2$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 - $Ploa3$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6;
  TRACE_POP
}

/*
 equation index: 115
 type: SIMPLE_ASSIGN
 $res._1._$pDERNLSJac6._dummyVarNLSJac6 = loa2_v_2SeedNLSJac6 - line1.line.line.i_p.1.$pDERNLSJac6.dummyVarNLSJac6 * line1.line.line.L * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_115(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,115};
  $P$res$P1$P$pDERNLSJac6$PdummyVarNLSJac6 = $Ploa2_v_2SeedNLSJac6 - (($Pline1$Pline$Pline$Pi_p$P1$P$pDERNLSJac6$PdummyVarNLSJac6) * ((data->simulationInfo->realParameter[22]) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */)));
  TRACE_POP
}

/*
 equation index: 116
 type: SIMPLE_ASSIGN
 $res._2._$pDERNLSJac6._dummyVarNLSJac6 = loa.i.2.$pDERNLSJac6.dummyVarNLSJac6 + loa1.i.2.$pDERNLSJac6.dummyVarNLSJac6 + line1_line_line_i_p_2SeedNLSJac6 + loa2.i.2.$pDERNLSJac6.dummyVarNLSJac6 + loa3.i.2.$pDERNLSJac6.dummyVarNLSJac6
 */
void LineFeederAndCapacitorTest_eqFunction_116(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,116};
  $P$res$P2$P$pDERNLSJac6$PdummyVarNLSJac6 = $Ploa$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 + $Ploa1$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 + $Pline1_line_line_i_p_2SeedNLSJac6 + $Ploa2$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 + $Ploa3$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6;
  TRACE_POP
}
int LineFeederAndCapacitorTest_functionJacNLSJac6_column(void* inData, threadData_t *threadData)
{
  TRACE_PUSH

  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_NLSJac6;
  LineFeederAndCapacitorTest_eqFunction_105(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_106(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_107(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_108(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_109(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_110(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_111(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_112(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_113(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_114(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_115(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_116(data, threadData);
  
  TRACE_POP
  return 0;
}

/*
 equation index: 50
 type: SIMPLE_ASSIGN
 der(loa2._v._2._$pDERLSJac5._dummyVarLSJac5) = line1.line.line.L * $DER_line1_line_line_i_p_1SeedLSJac5 * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_50(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,50};
  $P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5 = (data->simulationInfo->realParameter[22]) * (($P$DER_line1_line_line_i_p_1SeedLSJac5) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 51
 type: SIMPLE_ASSIGN
 der(loa._i._1._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((-loa2.v[1]) * loa.P_nominal * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0) + $DER_loa2_v_1SeedLSJac5 * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_51(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,51};
  modelica_real tmp80;
  modelica_real tmp81;
  modelica_real tmp82;
  modelica_real tmp83;
  modelica_real tmp84;
  modelica_real tmp85;
  modelica_real tmp86;
  modelica_real tmp87;
  tmp80 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp81 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp82 = (tmp80 * tmp80) + (tmp81 * tmp81);
  tmp83 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp84 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp85 = (tmp83 * tmp83) + (tmp84 * tmp84);
  tmp85 *= tmp85;tmp86 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp87 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM((((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ((data->simulationInfo->realParameter[32]) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp82 * tmp82)),(tmp85 * tmp85),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes) + ($P$DER_loa2_v_1SeedLSJac5) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp86 * tmp86) + (tmp87 * tmp87),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}

/*
 equation index: 52
 type: SIMPLE_ASSIGN
 der(loa._i._2._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((-loa2.v[2]) * loa.P_nominal * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0) + $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * DIVISION(loa.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_52(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,52};
  modelica_real tmp88;
  modelica_real tmp89;
  modelica_real tmp90;
  modelica_real tmp91;
  modelica_real tmp92;
  modelica_real tmp93;
  modelica_real tmp94;
  modelica_real tmp95;
  tmp88 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp89 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp90 = (tmp88 * tmp88) + (tmp89 * tmp89);
  tmp91 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp92 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp93 = (tmp91 * tmp91) + (tmp92 * tmp92);
  tmp93 *= tmp93;tmp94 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp95 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM((((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ((data->simulationInfo->realParameter[32]) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp90 * tmp90)),(tmp93 * tmp93),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes) + ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (DIVISION_SIM(data->simulationInfo->realParameter[32],(tmp94 * tmp94) + (tmp95 * tmp95),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}

/*
 equation index: 53
 type: SIMPLE_ASSIGN
 der(loa1._i._2._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((($DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * loa1.P_nominal - $DER_loa2_v_1SeedLSJac5 * loa1.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa1.P_nominal - loa2.v[1] * loa1.Q) * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5)) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_53(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,53};
  modelica_real tmp96;
  modelica_real tmp97;
  modelica_real tmp98;
  modelica_real tmp99;
  modelica_real tmp100;
  modelica_real tmp101;
  modelica_real tmp102;
  modelica_real tmp103;
  tmp96 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp97 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp98 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp99 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp100 = (tmp98 * tmp98) + (tmp99 * tmp99);
  tmp101 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp102 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp103 = (tmp101 * tmp101) + (tmp102 * tmp102);
  tmp103 *= tmp103;
  $P$DER$Ploa1$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM(((($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (data->simulationInfo->realParameter[34]) - (($P$DER_loa2_v_1SeedLSJac5) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * ((tmp96 * tmp96) + (tmp97 * tmp97)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[34]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp100 * tmp100)),(tmp103 * tmp103),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes), 0.0));
  TRACE_POP
}

/*
 equation index: 54
 type: SIMPLE_ASSIGN
 der(loa1._i._1._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((($DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * loa1.Q + $DER_loa2_v_1SeedLSJac5 * loa1.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa1.Q + loa2.v[1] * loa1.P_nominal) * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5)) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_54(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,54};
  modelica_real tmp104;
  modelica_real tmp105;
  modelica_real tmp106;
  modelica_real tmp107;
  modelica_real tmp108;
  modelica_real tmp109;
  modelica_real tmp110;
  modelica_real tmp111;
  tmp104 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp105 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp106 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp107 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp108 = (tmp106 * tmp106) + (tmp107 * tmp107);
  tmp109 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp110 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp111 = (tmp109 * tmp109) + (tmp110 * tmp110);
  tmp111 *= tmp111;
  $P$DER$Ploa1$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM(((($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + ($P$DER_loa2_v_1SeedLSJac5) * (data->simulationInfo->realParameter[34])) * ((tmp104 * tmp104) + (tmp105 * tmp105)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[42] /* loa1._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[34])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp108 * tmp108)),(tmp111 * tmp111),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes), 0.0));
  TRACE_POP
}

/*
 equation index: 55
 type: SIMPLE_ASSIGN
 der(loa2._i._1._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((-loa2.v[1]) * loa2.P_nominal * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0) + $DER_loa2_v_1SeedLSJac5 * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_55(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,55};
  modelica_real tmp112;
  modelica_real tmp113;
  modelica_real tmp114;
  modelica_real tmp115;
  modelica_real tmp116;
  modelica_real tmp117;
  modelica_real tmp118;
  modelica_real tmp119;
  tmp112 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp113 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp114 = (tmp112 * tmp112) + (tmp113 * tmp113);
  tmp115 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp116 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp117 = (tmp115 * tmp115) + (tmp116 * tmp116);
  tmp117 *= tmp117;tmp118 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp119 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa2$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM((((-data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ((data->simulationInfo->realParameter[37]) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp114 * tmp114)),(tmp117 * tmp117),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes) + ($P$DER_loa2_v_1SeedLSJac5) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp118 * tmp118) + (tmp119 * tmp119),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}

/*
 equation index: 56
 type: SIMPLE_ASSIGN
 der(loa2._i._2._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((-loa2.v[2]) * loa2.P_nominal * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0) + $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * DIVISION(loa2.P_nominal, loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_56(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,56};
  modelica_real tmp120;
  modelica_real tmp121;
  modelica_real tmp122;
  modelica_real tmp123;
  modelica_real tmp124;
  modelica_real tmp125;
  modelica_real tmp126;
  modelica_real tmp127;
  tmp120 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp121 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp122 = (tmp120 * tmp120) + (tmp121 * tmp121);
  tmp123 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp124 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp125 = (tmp123 * tmp123) + (tmp124 * tmp124);
  tmp125 *= tmp125;tmp126 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp127 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  $P$DER$Ploa2$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM((((-data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ((data->simulationInfo->realParameter[37]) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp122 * tmp122)),(tmp125 * tmp125),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes) + ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (DIVISION_SIM(data->simulationInfo->realParameter[37],(tmp126 * tmp126) + (tmp127 * tmp127),"loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0",equationIndexes)), 0.0));
  TRACE_POP
}

/*
 equation index: 57
 type: SIMPLE_ASSIGN
 der(loa3._i._1._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((($DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * loa3.Q + $DER_loa2_v_1SeedLSJac5 * loa3.P_nominal) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa3.Q + loa2.v[1] * loa3.P_nominal) * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5)) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_57(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,57};
  modelica_real tmp128;
  modelica_real tmp129;
  modelica_real tmp130;
  modelica_real tmp131;
  modelica_real tmp132;
  modelica_real tmp133;
  modelica_real tmp134;
  modelica_real tmp135;
  tmp128 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp129 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp130 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp131 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp132 = (tmp130 * tmp130) + (tmp131 * tmp131);
  tmp133 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp134 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp135 = (tmp133 * tmp133) + (tmp134 * tmp134);
  tmp135 *= tmp135;
  $P$DER$Ploa3$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM(((($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + ($P$DER_loa2_v_1SeedLSJac5) * (data->simulationInfo->realParameter[39])) * ((tmp128 * tmp128) + (tmp129 * tmp129)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */) + (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->simulationInfo->realParameter[39])) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp132 * tmp132)),(tmp135 * tmp135),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes), 0.0));
  TRACE_POP
}

/*
 equation index: 58
 type: SIMPLE_ASSIGN
 der(loa3._i._2._$pDERLSJac5._dummyVarLSJac5) = -homotopy(DIVISION((($DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5 * loa3.P_nominal - $DER_loa2_v_1SeedLSJac5 * loa3.Q) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) - (loa2.v[2] * loa3.P_nominal - loa2.v[1] * loa3.Q) * (2.0 * loa2.v[1] * $DER_loa2_v_1SeedLSJac5 + 2.0 * loa2.v[2] * $DER.loa2.v.2.$pDERLSJac5.dummyVarLSJac5)) * (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 2.0, (loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0), 0.0)
 */
void LineFeederAndCapacitorTest_eqFunction_58(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,58};
  modelica_real tmp136;
  modelica_real tmp137;
  modelica_real tmp138;
  modelica_real tmp139;
  modelica_real tmp140;
  modelica_real tmp141;
  modelica_real tmp142;
  modelica_real tmp143;
  tmp136 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp137 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp138 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp139 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp140 = (tmp138 * tmp138) + (tmp139 * tmp139);
  tmp141 = data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */;
  tmp142 = data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */;
  tmp143 = (tmp141 * tmp141) + (tmp142 * tmp142);
  tmp143 *= tmp143;
  $P$DER$Ploa3$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 = (-homotopy(DIVISION_SIM(((($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5) * (data->simulationInfo->realParameter[39]) - (($P$DER_loa2_v_1SeedLSJac5) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * ((tmp136 * tmp136) + (tmp137 * tmp137)) - (((data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */) * (data->simulationInfo->realParameter[39]) - ((data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */) * (data->localData[0]->realVars[65] /* loa3._Q variable */))) * (((2.0) * (data->localData[0]->realVars[61] /* loa2._v[1] DUMMY_STATE */)) * ($P$DER_loa2_v_1SeedLSJac5) + ((2.0) * (data->localData[0]->realVars[62] /* loa2._v[2] DUMMY_STATE */)) * ($P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5)))) * ((tmp140 * tmp140)),(tmp143 * tmp143),"(loa2.v[1] ^ 2.0 + loa2.v[2] ^ 2.0) ^ 4.0",equationIndexes), 0.0));
  TRACE_POP
}

/*
 equation index: 59
 type: SIMPLE_ASSIGN
 der(line1._line._line._i_p._2._$pDERLSJac5._dummyVarLSJac5) = (-$DER.loa.i.2.$pDERLSJac5.dummyVarLSJac5) - $DER.loa1.i.2.$pDERLSJac5.dummyVarLSJac5 - $DER.loa2.i.2.$pDERLSJac5.dummyVarLSJac5 - $DER.loa3.i.2.$pDERLSJac5.dummyVarLSJac5
 */
void LineFeederAndCapacitorTest_eqFunction_59(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,59};
  $P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac5$PdummyVarLSJac5 = (-$P$DER$Ploa$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5) - $P$DER$Ploa1$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 - $P$DER$Ploa2$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 - $P$DER$Ploa3$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5;
  TRACE_POP
}

/*
 equation index: 60
 type: SIMPLE_ASSIGN
 $res._1._$pDERLSJac5._dummyVarLSJac5 = $DER_loa2_v_1SeedLSJac5 + line1.line.line.L * $DER.line1.line.line.i_p.2.$pDERLSJac5.dummyVarLSJac5 * loa1.omega
 */
void LineFeederAndCapacitorTest_eqFunction_60(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,60};
  $P$res$P1$P$pDERLSJac5$PdummyVarLSJac5 = $P$DER_loa2_v_1SeedLSJac5 + (data->simulationInfo->realParameter[22]) * (($P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac5$PdummyVarLSJac5) * (data->localData[0]->realVars[50] /* loa1._omega DUMMY_STATE */));
  TRACE_POP
}

/*
 equation index: 61
 type: SIMPLE_ASSIGN
 $res._2._$pDERLSJac5._dummyVarLSJac5 = $DER.loa.i.1.$pDERLSJac5.dummyVarLSJac5 + $DER.loa1.i.1.$pDERLSJac5.dummyVarLSJac5 + $DER_line1_line_line_i_p_1SeedLSJac5 + $DER.loa2.i.1.$pDERLSJac5.dummyVarLSJac5 + $DER.loa3.i.1.$pDERLSJac5.dummyVarLSJac5
 */
void LineFeederAndCapacitorTest_eqFunction_61(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,61};
  $P$res$P2$P$pDERLSJac5$PdummyVarLSJac5 = $P$DER$Ploa$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 + $P$DER$Ploa1$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 + $P$DER_line1_line_line_i_p_1SeedLSJac5 + $P$DER$Ploa2$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 + $P$DER$Ploa3$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5;
  TRACE_POP
}
int LineFeederAndCapacitorTest_functionJacLSJac5_column(void* inData, threadData_t *threadData)
{
  TRACE_PUSH

  DATA* data = ((DATA*)inData);
  int index = LineFeederAndCapacitorTest_INDEX_JAC_LSJac5;
  LineFeederAndCapacitorTest_eqFunction_50(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_51(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_52(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_53(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_54(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_55(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_56(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_57(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_58(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_59(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_60(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_61(data, threadData);
  
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_functionJacA_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_functionJacB_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_functionJacC_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int LineFeederAndCapacitorTest_functionJacD_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}


