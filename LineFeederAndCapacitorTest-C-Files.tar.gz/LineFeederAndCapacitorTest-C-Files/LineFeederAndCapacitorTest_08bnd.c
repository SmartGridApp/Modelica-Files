/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "LineFeederAndCapacitorTest_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
 equation index: 160
 type: SIMPLE_ASSIGN
 $START._line1._line._line._i_p[2] = line1.line.line.i_start[2]
 */
void LineFeederAndCapacitorTest_eqFunction_160(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,160};
  data->modelData->realVarsData[33].attribute /* line1._line._line._i_p[2] DUMMY_STATE */.start = data->simulationInfo->realParameter[29];
    data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */ = data->modelData->realVarsData[33].attribute /* line1._line._line._i_p[2] DUMMY_STATE */.start;
    infoStreamPrint(LOG_INIT, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[33].info /* line1._line._line._i_p[2] */.name, (modelica_real) data->localData[0]->realVars[33] /* line1._line._line._i_p[2] DUMMY_STATE */);
  TRACE_POP
}

/*
 equation index: 161
 type: SIMPLE_ASSIGN
 $START._line1._line._line._i_p[1] = line1.line.line.i_start[1]
 */
void LineFeederAndCapacitorTest_eqFunction_161(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,161};
  data->modelData->realVarsData[32].attribute /* line1._line._line._i_p[1] DUMMY_STATE */.start = data->simulationInfo->realParameter[28];
    data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */ = data->modelData->realVarsData[32].attribute /* line1._line._line._i_p[1] DUMMY_STATE */.start;
    infoStreamPrint(LOG_INIT, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[32].info /* line1._line._line._i_p[1] */.name, (modelica_real) data->localData[0]->realVars[32] /* line1._line._line._i_p[1] DUMMY_STATE */);
  TRACE_POP
}
int LineFeederAndCapacitorTest_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  LineFeederAndCapacitorTest_eqFunction_160(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_161(data, threadData);
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}


/*
 equation index: 162
 type: SIMPLE_ASSIGN
 gri._sou._V = gri.V
 */
void LineFeederAndCapacitorTest_eqFunction_162(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,162};
  data->simulationInfo->realParameter[3] = data->simulationInfo->realParameter[0];
  TRACE_POP
}

/*
 equation index: 163
 type: SIMPLE_ASSIGN
 gri._sou._phiSou = gri.phiSou
 */
void LineFeederAndCapacitorTest_eqFunction_163(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,163};
  data->simulationInfo->realParameter[5] = data->simulationInfo->realParameter[2];
  TRACE_POP
}

/*
 equation index: 164
 type: SIMPLE_ASSIGN
 gri._terminal._v[2] = gri.sou.V * sin(gri.sou.phiSou)
 */
void LineFeederAndCapacitorTest_eqFunction_164(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,164};
  data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */ = (data->simulationInfo->realParameter[3]) * (sin(data->simulationInfo->realParameter[5]));
  TRACE_POP
}

/*
 equation index: 165
 type: SIMPLE_ASSIGN
 gri._terminal._v[1] = gri.sou.V * cos(gri.sou.phiSou)
 */
void LineFeederAndCapacitorTest_eqFunction_165(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,165};
  data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */ = (data->simulationInfo->realParameter[3]) * (cos(data->simulationInfo->realParameter[5]));
  TRACE_POP
}

/*
 equation index: 166
 type: SIMPLE_ASSIGN
 $cse1 = atan2(gri.terminal.v[2], gri.terminal.v[1])
 */
void LineFeederAndCapacitorTest_eqFunction_166(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,166};
  data->localData[0]->realVars[14] /* $cse1 variable */ = atan2(data->localData[0]->realVars[27] /* gri._terminal._v[2] variable */, data->localData[0]->realVars[26] /* gri._terminal._v[1] variable */);
  TRACE_POP
}

/*
 equation index: 167
 type: SIMPLE_ASSIGN
 line1._line._line._heatPort._Q_flow = -0.0
 */
void LineFeederAndCapacitorTest_eqFunction_167(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,167};
  data->localData[0]->realVars[31] /* line1._line._line._heatPort._Q_flow variable */ = -0.0;
  TRACE_POP
}

/*
 equation index: 168
 type: SIMPLE_ASSIGN
 loa3._use_pf_in = false
 */
void LineFeederAndCapacitorTest_eqFunction_168(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,168};
  data->simulationInfo->booleanParameter[10] = 0;
  TRACE_POP
}

/*
 equation index: 169
 type: SIMPLE_ASSIGN
 loa3._initMode = Buildings.Electrical.Types.InitMode.zero_current
 */
void LineFeederAndCapacitorTest_eqFunction_169(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,169};
  data->simulationInfo->integerParameter[11] = 1;
  TRACE_POP
}

/*
 equation index: 170
 type: SIMPLE_ASSIGN
 loa3._V_nominal = 110.0
 */
void LineFeederAndCapacitorTest_eqFunction_170(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,170};
  data->simulationInfo->realParameter[40] = 110.0;
  TRACE_POP
}

/*
 equation index: 171
 type: SIMPLE_ASSIGN
 loa3._mode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_171(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,171};
  data->simulationInfo->integerParameter[12] = 1;
  TRACE_POP
}

/*
 equation index: 172
 type: SIMPLE_ASSIGN
 loa3._linearized = false
 */
void LineFeederAndCapacitorTest_eqFunction_172(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,172};
  data->simulationInfo->booleanParameter[9] = 0;
  TRACE_POP
}

/*
 equation index: 173
 type: SIMPLE_ASSIGN
 loa2._initMode = Buildings.Electrical.Types.InitMode.zero_current
 */
void LineFeederAndCapacitorTest_eqFunction_173(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,173};
  data->simulationInfo->integerParameter[9] = 1;
  TRACE_POP
}

/*
 equation index: 174
 type: SIMPLE_ASSIGN
 loa2._V_nominal = 110.0
 */
void LineFeederAndCapacitorTest_eqFunction_174(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,174};
  data->simulationInfo->realParameter[38] = 110.0;
  TRACE_POP
}

/*
 equation index: 175
 type: SIMPLE_ASSIGN
 loa2._mode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_175(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,175};
  data->simulationInfo->integerParameter[10] = 1;
  TRACE_POP
}

/*
 equation index: 176
 type: SIMPLE_ASSIGN
 loa2._linearized = false
 */
void LineFeederAndCapacitorTest_eqFunction_176(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,176};
  data->simulationInfo->booleanParameter[8] = 0;
  TRACE_POP
}

/*
 equation index: 177
 type: SIMPLE_ASSIGN
 line1._line._line._mode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_177(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,177};
  data->simulationInfo->integerParameter[1] = 1;
  TRACE_POP
}

/*
 equation index: 178
 type: SIMPLE_ASSIGN
 line1._line._line._i_start[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_178(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,178};
  data->simulationInfo->realParameter[29] = 0.0;
  TRACE_POP
}

/*
 equation index: 179
 type: SIMPLE_ASSIGN
 line1._line._line._i_start[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_179(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,179};
  data->simulationInfo->realParameter[28] = 0.0;
  TRACE_POP
}

/*
 equation index: 180
 type: SIMPLE_ASSIGN
 line1._line._line._V_nominal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_180(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,180};
  data->simulationInfo->realParameter[27] = 0.0;
  TRACE_POP
}

/*
 equation index: 181
 type: SIMPLE_ASSIGN
 line1._line._L = 0.003183098861837907 * line1.line.l * line1.line.commercialCable.XCha
 */
void LineFeederAndCapacitorTest_eqFunction_181(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,181};
  data->simulationInfo->realParameter[7] = (0.003183098861837907) * ((data->simulationInfo->realParameter[20]) * (data->simulationInfo->realParameter[18]));
  TRACE_POP
}

/*
 equation index: 182
 type: SIMPLE_ASSIGN
 line1._line._line._L = 0.3333333333333333 * line1.line.L
 */
void LineFeederAndCapacitorTest_eqFunction_182(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,182};
  data->simulationInfo->realParameter[22] = (0.3333333333333333) * (data->simulationInfo->realParameter[7]);
  TRACE_POP
}

/*
 equation index: 183
 type: SIMPLE_ASSIGN
 line1._line._line._C = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_183(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,183};
  data->simulationInfo->realParameter[21] = 0.0;
  TRACE_POP
}

/*
 equation index: 184
 type: SIMPLE_ASSIGN
 line1._line._M = line1.line.commercialCable.M
 */
void LineFeederAndCapacitorTest_eqFunction_184(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,184};
  data->simulationInfo->realParameter[8] = data->simulationInfo->realParameter[15];
  TRACE_POP
}

/*
 equation index: 185
 type: SIMPLE_ASSIGN
 line1._line._line._M = line1.line.M
 */
void LineFeederAndCapacitorTest_eqFunction_185(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,185};
  data->simulationInfo->realParameter[23] = data->simulationInfo->realParameter[8];
  TRACE_POP
}

/*
 equation index: 186
 type: SIMPLE_ASSIGN
 line1._line._T_ref = line1.line.commercialCable.T_ref
 */
void LineFeederAndCapacitorTest_eqFunction_186(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,186};
  data->simulationInfo->realParameter[12] = data->simulationInfo->realParameter[17];
  TRACE_POP
}

/*
 equation index: 187
 type: SIMPLE_ASSIGN
 line1._line._line._T_ref = line1.line.T_ref
 */
void LineFeederAndCapacitorTest_eqFunction_187(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,187};
  data->simulationInfo->realParameter[26] = data->simulationInfo->realParameter[12];
  TRACE_POP
}

/*
 equation index: 188
 type: SIMPLE_ASSIGN
 line1._line._line._R = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_188(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,188};
  data->simulationInfo->realParameter[24] = 0.0;
  TRACE_POP
}

/*
 equation index: 189
 type: SIMPLE_ASSIGN
 line1._line._line._T = line1.line.line.T_ref
 */
void LineFeederAndCapacitorTest_eqFunction_189(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,189};
  data->simulationInfo->realParameter[25] = data->simulationInfo->realParameter[26];
  TRACE_POP
}

/*
 equation index: 190
 type: SIMPLE_ASSIGN
 line1._line._line._useHeatPort = true
 */
void LineFeederAndCapacitorTest_eqFunction_190(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,190};
  data->simulationInfo->booleanParameter[2] = 1;
  TRACE_POP
}

/*
 equation index: 191
 type: SIMPLE_ASSIGN
 line1._line._nominal_v_ = line1.line.V_nominal
 */
void LineFeederAndCapacitorTest_eqFunction_191(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,191};
  data->simulationInfo->realParameter[31] = data->simulationInfo->realParameter[13];
  TRACE_POP
}

/*
 equation index: 192
 type: SIMPLE_ASSIGN
 line1._line._nominal_i_ = DIVISION(line1.line.P_nominal, line1.line.V_nominal)
 */
void LineFeederAndCapacitorTest_eqFunction_192(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,192};
  data->simulationInfo->realParameter[30] = DIVISION_SIM(data->simulationInfo->realParameter[9],data->simulationInfo->realParameter[13],"line1.line.V_nominal",equationIndexes);
  TRACE_POP
}

/*
 equation index: 193
 type: SIMPLE_ASSIGN
 line1._line._n_ = 2
 */
void LineFeederAndCapacitorTest_eqFunction_193(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,193};
  data->simulationInfo->integerParameter[4] = ((modelica_integer) 2);
  TRACE_POP
}

/*
 equation index: 194
 type: SIMPLE_ASSIGN
 line1._line._C = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_194(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,194};
  data->simulationInfo->realParameter[6] = 0.0;
  TRACE_POP
}

/*
 equation index: 195
 type: SIMPLE_ASSIGN
 line1._line._R = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_195(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,195};
  data->simulationInfo->realParameter[10] = 0.0;
  TRACE_POP
}

/*
 equation index: 196
 type: SIMPLE_ASSIGN
 line1._line._commercialCable._RCha = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_196(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,196};
  data->simulationInfo->realParameter[16] = 0.0;
  TRACE_POP
}

/*
 equation index: 197
 type: SIMPLE_ASSIGN
 line1._line._mode = Buildings.Electrical.Types.CableMode.automatic
 */
void LineFeederAndCapacitorTest_eqFunction_197(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,197};
  data->simulationInfo->integerParameter[2] = 1;
  TRACE_POP
}

/*
 equation index: 198
 type: SIMPLE_ASSIGN
 line1._line._TCable = line1.line.T_ref
 */
void LineFeederAndCapacitorTest_eqFunction_198(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,198};
  data->simulationInfo->realParameter[11] = data->simulationInfo->realParameter[12];
  TRACE_POP
}

/*
 equation index: 199
 type: SIMPLE_ASSIGN
 line1._line._use_T = false
 */
void LineFeederAndCapacitorTest_eqFunction_199(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,199};
  data->simulationInfo->booleanParameter[4] = 0;
  TRACE_POP
}

/*
 equation index: 200
 type: SIMPLE_ASSIGN
 line1._line._modelMode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_200(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,200};
  data->simulationInfo->integerParameter[3] = 1;
  TRACE_POP
}

/*
 equation index: 201
 type: SIMPLE_ASSIGN
 line1._line._use_C = false
 */
void LineFeederAndCapacitorTest_eqFunction_201(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,201};
  data->simulationInfo->booleanParameter[3] = 0;
  TRACE_POP
}

/*
 equation index: 202
 type: SIMPLE_ASSIGN
 line1._line._f_n = 50.0
 */
void LineFeederAndCapacitorTest_eqFunction_202(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,202};
  data->simulationInfo->realParameter[19] = 50.0;
  TRACE_POP
}

/*
 equation index: 203
 type: SIMPLE_ASSIGN
 gri._sou._f = gri.f
 */
void LineFeederAndCapacitorTest_eqFunction_203(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,203};
  data->simulationInfo->realParameter[4] = data->simulationInfo->realParameter[1];
  TRACE_POP
}

/*
 equation index: 204
 type: SIMPLE_ASSIGN
 gri._sou._definiteReference = true
 */
void LineFeederAndCapacitorTest_eqFunction_204(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,204};
  data->simulationInfo->booleanParameter[0] = 1;
  TRACE_POP
}

/*
 equation index: 205
 type: SIMPLE_ASSIGN
 gri._sou._potentialReference = true
 */
void LineFeederAndCapacitorTest_eqFunction_205(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,205};
  data->simulationInfo->booleanParameter[1] = 1;
  TRACE_POP
}

/*
 equation index: 206
 type: SIMPLE_ASSIGN
 loa1._use_pf_in = false
 */
void LineFeederAndCapacitorTest_eqFunction_206(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,206};
  data->simulationInfo->booleanParameter[7] = 0;
  TRACE_POP
}

/*
 equation index: 207
 type: SIMPLE_ASSIGN
 loa1._initMode = Buildings.Electrical.Types.InitMode.zero_current
 */
void LineFeederAndCapacitorTest_eqFunction_207(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,207};
  data->simulationInfo->integerParameter[7] = 1;
  TRACE_POP
}

/*
 equation index: 208
 type: SIMPLE_ASSIGN
 loa1._V_nominal = 110.0
 */
void LineFeederAndCapacitorTest_eqFunction_208(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,208};
  data->simulationInfo->realParameter[35] = 110.0;
  TRACE_POP
}

/*
 equation index: 209
 type: SIMPLE_ASSIGN
 loa1._mode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_209(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,209};
  data->simulationInfo->integerParameter[8] = 1;
  TRACE_POP
}

/*
 equation index: 210
 type: SIMPLE_ASSIGN
 loa1._linearized = false
 */
void LineFeederAndCapacitorTest_eqFunction_210(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,210};
  data->simulationInfo->booleanParameter[6] = 0;
  TRACE_POP
}

/*
 equation index: 211
 type: SIMPLE_ASSIGN
 loa._initMode = Buildings.Electrical.Types.InitMode.zero_current
 */
void LineFeederAndCapacitorTest_eqFunction_211(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,211};
  data->simulationInfo->integerParameter[5] = 1;
  TRACE_POP
}

/*
 equation index: 212
 type: SIMPLE_ASSIGN
 loa._V_nominal = 110.0
 */
void LineFeederAndCapacitorTest_eqFunction_212(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,212};
  data->simulationInfo->realParameter[33] = 110.0;
  TRACE_POP
}

/*
 equation index: 213
 type: SIMPLE_ASSIGN
 loa._mode = Buildings.Electrical.Types.Load.FixedZ_steady_state
 */
void LineFeederAndCapacitorTest_eqFunction_213(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,213};
  data->simulationInfo->integerParameter[6] = 1;
  TRACE_POP
}

/*
 equation index: 214
 type: SIMPLE_ASSIGN
 loa._linearized = false
 */
void LineFeederAndCapacitorTest_eqFunction_214(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,214};
  data->simulationInfo->booleanParameter[5] = 0;
  TRACE_POP
}

/*
 equation index: 215
 type: SIMPLE_ASSIGN
 feeder2._i[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_215(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,215};
  data->localData[0]->realVars[19] /* feeder2._i[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 216
 type: SIMPLE_ASSIGN
 feeder2._i[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_216(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,216};
  data->localData[0]->realVars[18] /* feeder2._i[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 217
 type: SIMPLE_ASSIGN
 feeder1._i[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_217(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,217};
  data->localData[0]->realVars[17] /* feeder1._i[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 218
 type: SIMPLE_ASSIGN
 feeder1._i[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_218(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,218};
  data->localData[0]->realVars[16] /* feeder1._i[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 219
 type: SIMPLE_ASSIGN
 line1._line._line._R_actual = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_219(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,219};
  data->localData[0]->realVars[30] /* line1._line._line._R_actual variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 220
 type: SIMPLE_ASSIGN
 gri._sou._thetaRel = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_220(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,220};
  data->localData[0]->realVars[25] /* gri._sou._thetaRel variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 221
 type: SIMPLE_ASSIGN
 loa1._Q = loa1.P_nominal * tan(acos(loa1.pf))
 */
void LineFeederAndCapacitorTest_eqFunction_221(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,221};
  modelica_real tmp9;
  tmp9 = data->simulationInfo->realParameter[36];
  if(!(tmp9 >= -1.0 && tmp9 <= 1.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of acos(loa1.pf) outside the domain -1.0 <= %g <= 1.0", tmp9);
  }
  data->localData[0]->realVars[42] /* loa1._Q variable */ = (data->simulationInfo->realParameter[34]) * (tan(acos(tmp9)));
  TRACE_POP
}

/*
 equation index: 222
 type: SIMPLE_ASSIGN
 line1._line._cableTemp._port._Q_flow = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_222(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,222};
  data->localData[0]->realVars[29] /* line1._line._cableTemp._port._Q_flow variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 223
 type: SIMPLE_ASSIGN
 loa3._Q = loa3.P_nominal * tan(-acos(loa3.pf))
 */
void LineFeederAndCapacitorTest_eqFunction_223(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,223};
  modelica_real tmp10;
  tmp10 = data->simulationInfo->realParameter[41];
  if(!(tmp10 >= -1.0 && tmp10 <= 1.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of acos(loa3.pf) outside the domain -1.0 <= %g <= 1.0", tmp10);
  }
  data->localData[0]->realVars[65] /* loa3._Q variable */ = (data->simulationInfo->realParameter[39]) * (tan((-acos(tmp10))));
  TRACE_POP
}

/*
 equation index: 224
 type: SIMPLE_ASSIGN
 loa3._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_224(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,224};
  data->localData[0]->realVars[72] /* loa3._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 225
 type: SIMPLE_ASSIGN
 loa3._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_225(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,225};
  data->localData[0]->realVars[64] /* loa3._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 226
 type: SIMPLE_ASSIGN
 loa3._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_226(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,226};
  data->localData[0]->realVars[75] /* loa3._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 227
 type: SIMPLE_ASSIGN
 loa3._q[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_227(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,227};
  data->localData[0]->realVars[74] /* loa3._q[2] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 228
 type: SIMPLE_ASSIGN
 loa3._q[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_228(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,228};
  data->localData[0]->realVars[73] /* loa3._q[1] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 229
 type: SIMPLE_ASSIGN
 loa3._Y[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_229(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,229};
  data->localData[0]->realVars[69] /* loa3._Y[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 230
 type: SIMPLE_ASSIGN
 loa3._Y[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_230(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,230};
  data->localData[0]->realVars[68] /* loa3._Y[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 231
 type: SIMPLE_ASSIGN
 loa2._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_231(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,231};
  data->localData[0]->realVars[60] /* loa2._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 232
 type: SIMPLE_ASSIGN
 loa2._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_232(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,232};
  data->localData[0]->realVars[55] /* loa2._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 233
 type: SIMPLE_ASSIGN
 loa2._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_233(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,233};
  data->localData[0]->realVars[63] /* loa2._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 234
 type: SIMPLE_ASSIGN
 loa1._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_234(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,234};
  data->localData[0]->realVars[49] /* loa1._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 235
 type: SIMPLE_ASSIGN
 loa1._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_235(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,235};
  data->localData[0]->realVars[41] /* loa1._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 236
 type: SIMPLE_ASSIGN
 loa1._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_236(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,236};
  data->localData[0]->realVars[54] /* loa1._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 237
 type: SIMPLE_ASSIGN
 loa1._psi[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_237(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,237};
  data->localData[0]->realVars[52] /* loa1._psi[2] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 238
 type: SIMPLE_ASSIGN
 loa1._psi[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_238(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,238};
  data->localData[0]->realVars[51] /* loa1._psi[1] DUMMY_STATE */ = 0.0;
  TRACE_POP
}

/*
 equation index: 239
 type: SIMPLE_ASSIGN
 loa1._Z[2] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_239(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,239};
  data->localData[0]->realVars[46] /* loa1._Z[2] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 240
 type: SIMPLE_ASSIGN
 loa1._Z[1] = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_240(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,240};
  data->localData[0]->realVars[45] /* loa1._Z[1] variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 241
 type: SIMPLE_ASSIGN
 loa._load = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_241(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,241};
  data->localData[0]->realVars[39] /* loa._load variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 242
 type: SIMPLE_ASSIGN
 loa._P_internal = 0.0
 */
void LineFeederAndCapacitorTest_eqFunction_242(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,242};
  data->localData[0]->realVars[34] /* loa._P_internal variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 243
 type: SIMPLE_ASSIGN
 loa._y_internal = 1.0
 */
void LineFeederAndCapacitorTest_eqFunction_243(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,243};
  data->localData[0]->realVars[40] /* loa._y_internal variable */ = 1.0;
  TRACE_POP
}

/*
 equation index: 244
 type: ALGORITHM
 
   assert(loa3.pf >= 0.0 and loa3.pf <= 1.0, "Variable violating min/max constraint: 0.0 <= loa3.pf <= 1.0, has value: " + String(loa3.pf, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_244(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,244};
  modelica_boolean tmp11;
  modelica_boolean tmp12;
  static const MMC_DEFSTRINGLIT(tmp13,73,"Variable violating min/max constraint: 0.0 <= loa3.pf <= 1.0, has value: ");
  modelica_string tmp14;
  static int tmp15 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp15)
  {
    tmp11 = GreaterEq(data->simulationInfo->realParameter[41],0.0);
    tmp12 = LessEq(data->simulationInfo->realParameter[41],1.0);
    if(!(tmp11 && tmp12))
    {
      tmp14 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[41], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp13),tmp14);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/CapacitiveLoad.mo",6,3,7,49,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa3.pf >= 0.0 and loa3.pf <= 1.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp15 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 245
 type: ALGORITHM
 
   assert(loa3.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa3.initMode <= Buildings.Electrical.Types.InitMode.linearized, "Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa3.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: " + String(loa3.initMode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_245(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,245};
  modelica_boolean tmp16;
  modelica_boolean tmp17;
  static const MMC_DEFSTRINGLIT(tmp18,167,"Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa3.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: ");
  modelica_string tmp19;
  static int tmp20 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp20)
  {
    tmp16 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[11],1);
    tmp17 = LessEq((modelica_integer)data->simulationInfo->integerParameter[11],2);
    if(!(tmp16 && tmp17))
    {
      tmp19 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[11], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp18),tmp19);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",26,3,29,92,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa3.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa3.initMode <= Buildings.Electrical.Types.InitMode.linearized", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp20 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 246
 type: ALGORITHM
 
   assert(loa3.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= loa3.V_nominal, has value: " + String(loa3.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_246(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,246};
  modelica_boolean tmp21;
  static const MMC_DEFSTRINGLIT(tmp22,69,"Variable violating min constraint: 0.0 <= loa3.V_nominal, has value: ");
  modelica_string tmp23;
  static int tmp24 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp24)
  {
    tmp21 = GreaterEq(data->simulationInfo->realParameter[40],0.0);
    if(!tmp21)
    {
      tmp23 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[40], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp22),tmp23);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",20,3,25,86,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa3.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp24 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 247
 type: ALGORITHM
 
   assert(loa3.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa3.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa3.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: " + String(loa3.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_247(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,247};
  modelica_boolean tmp25;
  modelica_boolean tmp26;
  static const MMC_DEFSTRINGLIT(tmp27,169,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa3.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: ");
  modelica_string tmp28;
  static int tmp29 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp29)
  {
    tmp25 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[12],1);
    tmp26 = LessEq((modelica_integer)data->simulationInfo->integerParameter[12],4);
    if(!(tmp25 && tmp26))
    {
      tmp28 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[12], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp27),tmp28);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",9,3,13,68,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa3.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa3.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp29 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 248
 type: ALGORITHM
 
   assert(loa2.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa2.initMode <= Buildings.Electrical.Types.InitMode.linearized, "Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa2.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: " + String(loa2.initMode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_248(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,248};
  modelica_boolean tmp30;
  modelica_boolean tmp31;
  static const MMC_DEFSTRINGLIT(tmp32,167,"Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa2.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: ");
  modelica_string tmp33;
  static int tmp34 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp34)
  {
    tmp30 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[9],1);
    tmp31 = LessEq((modelica_integer)data->simulationInfo->integerParameter[9],2);
    if(!(tmp30 && tmp31))
    {
      tmp33 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[9], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp32),tmp33);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",26,3,29,92,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa2.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa2.initMode <= Buildings.Electrical.Types.InitMode.linearized", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp34 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 249
 type: ALGORITHM
 
   assert(loa2.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= loa2.V_nominal, has value: " + String(loa2.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_249(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,249};
  modelica_boolean tmp35;
  static const MMC_DEFSTRINGLIT(tmp36,69,"Variable violating min constraint: 0.0 <= loa2.V_nominal, has value: ");
  modelica_string tmp37;
  static int tmp38 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp38)
  {
    tmp35 = GreaterEq(data->simulationInfo->realParameter[38],0.0);
    if(!tmp35)
    {
      tmp37 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[38], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp36),tmp37);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",20,3,25,86,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa2.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp38 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 250
 type: ALGORITHM
 
   assert(loa2.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa2.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa2.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: " + String(loa2.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_250(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,250};
  modelica_boolean tmp39;
  modelica_boolean tmp40;
  static const MMC_DEFSTRINGLIT(tmp41,169,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa2.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: ");
  modelica_string tmp42;
  static int tmp43 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp43)
  {
    tmp39 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[10],1);
    tmp40 = LessEq((modelica_integer)data->simulationInfo->integerParameter[10],4);
    if(!(tmp39 && tmp40))
    {
      tmp42 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[10], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp41),tmp42);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",9,3,13,68,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa2.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa2.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp43 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 251
 type: ALGORITHM
 
   assert(line1.line.line.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and line1.line.line.mode <= Buildings.Electrical.Types.Load.FixedZ_dynamic, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= line1.line.line.mode <= Buildings.Electrical.Types.Load.FixedZ_dynamic, has value: " + String(line1.line.line.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_251(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,251};
  modelica_boolean tmp44;
  modelica_boolean tmp45;
  static const MMC_DEFSTRINGLIT(tmp46,177,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= line1.line.line.mode <= Buildings.Electrical.Types.Load.FixedZ_dynamic, has value: ");
  modelica_string tmp47;
  static int tmp48 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp48)
  {
    tmp44 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[1],1);
    tmp45 = LessEq((modelica_integer)data->simulationInfo->integerParameter[1],2);
    if(!(tmp44 && tmp45))
    {
      tmp47 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[1], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp46),tmp47);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/AC/OnePhase/Lines/TwoPortRL.mo",14,3,19,68,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and line1.line.line.mode <= Buildings.Electrical.Types.Load.FixedZ_dynamic", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp48 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 252
 type: ALGORITHM
 
   assert(line1.line.line.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.line.V_nominal, has value: " + String(line1.line.line.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_252(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,252};
  modelica_boolean tmp49;
  static const MMC_DEFSTRINGLIT(tmp50,80,"Variable violating min constraint: 0.0 <= line1.line.line.V_nominal, has value: ");
  modelica_string tmp51;
  static int tmp52 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp52)
  {
    tmp49 = GreaterEq(data->simulationInfo->realParameter[27],0.0);
    if(!tmp49)
    {
      tmp51 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[27], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp50),tmp51);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialTwoPortRLC.mo",13,3,14,87,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp52 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 253
 type: ALGORITHM
 
   assert(line1.line.l >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.l, has value: " + String(line1.line.l, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_253(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,253};
  modelica_boolean tmp53;
  static const MMC_DEFSTRINGLIT(tmp54,67,"Variable violating min constraint: 0.0 <= line1.line.l, has value: ");
  modelica_string tmp55;
  static int tmp56 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp56)
  {
    tmp53 = GreaterEq(data->simulationInfo->realParameter[20],0.0);
    if(!tmp53)
    {
      tmp55 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[20], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp54),tmp55);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",3,3,3,66,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.l >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp56 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 254
 type: ALGORITHM
 
   assert(line1.line.line.C >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.line.C, has value: " + String(line1.line.line.C, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_254(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,254};
  modelica_boolean tmp57;
  static const MMC_DEFSTRINGLIT(tmp58,72,"Variable violating min constraint: 0.0 <= line1.line.line.C, has value: ");
  modelica_string tmp59;
  static int tmp60 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp60)
  {
    tmp57 = GreaterEq(data->simulationInfo->realParameter[21],0.0);
    if(!tmp57)
    {
      tmp59 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[21], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp58),tmp59);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialTwoPortRLC.mo",11,3,11,54,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.C >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp60 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 255
 type: ALGORITHM
 
   assert(line1.line.commercialCable.M >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.commercialCable.M, has value: " + String(line1.line.commercialCable.M, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_255(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,255};
  modelica_boolean tmp61;
  static const MMC_DEFSTRINGLIT(tmp62,83,"Variable violating min constraint: 0.0 <= line1.line.commercialCable.M, has value: ");
  modelica_string tmp63;
  static int tmp64 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp64)
  {
    tmp61 = GreaterEq(data->simulationInfo->realParameter[15],0.0);
    if(!tmp61)
    {
      tmp63 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[15], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp62),tmp63);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/BaseCable.mo",9,3,10,43,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.commercialCable.M >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp64 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 256
 type: ALGORITHM
 
   assert(line1.line.M >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.M, has value: " + String(line1.line.M, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_256(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,256};
  modelica_boolean tmp65;
  static const MMC_DEFSTRINGLIT(tmp66,67,"Variable violating min constraint: 0.0 <= line1.line.M, has value: ");
  modelica_string tmp67;
  static int tmp68 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp68)
  {
    tmp65 = GreaterEq(data->simulationInfo->realParameter[8],0.0);
    if(!tmp65)
    {
      tmp67 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[8], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp66),tmp67);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",37,3,38,71,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.M >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp68 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 257
 type: ALGORITHM
 
   assert(line1.line.line.M >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.line.M, has value: " + String(line1.line.line.M, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_257(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,257};
  modelica_boolean tmp69;
  static const MMC_DEFSTRINGLIT(tmp70,72,"Variable violating min constraint: 0.0 <= line1.line.line.M, has value: ");
  modelica_string tmp71;
  static int tmp72 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp72)
  {
    tmp69 = GreaterEq(data->simulationInfo->realParameter[23],0.0);
    if(!tmp69)
    {
      tmp71 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[23], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp70),tmp71);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialTwoPortRLC.mo",9,3,10,71,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.M >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp72 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 258
 type: ALGORITHM
 
   assert(line1.line.commercialCable.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.commercialCable.T_ref, has value: " + String(line1.line.commercialCable.T_ref, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_258(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,258};
  modelica_boolean tmp73;
  static const MMC_DEFSTRINGLIT(tmp74,87,"Variable violating min constraint: 0.0 <= line1.line.commercialCable.T_ref, has value: ");
  modelica_string tmp75;
  static int tmp76 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp76)
  {
    tmp73 = GreaterEq(data->simulationInfo->realParameter[17],0.0);
    if(!tmp73)
    {
      tmp75 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[17], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp74),tmp75);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/BaseCable.mo",7,3,8,34,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.commercialCable.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp76 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 259
 type: ALGORITHM
 
   assert(line1.line.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.T_ref, has value: " + String(line1.line.T_ref, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_259(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,259};
  modelica_boolean tmp77;
  static const MMC_DEFSTRINGLIT(tmp78,71,"Variable violating min constraint: 0.0 <= line1.line.T_ref, has value: ");
  modelica_string tmp79;
  static int tmp80 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp80)
  {
    tmp77 = GreaterEq(data->simulationInfo->realParameter[12],0.0);
    if(!tmp77)
    {
      tmp79 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[12], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp78),tmp79);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",35,3,36,66,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp80 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 260
 type: ALGORITHM
 
   assert(line1.line.line.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.line.T_ref, has value: " + String(line1.line.line.T_ref, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_260(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,260};
  modelica_boolean tmp81;
  static const MMC_DEFSTRINGLIT(tmp82,76,"Variable violating min constraint: 0.0 <= line1.line.line.T_ref, has value: ");
  modelica_string tmp83;
  static int tmp84 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp84)
  {
    tmp81 = GreaterEq(data->simulationInfo->realParameter[26],0.0);
    if(!tmp81)
    {
      tmp83 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[26], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp82),tmp83);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialTwoPortRLC.mo",8,3,8,80,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp84 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 261
 type: ALGORITHM
 
   assert(line1.line.line.T >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.line.T, has value: " + String(line1.line.line.T, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_261(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,261};
  modelica_boolean tmp85;
  static const MMC_DEFSTRINGLIT(tmp86,72,"Variable violating min constraint: 0.0 <= line1.line.line.T, has value: ");
  modelica_string tmp87;
  static int tmp88 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp88)
  {
    tmp85 = GreaterEq(data->simulationInfo->realParameter[25],0.0);
    if(!tmp85)
    {
      tmp87 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[25], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp86),tmp87);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.line.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp88 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 262
 type: ALGORITHM
 
   assert(line1.line.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.V_nominal, has value: " + String(line1.line.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_262(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,262};
  modelica_boolean tmp89;
  static const MMC_DEFSTRINGLIT(tmp90,75,"Variable violating min constraint: 0.0 <= line1.line.V_nominal, has value: ");
  modelica_string tmp91;
  static int tmp92 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp92)
  {
    tmp89 = GreaterEq(data->simulationInfo->realParameter[13],0.0);
    if(!tmp89)
    {
      tmp91 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[13], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp90),tmp91);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",5,3,6,34,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp92 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 263
 type: ALGORITHM
 
   assert(line1.line.P_nominal >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.P_nominal, has value: " + String(line1.line.P_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_263(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,263};
  modelica_boolean tmp93;
  static const MMC_DEFSTRINGLIT(tmp94,75,"Variable violating min constraint: 0.0 <= line1.line.P_nominal, has value: ");
  modelica_string tmp95;
  static int tmp96 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp96)
  {
    tmp93 = GreaterEq(data->simulationInfo->realParameter[9],0.0);
    if(!tmp93)
    {
      tmp95 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[9], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp94),tmp95);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",4,3,4,80,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.P_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp96 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 264
 type: ALGORITHM
 
   assert(line1.line.C >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.C, has value: " + String(line1.line.C, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_264(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,264};
  modelica_boolean tmp97;
  static const MMC_DEFSTRINGLIT(tmp98,67,"Variable violating min constraint: 0.0 <= line1.line.C, has value: ");
  modelica_string tmp99;
  static int tmp100 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp100)
  {
    tmp97 = GreaterEq(data->simulationInfo->realParameter[6],0.0);
    if(!tmp97)
    {
      tmp99 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[6], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp98),tmp99);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",43,3,44,59,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.C >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp100 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 265
 type: ALGORITHM
 
   assert(line1.line.commercialCable.material >= Buildings.Electrical.Transmission.Types.Material.Cu and line1.line.commercialCable.material <= Buildings.Electrical.Transmission.Types.Material.Al, "Variable violating min/max constraint: Buildings.Electrical.Transmission.Types.Material.Cu <= line1.line.commercialCable.material <= Buildings.Electrical.Transmission.Types.Material.Al, has value: " + String(line1.line.commercialCable.material, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_265(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,265};
  modelica_boolean tmp101;
  modelica_boolean tmp102;
  static const MMC_DEFSTRINGLIT(tmp103,197,"Variable violating min/max constraint: Buildings.Electrical.Transmission.Types.Material.Cu <= line1.line.commercialCable.material <= Buildings.Electrical.Transmission.Types.Material.Al, has value: ");
  modelica_string tmp104;
  static int tmp105 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp105)
  {
    tmp101 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[0],1);
    tmp102 = LessEq((modelica_integer)data->simulationInfo->integerParameter[0],2);
    if(!(tmp101 && tmp102))
    {
      tmp104 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[0], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp103),tmp104);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/BaseCable.mo",3,3,4,28,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.commercialCable.material >= Buildings.Electrical.Transmission.Types.Material.Cu and line1.line.commercialCable.material <= Buildings.Electrical.Transmission.Types.Material.Al", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp105 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 266
 type: ALGORITHM
 
   assert(line1.line.mode >= Buildings.Electrical.Types.CableMode.automatic and line1.line.mode <= Buildings.Electrical.Types.CableMode.commercial, "Variable violating min/max constraint: Buildings.Electrical.Types.CableMode.automatic <= line1.line.mode <= Buildings.Electrical.Types.CableMode.commercial, has value: " + String(line1.line.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_266(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,266};
  modelica_boolean tmp106;
  modelica_boolean tmp107;
  static const MMC_DEFSTRINGLIT(tmp108,168,"Variable violating min/max constraint: Buildings.Electrical.Types.CableMode.automatic <= line1.line.mode <= Buildings.Electrical.Types.CableMode.commercial, has value: ");
  modelica_string tmp109;
  static int tmp110 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp110)
  {
    tmp106 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[2],1);
    tmp107 = LessEq((modelica_integer)data->simulationInfo->integerParameter[2],2);
    if(!(tmp106 && tmp107))
    {
      tmp109 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[2], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp108),tmp109);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",22,3,24,116,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.mode >= Buildings.Electrical.Types.CableMode.automatic and line1.line.mode <= Buildings.Electrical.Types.CableMode.commercial", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp110 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 267
 type: ALGORITHM
 
   assert(line1.line.TCable >= 0.0, "Variable violating min constraint: 0.0 <= line1.line.TCable, has value: " + String(line1.line.TCable, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_267(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,267};
  modelica_boolean tmp111;
  static const MMC_DEFSTRINGLIT(tmp112,72,"Variable violating min constraint: 0.0 <= line1.line.TCable, has value: ");
  modelica_string tmp113;
  static int tmp114 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp114)
  {
    tmp111 = GreaterEq(data->simulationInfo->realParameter[11],0.0);
    if(!tmp111)
    {
      tmp113 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[11], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp112),tmp113);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",19,3,20,106,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.TCable >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp114 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 268
 type: ALGORITHM
 
   assert(line1.line.modelMode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and line1.line.modelMode <= Buildings.Electrical.Types.Load.VariableZ_y_input, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= line1.line.modelMode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: " + String(line1.line.modelMode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_268(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,268};
  modelica_boolean tmp115;
  modelica_boolean tmp116;
  static const MMC_DEFSTRINGLIT(tmp117,180,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= line1.line.modelMode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: ");
  modelica_string tmp118;
  static int tmp119 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp119)
  {
    tmp115 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[3],1);
    tmp116 = LessEq((modelica_integer)data->simulationInfo->integerParameter[3],4);
    if(!(tmp115 && tmp116))
    {
      tmp118 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[3], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp117),tmp118);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Transmission/BaseClasses/PartialBaseLine.mo",13,3,16,90,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nline1.line.modelMode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and line1.line.modelMode <= Buildings.Electrical.Types.Load.VariableZ_y_input", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp119 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 269
 type: ALGORITHM
 
   assert(loa1.pf >= 0.0 and loa1.pf <= 1.0, "Variable violating min/max constraint: 0.0 <= loa1.pf <= 1.0, has value: " + String(loa1.pf, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_269(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,269};
  modelica_boolean tmp120;
  modelica_boolean tmp121;
  static const MMC_DEFSTRINGLIT(tmp122,73,"Variable violating min/max constraint: 0.0 <= loa1.pf <= 1.0, has value: ");
  modelica_string tmp123;
  static int tmp124 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp124)
  {
    tmp120 = GreaterEq(data->simulationInfo->realParameter[36],0.0);
    tmp121 = LessEq(data->simulationInfo->realParameter[36],1.0);
    if(!(tmp120 && tmp121))
    {
      tmp123 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[36], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp122),tmp123);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/InductiveLoad.mo",6,3,7,49,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa1.pf >= 0.0 and loa1.pf <= 1.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp124 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 270
 type: ALGORITHM
 
   assert(loa1.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa1.initMode <= Buildings.Electrical.Types.InitMode.linearized, "Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa1.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: " + String(loa1.initMode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_270(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,270};
  modelica_boolean tmp125;
  modelica_boolean tmp126;
  static const MMC_DEFSTRINGLIT(tmp127,167,"Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa1.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: ");
  modelica_string tmp128;
  static int tmp129 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp129)
  {
    tmp125 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[7],1);
    tmp126 = LessEq((modelica_integer)data->simulationInfo->integerParameter[7],2);
    if(!(tmp125 && tmp126))
    {
      tmp128 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[7], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp127),tmp128);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",26,3,29,92,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa1.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa1.initMode <= Buildings.Electrical.Types.InitMode.linearized", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp129 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 271
 type: ALGORITHM
 
   assert(loa1.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= loa1.V_nominal, has value: " + String(loa1.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_271(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,271};
  modelica_boolean tmp130;
  static const MMC_DEFSTRINGLIT(tmp131,69,"Variable violating min constraint: 0.0 <= loa1.V_nominal, has value: ");
  modelica_string tmp132;
  static int tmp133 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp133)
  {
    tmp130 = GreaterEq(data->simulationInfo->realParameter[35],0.0);
    if(!tmp130)
    {
      tmp132 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[35], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp131),tmp132);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",20,3,25,86,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa1.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp133 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 272
 type: ALGORITHM
 
   assert(loa1.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa1.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa1.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: " + String(loa1.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_272(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,272};
  modelica_boolean tmp134;
  modelica_boolean tmp135;
  static const MMC_DEFSTRINGLIT(tmp136,169,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa1.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: ");
  modelica_string tmp137;
  static int tmp138 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp138)
  {
    tmp134 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[8],1);
    tmp135 = LessEq((modelica_integer)data->simulationInfo->integerParameter[8],4);
    if(!(tmp134 && tmp135))
    {
      tmp137 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[8], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp136),tmp137);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",9,3,13,68,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa1.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa1.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp138 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 273
 type: ALGORITHM
 
   assert(loa.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa.initMode <= Buildings.Electrical.Types.InitMode.linearized, "Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: " + String(loa.initMode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_273(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,273};
  modelica_boolean tmp139;
  modelica_boolean tmp140;
  static const MMC_DEFSTRINGLIT(tmp141,166,"Variable violating min/max constraint: Buildings.Electrical.Types.InitMode.zero_current <= loa.initMode <= Buildings.Electrical.Types.InitMode.linearized, has value: ");
  modelica_string tmp142;
  static int tmp143 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp143)
  {
    tmp139 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[5],1);
    tmp140 = LessEq((modelica_integer)data->simulationInfo->integerParameter[5],2);
    if(!(tmp139 && tmp140))
    {
      tmp142 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[5], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp141),tmp142);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",26,3,29,92,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa.initMode >= Buildings.Electrical.Types.InitMode.zero_current and loa.initMode <= Buildings.Electrical.Types.InitMode.linearized", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp143 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 274
 type: ALGORITHM
 
   assert(loa.V_nominal >= 0.0, "Variable violating min constraint: 0.0 <= loa.V_nominal, has value: " + String(loa.V_nominal, "g"));
 */
void LineFeederAndCapacitorTest_eqFunction_274(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,274};
  modelica_boolean tmp144;
  static const MMC_DEFSTRINGLIT(tmp145,68,"Variable violating min constraint: 0.0 <= loa.V_nominal, has value: ");
  modelica_string tmp146;
  static int tmp147 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp147)
  {
    tmp144 = GreaterEq(data->simulationInfo->realParameter[33],0.0);
    if(!tmp144)
    {
      tmp146 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[33], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp145),tmp146);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",20,3,25,86,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa.V_nominal >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp147 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 275
 type: ALGORITHM
 
   assert(loa.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, "Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: " + String(loa.mode, "d"));
 */
void LineFeederAndCapacitorTest_eqFunction_275(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,275};
  modelica_boolean tmp148;
  modelica_boolean tmp149;
  static const MMC_DEFSTRINGLIT(tmp150,168,"Variable violating min/max constraint: Buildings.Electrical.Types.Load.FixedZ_steady_state <= loa.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input, has value: ");
  modelica_string tmp151;
  static int tmp152 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp152)
  {
    tmp148 = GreaterEq((modelica_integer)data->simulationInfo->integerParameter[6],1);
    tmp149 = LessEq((modelica_integer)data->simulationInfo->integerParameter[6],4);
    if(!(tmp148 && tmp149))
    {
      tmp151 = modelica_integer_to_modelica_string_format((modelica_integer)data->simulationInfo->integerParameter[6], (modelica_string) mmc_strings_len1[100]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp150),tmp151);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Buildings/Electrical/Interfaces/Load.mo",9,3,13,68,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nloa.mode >= Buildings.Electrical.Types.Load.FixedZ_steady_state and loa.mode <= Buildings.Electrical.Types.Load.VariableZ_y_input", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp152 = 1;
    }
  }
  TRACE_POP
}
int LineFeederAndCapacitorTest_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  LineFeederAndCapacitorTest_eqFunction_162(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_163(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_164(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_165(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_166(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_167(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_168(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_169(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_170(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_171(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_172(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_173(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_174(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_175(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_176(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_177(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_178(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_179(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_180(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_181(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_182(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_183(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_184(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_185(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_186(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_187(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_188(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_189(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_190(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_191(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_192(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_193(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_194(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_195(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_196(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_197(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_198(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_199(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_200(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_201(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_202(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_203(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_204(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_205(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_206(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_207(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_208(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_209(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_210(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_211(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_212(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_213(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_214(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_215(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_216(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_217(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_218(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_219(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_220(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_221(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_222(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_223(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_224(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_225(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_226(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_227(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_228(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_229(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_230(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_231(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_232(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_233(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_234(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_235(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_236(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_237(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_238(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_239(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_240(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_241(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_242(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_243(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_244(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_245(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_246(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_247(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_248(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_249(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_250(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_251(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_252(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_253(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_254(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_255(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_256(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_257(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_258(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_259(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_260(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_261(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_262(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_263(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_264(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_265(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_266(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_267(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_268(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_269(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_270(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_271(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_272(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_273(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_274(data, threadData);

  LineFeederAndCapacitorTest_eqFunction_275(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

