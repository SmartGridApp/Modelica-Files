/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;
/* Jacobian Variables */
#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_LSJac7 2
  int LineFeederAndCapacitorTest_functionJacLSJac7_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac7(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* LSJac7 */
#define $P$DER_loa2_v_1SeedLSJac7 data->simulationInfo->analyticJacobians[2].seedVars[0]
#define $P$DER_line1_line_line_i_p_1SeedLSJac7 data->simulationInfo->analyticJacobians[2].seedVars[1]
#define _$P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[0]
#define $P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[1]
#define $P$DER$Ploa$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa2$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[2]
#define $P$DER$Ploa2$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa2$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa3$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[3]
#define $P$DER$Ploa3$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa3$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa1$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[4]
#define $P$DER$Ploa1$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa1$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa1$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[5]
#define $P$DER$Ploa1$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa1$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa3$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[6]
#define $P$DER$Ploa3$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa3$Pi$P1$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa2$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[7]
#define $P$DER$Ploa2$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa2$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[8]
#define $P$DER$Ploa$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa$Pi$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].tmpVars[9]
#define $P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$DER$Ploa2$Pv$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$res$P2$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].resultVars[1]
#define $P$res$P2$P$pDERLSJac7$PdummyVarLSJac7 _$P$res$P2$P$pDERLSJac7$PdummyVarLSJac7(0)

#define _$P$res$P1$P$pDERLSJac7$PdummyVarLSJac7(i) data->simulationInfo->analyticJacobians[2].resultVars[0]
#define $P$res$P1$P$pDERLSJac7$PdummyVarLSJac7 _$P$res$P1$P$pDERLSJac7$PdummyVarLSJac7(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_NLSJac6 1
  int LineFeederAndCapacitorTest_functionJacNLSJac6_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianNLSJac6(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* NLSJac6 */
#define $Ploa2_v_2SeedNLSJac6 data->simulationInfo->analyticJacobians[1].seedVars[0]
#define $Pline1_line_line_i_p_2SeedNLSJac6 data->simulationInfo->analyticJacobians[1].seedVars[1]
#define _$Pline1$Pline$Pline$Pi_p$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[0]
#define $Pline1$Pline$Pline$Pi_p$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Pline1$Pline$Pline$Pi_p$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa3$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[1]
#define $Ploa3$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa3$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa2$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[2]
#define $Ploa2$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa2$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa3$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[3]
#define $Ploa3$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa3$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa2$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[4]
#define $Ploa2$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa2$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa1$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[5]
#define $Ploa1$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa1$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[6]
#define $Ploa$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa$Pi$P2$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa1$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[7]
#define $Ploa1$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa1$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[8]
#define $Ploa$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa$Pi$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].tmpVars[9]
#define $Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$Ploa2$Pv$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$P$res$P2$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].resultVars[1]
#define $P$res$P2$P$pDERNLSJac6$PdummyVarNLSJac6 _$P$res$P2$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#define _$P$res$P1$P$pDERNLSJac6$PdummyVarNLSJac6(i) data->simulationInfo->analyticJacobians[1].resultVars[0]
#define $P$res$P1$P$pDERNLSJac6$PdummyVarNLSJac6 _$P$res$P1$P$pDERNLSJac6$PdummyVarNLSJac6(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_LSJac5 0
  int LineFeederAndCapacitorTest_functionJacLSJac5_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianLSJac5(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* LSJac5 */
#define $P$DER_loa2_v_1SeedLSJac5 data->simulationInfo->analyticJacobians[0].seedVars[0]
#define $P$DER_line1_line_line_i_p_1SeedLSJac5 data->simulationInfo->analyticJacobians[0].seedVars[1]
#define _$P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[0]
#define $P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Pline1$Pline$Pline$Pi_p$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa3$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[1]
#define $P$DER$Ploa3$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa3$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa3$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[2]
#define $P$DER$Ploa3$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa3$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa2$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[3]
#define $P$DER$Ploa2$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa2$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa2$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[4]
#define $P$DER$Ploa2$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa2$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa1$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[5]
#define $P$DER$Ploa1$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa1$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa1$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[6]
#define $P$DER$Ploa1$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa1$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[7]
#define $P$DER$Ploa$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa$Pi$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[8]
#define $P$DER$Ploa$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa$Pi$P1$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].tmpVars[9]
#define $P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$DER$Ploa2$Pv$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$res$P2$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].resultVars[1]
#define $P$res$P2$P$pDERLSJac5$PdummyVarLSJac5 _$P$res$P2$P$pDERLSJac5$PdummyVarLSJac5(0)

#define _$P$res$P1$P$pDERLSJac5$PdummyVarLSJac5(i) data->simulationInfo->analyticJacobians[0].resultVars[0]
#define $P$res$P1$P$pDERLSJac5$PdummyVarLSJac5 _$P$res$P1$P$pDERLSJac5$PdummyVarLSJac5(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_A 6
  int LineFeederAndCapacitorTest_functionJacA_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianA(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* A */

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_B 5
  int LineFeederAndCapacitorTest_functionJacB_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianB(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* B */

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_C 4
  int LineFeederAndCapacitorTest_functionJacC_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianC(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* C */

#if defined(__cplusplus)
extern "C" {
#endif
  #define LineFeederAndCapacitorTest_INDEX_JAC_D 3
  int LineFeederAndCapacitorTest_functionJacD_column(void* data, threadData_t *threadData);
  int LineFeederAndCapacitorTest_initialAnalyticJacobianD(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* D */


