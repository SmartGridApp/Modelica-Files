#include "LineFeederAndCapacitorTest_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "LineFeederAndCapacitorTest_includes.h"


Buildings_Electrical_Transmission_LowVoltageCables_Cu10 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu10(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu10 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu10(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu10__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu100 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu100(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu100 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu100(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu100__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu20 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu20(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu20 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu20(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu20__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu25 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu25(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu25 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu25(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu25__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu35 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu35(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu35 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu35(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu35__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu50 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu50(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu50 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu50(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu50__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Cu95 omc_Buildings_Electrical_Transmission_LowVoltageCables_Cu95(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Cu95 tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Cu95(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Cu95__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

Buildings_Electrical_Transmission_LowVoltageCables_Generic omc_Buildings_Electrical_Transmission_LowVoltageCables_Generic(threadData_t *threadData, modelica_integer omc_material, modelica_real omc_Amp, modelica_real omc_T_ref, modelica_real omc_M, modelica_real omc_RCha, modelica_real omc_XCha)
{
  Buildings_Electrical_Transmission_LowVoltageCables_Generic tmp1;
  tmp1._material = omc_material;
  tmp1._Amp = omc_Amp;
  tmp1._T_ref = omc_T_ref;
  tmp1._M = omc_M;
  tmp1._RCha = omc_RCha;
  tmp1._XCha = omc_XCha;
  return tmp1;
}

modelica_metatype boxptr_Buildings_Electrical_Transmission_LowVoltageCables_Generic(threadData_t *threadData, modelica_metatype _material, modelica_metatype _Amp, modelica_metatype _T_ref, modelica_metatype _M, modelica_metatype _RCha, modelica_metatype _XCha)
{
  return mmc_mk_box7(3, &Buildings_Electrical_Transmission_LowVoltageCables_Generic__desc, _material, _Amp, _T_ref, _M, _RCha, _XCha);
}

DLLExport
modelica_real omc_Modelica_Fluid_Utilities_regRoot(threadData_t *threadData, modelica_real _x, modelica_real _delta)
{
  modelica_real _y;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = _x;
  tmp2 = _delta;
  tmp3 = (tmp1 * tmp1) + (tmp2 * tmp2);
  tmp4 = 0.25;
  if(tmp3 < 0.0 && tmp4 != 0.0)
  {
    tmp6 = modf(tmp4, &tmp7);
    
    if(tmp6 > 0.5)
    {
      tmp6 -= 1.0;
      tmp7 += 1.0;
    }
    else if(tmp6 < -0.5)
    {
      tmp6 += 1.0;
      tmp7 -= 1.0;
    }
    
    if(fabs(tmp6) < 1e-10)
      tmp5 = pow(tmp3, tmp7);
    else
    {
      tmp9 = modf(1.0/tmp4, &tmp8);
      if(tmp9 > 0.5)
      {
        tmp9 -= 1.0;
        tmp8 += 1.0;
      }
      else if(tmp9 < -0.5)
      {
        tmp9 += 1.0;
        tmp8 -= 1.0;
      }
      if(fabs(tmp9) < 1e-10 && ((unsigned long)tmp8 & 1))
      {
        tmp5 = -pow(-tmp3, tmp6)*pow(tmp3, tmp7);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp3, tmp4);
      }
    }
  }
  else
  {
    tmp5 = pow(tmp3, tmp4);
  }
  if(isnan(tmp5) || isinf(tmp5))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp3, tmp4);
  }tmp10 = tmp5;
  if (tmp10 == 0) {throwStreamPrint(threadData, "Division by zero %s", "x / (x ^ 2.0 + delta ^ 2.0) ^ 0.25");}
  _y = (_x) / tmp10;
  _return: OMC_LABEL_UNUSED
  return _y;
}
modelica_metatype boxptr_Modelica_Fluid_Utilities_regRoot(threadData_t *threadData, modelica_metatype _x, modelica_metatype _delta)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real _y;
  modelica_metatype out_y;
  tmp1 = mmc_unbox_real(_x);
  tmp2 = mmc_unbox_real(_delta);
  _y = omc_Modelica_Fluid_Utilities_regRoot(threadData, tmp1, tmp2);
  out_y = mmc_mk_rcon(_y);
  return out_y;
}

#ifdef __cplusplus
}
#endif
