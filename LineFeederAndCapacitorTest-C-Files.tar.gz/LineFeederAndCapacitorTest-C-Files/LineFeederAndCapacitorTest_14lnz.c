/* Linearization */
#include "LineFeederAndCapacitorTest_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *LineFeederAndCapacitorTest_linear_model_frame()
{
  return "model linear_LineFeederAndCapacitorTest\n  parameter Integer n = 0; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,0] = zeros(0,0);%s\n"
  "  parameter Real C[0,0] = zeros(0,0);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  Real x[0];\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "\n  \n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_LineFeederAndCapacitorTest;\n";
}
const char *LineFeederAndCapacitorTest_linear_model_datarecovery_frame()
{
  return "model linear_LineFeederAndCapacitorTest\n  parameter Integer n = 0; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n  parameter Integer nz = 76; // data recovery variables\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real z0[76] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,0] = zeros(0,0);%s\n"
  "  parameter Real C[0,0] = zeros(0,0);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  parameter Real Cz[76,0] = zeros(76,0);%s\n"
  "  parameter Real Dz[76,0] = zeros(76,0);%s\n"
  "  Real x[0];\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "  output Real z[76];\n"
  "\nReal 'z_der(line1.line.line.i_p[1])' = z[1];\nReal 'z_der(line1.line.line.i_p[2])' = z[2];\nReal 'z_der(loa.i[1])' = z[3];\nReal 'z_der(loa.i[2])' = z[4];\nReal 'z_der(loa1.i[1])' = z[5];\nReal 'z_der(loa1.i[2])' = z[6];\nReal 'z_der(loa1.omega)' = z[7];\nReal 'z_der(loa1.theRef)' = z[8];\nReal 'z_der(loa2.i[1])' = z[9];\nReal 'z_der(loa2.i[2])' = z[10];\nReal 'z_der(loa2.v[1])' = z[11];\nReal 'z_der(loa2.v[2])' = z[12];\nReal 'z_der(loa3.i[1])' = z[13];\nReal 'z_der(loa3.i[2])' = z[14];\nReal 'z_$cse1' = z[15];\nReal 'z_$cse2' = z[16];\nReal 'z_feeder1.i[1]' = z[17];\nReal 'z_feeder1.i[2]' = z[18];\nReal 'z_feeder2.i[1]' = z[19];\nReal 'z_feeder2.i[2]' = z[20];\nReal 'z_gri.P.apparent' = z[21];\nReal 'z_gri.P.cosPhi' = z[22];\nReal 'z_gri.sou.S[1]' = z[23];\nReal 'z_gri.sou.S[2]' = z[24];\nReal 'z_gri.sou.phi' = z[25];\nReal 'z_gri.sou.thetaRel' = z[26];\nReal 'z_gri.terminal.v[1]' = z[27];\nReal 'z_gri.terminal.v[2]' = z[28];\nReal 'z_line1.line.VoltageLosses' = z[29];\nReal 'z_line1.line.cableTemp.port.Q_flow' = z[30];\nReal 'z_line1.line.line.R_actual' = z[31];\nReal 'z_line1.line.line.heatPort.Q_flow' = z[32];\nReal 'z_line1.line.line.i_p[1]' = z[33];\nReal 'z_line1.line.line.i_p[2]' = z[34];\nReal 'z_loa.P_internal' = z[35];\nReal 'z_loa.S[1]' = z[36];\nReal 'z_loa.S[2]' = z[37];\nReal 'z_loa.i[1]' = z[38];\nReal 'z_loa.i[2]' = z[39];\nReal 'z_loa.load' = z[40];\nReal 'z_loa.y_internal' = z[41];\nReal 'z_loa1.P_internal' = z[42];\nReal 'z_loa1.Q' = z[43];\nReal 'z_loa1.S[1]' = z[44];\nReal 'z_loa1.S[2]' = z[45];\nReal 'z_loa1.Z[1]' = z[46];\nReal 'z_loa1.Z[2]' = z[47];\nReal 'z_loa1.i[1]' = z[48];\nReal 'z_loa1.i[2]' = z[49];\nReal 'z_loa1.load' = z[50];\nReal 'z_loa1.omega' = z[51];\nReal 'z_loa1.psi[1]' = z[52];\nReal 'z_loa1.psi[2]' = z[53];\nReal 'z_loa1.theRef' = z[54];\nReal 'z_loa1.y_internal' = z[55];\nReal 'z_loa2.P_internal' = z[56];\nReal 'z_loa2.S[1]' = z[57];\nReal 'z_loa2.S[2]' = z[58];\nReal 'z_loa2.i[1]' = z[59];\nReal 'z_loa2.i[2]' = z[60];\nReal 'z_loa2.load' = z[61];\nReal 'z_loa2.v[1]' = z[62];\nReal 'z_loa2.v[2]' = z[63];\nReal 'z_loa2.y_internal' = z[64];\nReal 'z_loa3.P_internal' = z[65];\nReal 'z_loa3.Q' = z[66];\nReal 'z_loa3.S[1]' = z[67];\nReal 'z_loa3.S[2]' = z[68];\nReal 'z_loa3.Y[1]' = z[69];\nReal 'z_loa3.Y[2]' = z[70];\nReal 'z_loa3.i[1]' = z[71];\nReal 'z_loa3.i[2]' = z[72];\nReal 'z_loa3.load' = z[73];\nReal 'z_loa3.q[1]' = z[74];\nReal 'z_loa3.q[2]' = z[75];\nReal 'z_loa3.y_internal' = z[76];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_LineFeederAndCapacitorTest;\n";
}
#if defined(__cplusplus)
}
#endif

