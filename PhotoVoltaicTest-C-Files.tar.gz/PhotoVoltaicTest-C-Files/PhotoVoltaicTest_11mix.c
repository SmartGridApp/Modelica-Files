/* Mixed Systems */
#include "PhotoVoltaicTest_model.h"
#include "PhotoVoltaicTest_11mix.h"
/* initial mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */


