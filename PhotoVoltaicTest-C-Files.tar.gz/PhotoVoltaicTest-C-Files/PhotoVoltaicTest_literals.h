#ifdef __cplusplus
extern "C" {
#endif

#define _OMC_LIT0_data "1"
static const MMC_DEFSTRINGLIT(_OMC_LIT_STRUCT0,1,_OMC_LIT0_data);
#define _OMC_LIT0 MMC_REFSTRINGLIT(_OMC_LIT_STRUCT0)

#ifdef __cplusplus
}
#endif
