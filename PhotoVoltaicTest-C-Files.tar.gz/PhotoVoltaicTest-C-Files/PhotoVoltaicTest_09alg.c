/* Algebraic */
#include "PhotoVoltaicTest_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void PhotoVoltaicTest_eqFunction_54(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_55(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_56(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_57(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_58(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_59(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_60(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_61(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_38(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_64(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_63(DATA* data, threadData_t *threadData);
extern void PhotoVoltaicTest_eqFunction_62(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  PhotoVoltaicTest_eqFunction_54(data, threadData);

  PhotoVoltaicTest_eqFunction_55(data, threadData);

  PhotoVoltaicTest_eqFunction_56(data, threadData);

  PhotoVoltaicTest_eqFunction_57(data, threadData);

  PhotoVoltaicTest_eqFunction_58(data, threadData);

  PhotoVoltaicTest_eqFunction_59(data, threadData);

  PhotoVoltaicTest_eqFunction_60(data, threadData);

  PhotoVoltaicTest_eqFunction_61(data, threadData);

  PhotoVoltaicTest_eqFunction_38(data, threadData);

  PhotoVoltaicTest_eqFunction_64(data, threadData);

  PhotoVoltaicTest_eqFunction_63(data, threadData);

  PhotoVoltaicTest_eqFunction_62(data, threadData);
}
/* for continuous time variables */
int PhotoVoltaicTest_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  
  data->simulationInfo->callStatistics.functionAlgebraics++;
  
  functionAlg_system0(data, threadData);

  PhotoVoltaicTest_function_savePreSynchronous(data, threadData);
  
  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
