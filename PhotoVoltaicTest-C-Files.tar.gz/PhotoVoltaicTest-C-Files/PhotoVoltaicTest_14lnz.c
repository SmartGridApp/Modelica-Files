/* Linearization */
#include "PhotoVoltaicTest_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *PhotoVoltaicTest_linear_model_frame()
{
  return "model linear_PhotoVoltaicTest\n  parameter Integer n = 0; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,0] = zeros(0,0);%s\n"
  "  parameter Real C[0,0] = zeros(0,0);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  Real x[0];\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "\n  \n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_PhotoVoltaicTest;\n";
}
const char *PhotoVoltaicTest_linear_model_datarecovery_frame()
{
  return "model linear_PhotoVoltaicTest\n  parameter Integer n = 0; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n  parameter Integer nz = 30; // data recovery variables\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real z0[30] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,0] = zeros(0,0);%s\n"
  "  parameter Real C[0,0] = zeros(0,0);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  parameter Real Cz[30,0] = zeros(30,0);%s\n"
  "  parameter Real Dz[30,0] = zeros(30,0);%s\n"
  "  Real x[0];\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "  output Real z[30];\n"
  "\nReal 'z_$cse2' = z[1];\nReal 'z_basicPV1.pVDiode1.Eg' = z[2];\nReal 'z_basicPV1.pVDiode1.Ids' = z[3];\nReal 'z_basicPV1.pVDiode1.Ion' = z[4];\nReal 'z_basicPV1.pVDiode1.K' = z[5];\nReal 'z_basicPV1.pVDiode1.LossPower' = z[6];\nReal 'z_basicPV1.pVDiode1.R_s' = z[7];\nReal 'z_basicPV1.pVDiode1.a' = z[8];\nReal 'z_basicPV1.pVDiode1.i' = z[9];\nReal 'z_basicPV1.pVDiode1.q' = z[10];\nReal 'z_basicPV1.pin_n.i' = z[11];\nReal 'z_basicPV1.resistor2.LossPower' = z[12];\nReal 'z_basicPV1.resistor2.v' = z[13];\nReal 'z_basicPV1.resistor3.LossPower' = z[14];\nReal 'z_basicPV1.resistor3.R_actual' = z[15];\nReal 'z_basicPV1.resistor3.i' = z[16];\nReal 'z_basicPV1.signalPhotoVoltaicCurrent1.Gn' = z[17];\nReal 'z_basicPV1.signalPhotoVoltaicCurrent1.Ki' = z[18];\nReal 'z_basicPV1.signalPhotoVoltaicCurrent1.LossPower' = z[19];\nReal 'z_basicPV1.signalPhotoVoltaicCurrent1.i' = z[20];\nReal 'z_basicPV1.signalPhotoVoltaicCurrent1.v' = z[21];\nReal 'z_basicPV1.voltageSensor1.n.i' = z[22];\nReal 'z_basicPV1.voltageSensor1.p.i' = z[23];\nReal 'z_bulb1.I' = z[24];\nReal 'z_bulb1.P' = z[25];\nReal 'z_bulb1.V' = z[26];\nReal 'z_bulb1.resistor1.LossPower' = z[27];\nReal 'z_bulb1.resistor1.R_actual' = z[28];\nReal 'z_ground1.p.i' = z[29];\nReal 'z_ground1.p.v' = z[30];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_PhotoVoltaicTest;\n";
}
#if defined(__cplusplus)
}
#endif

