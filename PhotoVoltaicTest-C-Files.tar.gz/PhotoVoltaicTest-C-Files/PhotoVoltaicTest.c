/* Main Simulation File */
#include "PhotoVoltaicTest_model.h"

#define prefixedName_performSimulation PhotoVoltaicTest_performSimulation
#define prefixedName_updateContinuousSystem PhotoVoltaicTest_updateContinuousSystem
#include <simulation/solver/perform_simulation.c>

#define prefixedName_performQSSSimulation PhotoVoltaicTest_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c>

/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int PhotoVoltaicTest_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int PhotoVoltaicTest_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int PhotoVoltaicTest_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int PhotoVoltaicTest_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int PhotoVoltaicTest_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
 equation index: 38
 type: SIMPLE_ASSIGN
 ground1._p._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  data->localData[0]->realVars[28] /* ground1._p._i variable */ = 0.0;
  TRACE_POP
}
void PhotoVoltaicTest_eqFunction_39(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_40(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_41(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_42(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_43(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_44(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_45(DATA*,threadData_t*);
/*
 equation index: 54
 indexNonlinear: 1
 type: NONLINEAR
 
 vars: {bulb1._I}
 eqns: {39, 40, 41, 42, 43, 44, 45}
 */
void PhotoVoltaicTest_eqFunction_54(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,54};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 54 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = data->localData[0]->realVars[23] /* bulb1._I variable */;
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,54};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 54 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[23] /* bulb1._I variable */ = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  TRACE_POP
}
/*
 equation index: 55
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._LossPower = (-basicPV1.signalPhotoVoltaicCurrent1.v) * basicPV1.pVDiode1.i
 */
void PhotoVoltaicTest_eqFunction_55(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,55};
  data->localData[0]->realVars[5] /* basicPV1._pVDiode1._LossPower variable */ = ((-data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */)) * (data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */);
  TRACE_POP
}
/*
 equation index: 56
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._LossPower = basicPV1.signalPhotoVoltaicCurrent1.v * basicPV1.signalPhotoVoltaicCurrent1.i
 */
void PhotoVoltaicTest_eqFunction_56(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,56};
  data->localData[0]->realVars[18] /* basicPV1._signalPhotoVoltaicCurrent1._LossPower variable */ = (data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */) * (data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */);
  TRACE_POP
}
/*
 equation index: 57
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._LossPower = basicPV1.signalPhotoVoltaicCurrent1.v * basicPV1.resistor3.i
 */
void PhotoVoltaicTest_eqFunction_57(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,57};
  data->localData[0]->realVars[13] /* basicPV1._resistor3._LossPower variable */ = (data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */) * (data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */);
  TRACE_POP
}
/*
 equation index: 58
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._LossPower = (-basicPV1.resistor2.v) * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_58(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,58};
  data->localData[0]->realVars[11] /* basicPV1._resistor2._LossPower variable */ = ((-data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */)) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 59
 type: SIMPLE_ASSIGN
 bulb1._resistor1._LossPower = bulb1.V * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_59(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,59};
  data->localData[0]->realVars[26] /* bulb1._resistor1._LossPower variable */ = (data->localData[0]->realVars[25] /* bulb1._V variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 60
 type: SIMPLE_ASSIGN
 bulb1._P = bulb1.V * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_60(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,60};
  data->localData[0]->realVars[24] /* bulb1._P variable */ = (data->localData[0]->realVars[25] /* bulb1._V variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 61
 type: SIMPLE_ASSIGN
 basicPV1._pin_n._i = bulb1.I
 */
void PhotoVoltaicTest_eqFunction_61(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,61};
  data->localData[0]->realVars[10] /* basicPV1._pin_n._i variable */ = data->localData[0]->realVars[23] /* bulb1._I variable */;
  TRACE_POP
}
/*
 equation index: 64
 type: ALGORITHM
 
   assert(1.0 + bulb1.resistor1.alpha * (bulb1.resistor1.T - bulb1.resistor1.T_ref) >= 1e-15, "Temperature outside scope of model!");
 */
void PhotoVoltaicTest_eqFunction_64(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,64};
  modelica_boolean tmp0;
  static const MMC_DEFSTRINGLIT(tmp1,35,"Temperature outside scope of model!");
  static int tmp2 = 0;
  {
    tmp0 = GreaterEq(1.0 + (data->simulationInfo->realParameter[24]) * (data->simulationInfo->realParameter[22] - data->simulationInfo->realParameter[23]),1e-15);
    if(!tmp0)
    {
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Basic.mo",66,5,67,45,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\n1.0 + bulb1.resistor1.alpha * (bulb1.resistor1.T - bulb1.resistor1.T_ref) >= 1e-15", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_withEquationIndexes(threadData, info, equationIndexes, MMC_STRINGDATA(MMC_REFSTRINGLIT(tmp1)));
      }
    }
  }
  TRACE_POP
}
/*
 equation index: 63
 type: ALGORITHM
 
   assert(1.0 + basicPV1.resistor2.alpha * (basicPV1.resistor2.T - basicPV1.resistor2.T_ref) >= 1e-15, "Temperature outside scope of model!");
 */
void PhotoVoltaicTest_eqFunction_63(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,63};
  modelica_boolean tmp3;
  static const MMC_DEFSTRINGLIT(tmp4,35,"Temperature outside scope of model!");
  static int tmp5 = 0;
  {
    tmp3 = GreaterEq(1.0 + (data->simulationInfo->realParameter[11]) * (data->simulationInfo->realParameter[9] - data->simulationInfo->realParameter[10]),1e-15);
    if(!tmp3)
    {
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",212,5,212,110,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\n1.0 + basicPV1.resistor2.alpha * (basicPV1.resistor2.T - basicPV1.resistor2.T_ref) >= 1e-15", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_withEquationIndexes(threadData, info, equationIndexes, MMC_STRINGDATA(MMC_REFSTRINGLIT(tmp4)));
      }
    }
  }
  TRACE_POP
}
/*
 equation index: 62
 type: ALGORITHM
 
   assert(1.0 + basicPV1.resistor3.alpha * (basicPV1.resistor3.T - basicPV1.resistor3.T_ref) >= 1e-15, "Temperature outside scope of model!");
 */
void PhotoVoltaicTest_eqFunction_62(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,62};
  modelica_boolean tmp6;
  static const MMC_DEFSTRINGLIT(tmp7,35,"Temperature outside scope of model!");
  static int tmp8 = 0;
  {
    tmp6 = GreaterEq(1.0 + (data->simulationInfo->realParameter[15]) * (data->simulationInfo->realParameter[13] - data->simulationInfo->realParameter[14]),1e-15);
    if(!tmp6)
    {
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Basic.mo",66,5,67,45,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\n1.0 + basicPV1.resistor3.alpha * (basicPV1.resistor3.T - basicPV1.resistor3.T_ref) >= 1e-15", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_withEquationIndexes(threadData, info, equationIndexes, MMC_STRINGDATA(MMC_REFSTRINGLIT(tmp7)));
      }
    }
  }
  TRACE_POP
}


int PhotoVoltaicTest_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  PhotoVoltaicTest_functionLocalKnownVars(data, threadData);
  PhotoVoltaicTest_eqFunction_38(data, threadData);

  PhotoVoltaicTest_eqFunction_54(data, threadData);

  PhotoVoltaicTest_eqFunction_55(data, threadData);

  PhotoVoltaicTest_eqFunction_56(data, threadData);

  PhotoVoltaicTest_eqFunction_57(data, threadData);

  PhotoVoltaicTest_eqFunction_58(data, threadData);

  PhotoVoltaicTest_eqFunction_59(data, threadData);

  PhotoVoltaicTest_eqFunction_60(data, threadData);

  PhotoVoltaicTest_eqFunction_61(data, threadData);

  PhotoVoltaicTest_eqFunction_64(data, threadData);

  PhotoVoltaicTest_eqFunction_63(data, threadData);

  PhotoVoltaicTest_eqFunction_62(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int PhotoVoltaicTest_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


int PhotoVoltaicTest_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  PhotoVoltaicTest_functionLocalKnownVars(data, threadData);
  /* no ODE systems */

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "PhotoVoltaicTest_12jac.h"
#include "PhotoVoltaicTest_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks PhotoVoltaicTest_callback = {
   (int (*)(DATA *, threadData_t *, void *)) PhotoVoltaicTest_performSimulation,
   (int (*)(DATA *, threadData_t *, void *)) PhotoVoltaicTest_performQSSSimulation,
   PhotoVoltaicTest_updateContinuousSystem,
   PhotoVoltaicTest_callExternalObjectDestructors,
   PhotoVoltaicTest_initialNonLinearSystem,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   PhotoVoltaicTest_initializeStateSets,
   #else
   NULL,
   #endif
   PhotoVoltaicTest_initializeDAEmodeData,
   PhotoVoltaicTest_functionODE,
   PhotoVoltaicTest_functionAlgebraics,
   PhotoVoltaicTest_functionDAE,
   PhotoVoltaicTest_functionLocalKnownVars,
   PhotoVoltaicTest_input_function,
   PhotoVoltaicTest_input_function_init,
   PhotoVoltaicTest_input_function_updateStartValues,
   PhotoVoltaicTest_output_function,
   PhotoVoltaicTest_function_storeDelayed,
   PhotoVoltaicTest_updateBoundVariableAttributes,
   PhotoVoltaicTest_functionInitialEquations,
   PhotoVoltaicTest_functionRemovedInitialEquations,
   PhotoVoltaicTest_updateBoundParameters,
   PhotoVoltaicTest_checkForAsserts,
   PhotoVoltaicTest_function_ZeroCrossingsEquations,
   PhotoVoltaicTest_function_ZeroCrossings,
   PhotoVoltaicTest_function_updateRelations,
   PhotoVoltaicTest_checkForDiscreteChanges,
   PhotoVoltaicTest_zeroCrossingDescription,
   PhotoVoltaicTest_relationDescription,
   PhotoVoltaicTest_function_initSample,
   PhotoVoltaicTest_INDEX_JAC_A,
   PhotoVoltaicTest_INDEX_JAC_B,
   PhotoVoltaicTest_INDEX_JAC_C,
   PhotoVoltaicTest_INDEX_JAC_D,
   PhotoVoltaicTest_initialAnalyticJacobianA,
   PhotoVoltaicTest_initialAnalyticJacobianB,
   PhotoVoltaicTest_initialAnalyticJacobianC,
   PhotoVoltaicTest_initialAnalyticJacobianD,
   PhotoVoltaicTest_functionJacA_column,
   PhotoVoltaicTest_functionJacB_column,
   PhotoVoltaicTest_functionJacC_column,
   PhotoVoltaicTest_functionJacD_column,
   PhotoVoltaicTest_linear_model_frame,
   PhotoVoltaicTest_linear_model_datarecovery_frame,
   PhotoVoltaicTest_mayer,
   PhotoVoltaicTest_lagrange,
   PhotoVoltaicTest_pickUpBoundsForInputsInOptimization,
   PhotoVoltaicTest_setInputData,
   PhotoVoltaicTest_getTimeGrid,
   PhotoVoltaicTest_symbolicInlineSystem,
   PhotoVoltaicTest_function_initSynchronous,
   PhotoVoltaicTest_function_updateSynchronous,
   PhotoVoltaicTest_function_equationsSynchronous,
   NULL
   #ifdef FMU_EXPERIMENTAL
   ,PhotoVoltaicTest_functionODE_Partial
   ,PhotoVoltaicTest_functionFMIJacobian
   #endif
   ,PhotoVoltaicTest_inputNames


};

void PhotoVoltaicTest_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &PhotoVoltaicTest_callback;
  data->modelData->modelName = "PhotoVoltaicTest";
  data->modelData->modelFilePrefix = "PhotoVoltaicTest";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "/home/bhaskar/Modelica/Modelica-Files";
  data->modelData->modelGUID = "{235ee460-3b2a-4cb6-8e85-b82ab828fe49}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "PhotoVoltaicTest_init.c"
    ;
  static const char contents_info[] =
    #include "PhotoVoltaicTest_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "PhotoVoltaicTest_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "PhotoVoltaicTest_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  
  data->modelData->nStates = 0;
  data->modelData->nVariablesReal = 30;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 25;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 5;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  
  data->modelData->nAliasReal = 51;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 0;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "PhotoVoltaicTest_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 101;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 2;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 6;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    PhotoVoltaicTest_setupDataStruc(&data, threadData);
    res = _main_SimulationRuntime(argc, argv, &data, threadData);
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

