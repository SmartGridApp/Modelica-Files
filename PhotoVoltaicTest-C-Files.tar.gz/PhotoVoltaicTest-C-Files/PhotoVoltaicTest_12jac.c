/* Jacobians */
#include "PhotoVoltaicTest_model.h"
#include "PhotoVoltaicTest_12jac.h"

int PhotoVoltaicTest_initialAnalyticJacobianNLSJac1(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  DATA* data = ((DATA*)inData);
  int index = PhotoVoltaicTest_INDEX_JAC_NLSJac1;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  int i = 0;
  
  data->simulationInfo->analyticJacobians[index].sizeCols = 1;
  data->simulationInfo->analyticJacobians[index].sizeRows = 1;
  data->simulationInfo->analyticJacobians[index].sizeTmpVars = 8;
  data->simulationInfo->analyticJacobians[index].seedVars = (modelica_real*) calloc(1,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].resultVars = (modelica_real*) calloc(1,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].tmpVars = (modelica_real*) calloc(8,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.numberOfNoneZeros = 1;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.maxColors = 1;
  data->simulationInfo->analyticJacobians[index].jacobian = NULL;
  
  /* write lead index of compressed sparse column */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i] += data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[0] = 1;
  TRACE_POP
  return 0;
}

int PhotoVoltaicTest_initialAnalyticJacobianNLSJac0(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  DATA* data = ((DATA*)inData);
  int index = PhotoVoltaicTest_INDEX_JAC_NLSJac0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  int i = 0;
  
  data->simulationInfo->analyticJacobians[index].sizeCols = 1;
  data->simulationInfo->analyticJacobians[index].sizeRows = 1;
  data->simulationInfo->analyticJacobians[index].sizeTmpVars = 8;
  data->simulationInfo->analyticJacobians[index].seedVars = (modelica_real*) calloc(1,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].resultVars = (modelica_real*) calloc(1,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].tmpVars = (modelica_real*) calloc(8,sizeof(modelica_real));
  data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.numberOfNoneZeros = 1;
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  data->simulationInfo->analyticJacobians[index].sparsePattern.maxColors = 1;
  data->simulationInfo->analyticJacobians[index].jacobian = NULL;
  
  /* write lead index of compressed sparse column */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i] += data->simulationInfo->analyticJacobians[index].sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(data->simulationInfo->analyticJacobians[index].sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  data->simulationInfo->analyticJacobians[index].sparsePattern.colorCols[0] = 1;
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_initialAnalyticJacobianA(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int PhotoVoltaicTest_initialAnalyticJacobianB(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int PhotoVoltaicTest_initialAnalyticJacobianC(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}
int PhotoVoltaicTest_initialAnalyticJacobianD(void* inData, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 1;
}


/*
 equation index: 46
 type: SIMPLE_ASSIGN
 $cse3 = exp(1.062e-19 * DIVISION(bulb1.V + bulb1.I * basicPV1.pVDiode1.R_s, 2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns))
 */
void PhotoVoltaicTest_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,46};
  $P$cse3 = exp((1.062e-19) * (DIVISION_SIM(data->localData[0]->realVars[25] /* bulb1._V variable */ + (data->localData[0]->realVars[23] /* bulb1._I variable */) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */),((2.070975e-23) * (data->simulationInfo->realParameter[5])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 47
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._v._$pDERNLSJac1._dummyVarNLSJac1 = (-basicPV1.pVDiode1.R_s) * bulb1_ISeedNLSJac1
 */
void PhotoVoltaicTest_eqFunction_47(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,47};
  $PbasicPV1$Presistor2$Pv$P$pDERNLSJac1$PdummyVarNLSJac1 = ((-data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * ($Pbulb1_ISeedNLSJac1);
  TRACE_POP
}

/*
 equation index: 48
 type: SIMPLE_ASSIGN
 bulb1._V._$pDERNLSJac1._dummyVarNLSJac1 = bulb1.resistor1.R_actual * bulb1_ISeedNLSJac1
 */
void PhotoVoltaicTest_eqFunction_48(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,48};
  $Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1 = (data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */) * ($Pbulb1_ISeedNLSJac1);
  TRACE_POP
}

/*
 equation index: 49
 type: SIMPLE_ASSIGN
 $cse2._$pDERNLSJac1._dummyVarNLSJac1 = 5128.019411146923 * $cse3 * (bulb1.V.$pDERNLSJac1.dummyVarNLSJac1 + bulb1_ISeedNLSJac1 * basicPV1.pVDiode1.R_s) * basicPV1.pVDiode1.Tn * DIVISION(basicPV1.pVDiode1.Ns, (basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns) ^ 2.0)
 */
void PhotoVoltaicTest_eqFunction_49(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,49};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[5]) * (data->simulationInfo->realParameter[2]);
  $P$cse2$P$pDERNLSJac1$PdummyVarNLSJac1 = (5128.019411146923) * (($P$cse3) * (($Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1 + ($Pbulb1_ISeedNLSJac1) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * ((data->simulationInfo->realParameter[5]) * (DIVISION_SIM(data->simulationInfo->realParameter[2],(tmp0 * tmp0),"(basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns) ^ 2.0",equationIndexes)))));
  TRACE_POP
}

/*
 equation index: 50
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._i._$pDERNLSJac1._dummyVarNLSJac1 = basicPV1.pVDiode1.Ids * $cse2.$pDERNLSJac1.dummyVarNLSJac1
 */
void PhotoVoltaicTest_eqFunction_50(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,50};
  $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac1$PdummyVarNLSJac1 = (data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */) * ($P$cse2$P$pDERNLSJac1$PdummyVarNLSJac1);
  TRACE_POP
}

/*
 equation index: 51
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._i._$pDERNLSJac1._dummyVarNLSJac1 = basicPV1.pVDiode1.i.$pDERNLSJac1.dummyVarNLSJac1 + bulb1_ISeedNLSJac1
 */
void PhotoVoltaicTest_eqFunction_51(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,51};
  $PbasicPV1$Presistor3$Pi$P$pDERNLSJac1$PdummyVarNLSJac1 = $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac1$PdummyVarNLSJac1 + $Pbulb1_ISeedNLSJac1;
  TRACE_POP
}

/*
 equation index: 52
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._v._$pDERNLSJac1._dummyVarNLSJac1 = basicPV1.resistor3.R_actual * basicPV1.resistor3.i.$pDERNLSJac1.dummyVarNLSJac1
 */
void PhotoVoltaicTest_eqFunction_52(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,52};
  $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac1$PdummyVarNLSJac1 = (data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */) * ($PbasicPV1$Presistor3$Pi$P$pDERNLSJac1$PdummyVarNLSJac1);
  TRACE_POP
}

/*
 equation index: 53
 type: SIMPLE_ASSIGN
 $res._1._$pDERNLSJac1._dummyVarNLSJac1 = basicPV1.signalPhotoVoltaicCurrent1.v.$pDERNLSJac1.dummyVarNLSJac1 + bulb1.V.$pDERNLSJac1.dummyVarNLSJac1 - basicPV1.resistor2.v.$pDERNLSJac1.dummyVarNLSJac1
 */
void PhotoVoltaicTest_eqFunction_53(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,53};
  $P$res$P1$P$pDERNLSJac1$PdummyVarNLSJac1 = $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac1$PdummyVarNLSJac1 + $Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1 - $PbasicPV1$Presistor2$Pv$P$pDERNLSJac1$PdummyVarNLSJac1;
  TRACE_POP
}
int PhotoVoltaicTest_functionJacNLSJac1_column(void* inData, threadData_t *threadData)
{
  TRACE_PUSH

  DATA* data = ((DATA*)inData);
  int index = PhotoVoltaicTest_INDEX_JAC_NLSJac1;
  PhotoVoltaicTest_eqFunction_46(data, threadData);

  PhotoVoltaicTest_eqFunction_47(data, threadData);

  PhotoVoltaicTest_eqFunction_48(data, threadData);

  PhotoVoltaicTest_eqFunction_49(data, threadData);

  PhotoVoltaicTest_eqFunction_50(data, threadData);

  PhotoVoltaicTest_eqFunction_51(data, threadData);

  PhotoVoltaicTest_eqFunction_52(data, threadData);

  PhotoVoltaicTest_eqFunction_53(data, threadData);
  
  TRACE_POP
  return 0;
}

/*
 equation index: 23
 type: SIMPLE_ASSIGN
 $cse1 = exp(1.062e-19 * DIVISION(bulb1.V + bulb1.I * basicPV1.pVDiode1.R_s, 2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns))
 */
void PhotoVoltaicTest_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,23};
  $P$cse1 = exp((1.062e-19) * (DIVISION_SIM(data->localData[0]->realVars[25] /* bulb1._V variable */ + (data->localData[0]->realVars[23] /* bulb1._I variable */) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */),((2.070975e-23) * (data->simulationInfo->realParameter[5])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 24
 type: SIMPLE_ASSIGN
 bulb1._V._$pDERNLSJac0._dummyVarNLSJac0 = bulb1.resistor1.R_actual * bulb1_ISeedNLSJac0
 */
void PhotoVoltaicTest_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,24};
  $Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0 = (data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */) * ($Pbulb1_ISeedNLSJac0);
  TRACE_POP
}

/*
 equation index: 25
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._i._$pDERNLSJac0._dummyVarNLSJac0 = 5128.019411146923 * basicPV1.pVDiode1.Ids * $cse1 * (bulb1.V.$pDERNLSJac0.dummyVarNLSJac0 + bulb1_ISeedNLSJac0 * basicPV1.pVDiode1.R_s) * basicPV1.pVDiode1.Tn * DIVISION(basicPV1.pVDiode1.Ns, (basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns) ^ 2.0)
 */
void PhotoVoltaicTest_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,25};
  modelica_real tmp1;
  tmp1 = (data->simulationInfo->realParameter[5]) * (data->simulationInfo->realParameter[2]);
  $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 = (5128.019411146923) * ((data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */) * (($P$cse1) * (($Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0 + ($Pbulb1_ISeedNLSJac0) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * ((data->simulationInfo->realParameter[5]) * (DIVISION_SIM(data->simulationInfo->realParameter[2],(tmp1 * tmp1),"(basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns) ^ 2.0",equationIndexes))))));
  TRACE_POP
}

/*
 equation index: 26
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._i._$pDERNLSJac0._dummyVarNLSJac0 = basicPV1.pVDiode1.i.$pDERNLSJac0.dummyVarNLSJac0 + bulb1_ISeedNLSJac0
 */
void PhotoVoltaicTest_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,26};
  $PbasicPV1$Presistor3$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 = $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 + $Pbulb1_ISeedNLSJac0;
  TRACE_POP
}

/*
 equation index: 27
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._v._$pDERNLSJac0._dummyVarNLSJac0 = basicPV1.resistor3.R_actual * basicPV1.resistor3.i.$pDERNLSJac0.dummyVarNLSJac0
 */
void PhotoVoltaicTest_eqFunction_27(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,27};
  $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac0$PdummyVarNLSJac0 = (data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */) * ($PbasicPV1$Presistor3$Pi$P$pDERNLSJac0$PdummyVarNLSJac0);
  TRACE_POP
}

/*
 equation index: 28
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._v._$pDERNLSJac0._dummyVarNLSJac0 = (-basicPV1.pVDiode1.R_s) * bulb1_ISeedNLSJac0
 */
void PhotoVoltaicTest_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,28};
  $PbasicPV1$Presistor2$Pv$P$pDERNLSJac0$PdummyVarNLSJac0 = ((-data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * ($Pbulb1_ISeedNLSJac0);
  TRACE_POP
}

/*
 equation index: 29
 type: SIMPLE_ASSIGN
 $res._1._$pDERNLSJac0._dummyVarNLSJac0 = basicPV1.signalPhotoVoltaicCurrent1.v.$pDERNLSJac0.dummyVarNLSJac0 + bulb1.V.$pDERNLSJac0.dummyVarNLSJac0 - basicPV1.resistor2.v.$pDERNLSJac0.dummyVarNLSJac0
 */
void PhotoVoltaicTest_eqFunction_29(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int clockIndex = 0;
  const int equationIndexes[2] = {1,29};
  $P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0 = $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac0$PdummyVarNLSJac0 + $Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0 - $PbasicPV1$Presistor2$Pv$P$pDERNLSJac0$PdummyVarNLSJac0;
  TRACE_POP
}
int PhotoVoltaicTest_functionJacNLSJac0_column(void* inData, threadData_t *threadData)
{
  TRACE_PUSH

  DATA* data = ((DATA*)inData);
  int index = PhotoVoltaicTest_INDEX_JAC_NLSJac0;
  PhotoVoltaicTest_eqFunction_23(data, threadData);

  PhotoVoltaicTest_eqFunction_24(data, threadData);

  PhotoVoltaicTest_eqFunction_25(data, threadData);

  PhotoVoltaicTest_eqFunction_26(data, threadData);

  PhotoVoltaicTest_eqFunction_27(data, threadData);

  PhotoVoltaicTest_eqFunction_28(data, threadData);

  PhotoVoltaicTest_eqFunction_29(data, threadData);
  
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_functionJacA_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_functionJacB_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_functionJacC_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_functionJacD_column(void* data, threadData_t *threadData)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}


