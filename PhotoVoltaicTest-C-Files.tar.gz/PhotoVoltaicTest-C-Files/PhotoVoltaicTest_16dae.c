/* DAE residuals is empty */
 #include "PhotoVoltaicTest_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int PhotoVoltaicTest_initializeDAEmodeData(DATA *inData, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
