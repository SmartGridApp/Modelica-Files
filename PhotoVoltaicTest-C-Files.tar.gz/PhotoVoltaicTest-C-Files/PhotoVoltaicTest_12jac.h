/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;
/* Jacobian Variables */
#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_NLSJac1 1
  int PhotoVoltaicTest_functionJacNLSJac1_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianNLSJac1(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* NLSJac1 */
#define $Pbulb1_ISeedNLSJac1 data->simulationInfo->analyticJacobians[1].seedVars[0]
#define _$PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[0]
#define $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac1$PdummyVarNLSJac1 _$PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$PbasicPV1$Presistor3$Pi$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[1]
#define $PbasicPV1$Presistor3$Pi$P$pDERNLSJac1$PdummyVarNLSJac1 _$PbasicPV1$Presistor3$Pi$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[2]
#define $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac1$PdummyVarNLSJac1 _$PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$P$cse2$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[3]
#define $P$cse2$P$pDERNLSJac1$PdummyVarNLSJac1 _$P$cse2$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[4]
#define $Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1 _$Pbulb1$PV$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$PbasicPV1$Presistor2$Pv$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].tmpVars[5]
#define $PbasicPV1$Presistor2$Pv$P$pDERNLSJac1$PdummyVarNLSJac1 _$PbasicPV1$Presistor2$Pv$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$P$res$P1$P$pDERNLSJac1$PdummyVarNLSJac1(i) data->simulationInfo->analyticJacobians[1].resultVars[0]
#define $P$res$P1$P$pDERNLSJac1$PdummyVarNLSJac1 _$P$res$P1$P$pDERNLSJac1$PdummyVarNLSJac1(0)

#define _$P$cse3(i) data->simulationInfo->analyticJacobians[1].tmpVars[7]
#define $P$cse3 _$P$cse3(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_NLSJac0 0
  int PhotoVoltaicTest_functionJacNLSJac0_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianNLSJac0(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* NLSJac0 */
#define $Pbulb1_ISeedNLSJac0 data->simulationInfo->analyticJacobians[0].seedVars[0]
#define _$PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[0]
#define $PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac0$PdummyVarNLSJac0 _$PbasicPV1$PsignalPhotoVoltaicCurrent1$Pv$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$PbasicPV1$Presistor3$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[1]
#define $PbasicPV1$Presistor3$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 _$PbasicPV1$Presistor3$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$PbasicPV1$Ppin_n$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[2]
#define $PbasicPV1$Ppin_n$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 _$PbasicPV1$Ppin_n$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[3]
#define $PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac0$PdummyVarNLSJac0 _$PbasicPV1$PpVDiode1$Pi$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[4]
#define $Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0 _$Pbulb1$PV$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$PbasicPV1$Presistor2$Pv$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[5]
#define $PbasicPV1$Presistor2$Pv$P$pDERNLSJac0$PdummyVarNLSJac0 _$PbasicPV1$Presistor2$Pv$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].resultVars[0]
#define $P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0 _$P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$P$cse1(i) data->simulationInfo->analyticJacobians[0].tmpVars[7]
#define $P$cse1 _$P$cse1(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_A 5
  int PhotoVoltaicTest_functionJacA_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianA(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* A */

#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_B 4
  int PhotoVoltaicTest_functionJacB_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianB(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* B */

#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_C 3
  int PhotoVoltaicTest_functionJacC_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianC(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* C */

#if defined(__cplusplus)
extern "C" {
#endif
  #define PhotoVoltaicTest_INDEX_JAC_D 2
  int PhotoVoltaicTest_functionJacD_column(void* data, threadData_t *threadData);
  int PhotoVoltaicTest_initialAnalyticJacobianD(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* D */


