/* Initialization */
#include "PhotoVoltaicTest_model.h"
#include "PhotoVoltaicTest_11mix.h"
#include "PhotoVoltaicTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void PhotoVoltaicTest_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 ground1._p._v = 0.0
 */
void PhotoVoltaicTest_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[29] /* ground1._p._v variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 basicPV1._voltageSensor1._n._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  data->localData[0]->realVars[21] /* basicPV1._voltageSensor1._n._i variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 basicPV1._voltageSensor1._p._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[22] /* basicPV1._voltageSensor1._p._i variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Eg = 1.1
 */
void PhotoVoltaicTest_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[1] /* basicPV1._pVDiode1._Eg variable */ = 1.1;
  TRACE_POP
}

/*
 equation index: 5
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._a = 1.5
 */
void PhotoVoltaicTest_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  data->localData[0]->realVars[7] /* basicPV1._pVDiode1._a variable */ = 1.5;
  TRACE_POP
}

/*
 equation index: 6
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._q = 1.062e-19
 */
void PhotoVoltaicTest_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[9] /* basicPV1._pVDiode1._q variable */ = 1.062e-19;
  TRACE_POP
}

/*
 equation index: 7
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._K = 1.38065e-23
 */
void PhotoVoltaicTest_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  data->localData[0]->realVars[4] /* basicPV1._pVDiode1._K variable */ = 1.38065e-23;
  TRACE_POP
}

/*
 equation index: 8
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._Gn = 1000.0
 */
void PhotoVoltaicTest_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  data->localData[0]->realVars[16] /* basicPV1._signalPhotoVoltaicCurrent1._Gn variable */ = 1000.0;
  TRACE_POP
}

/*
 equation index: 9
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._Ki = 0.0032
 */
void PhotoVoltaicTest_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  data->localData[0]->realVars[17] /* basicPV1._signalPhotoVoltaicCurrent1._Ki variable */ = 0.0032;
  TRACE_POP
}

/*
 equation index: 10
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._i = 0.001 * (basicPV1.signalPhotoVoltaicCurrent1.Isc + 0.0032 * (basicPV1.signalPhotoVoltaicCurrent1.To - basicPV1.signalPhotoVoltaicCurrent1.Tref)) * basicPV1.signalPhotoVoltaicCurrent1.G
 */
void PhotoVoltaicTest_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */ = (0.001) * ((data->simulationInfo->realParameter[17] + (0.0032) * (data->simulationInfo->realParameter[19] - data->simulationInfo->realParameter[20])) * (data->simulationInfo->realParameter[16]));
  TRACE_POP
}

/*
 equation index: 11
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._R_actual = basicPV1.resistor3.R * (1.0 + basicPV1.resistor3.alpha * (basicPV1.resistor3.T - basicPV1.resistor3.T_ref))
 */
void PhotoVoltaicTest_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */ = (data->simulationInfo->realParameter[12]) * (1.0 + (data->simulationInfo->realParameter[15]) * (data->simulationInfo->realParameter[13] - data->simulationInfo->realParameter[14]));
  TRACE_POP
}

/*
 equation index: 12
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._R_s = basicPV1.resistor2.R * (1.0 + basicPV1.resistor2.alpha * (basicPV1.resistor2.T - basicPV1.resistor2.T_ref))
 */
void PhotoVoltaicTest_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */ = (data->simulationInfo->realParameter[8]) * (1.0 + (data->simulationInfo->realParameter[11]) * (data->simulationInfo->realParameter[9] - data->simulationInfo->realParameter[10]));
  TRACE_POP
}

/*
 equation index: 13
 type: SIMPLE_ASSIGN
 bulb1._resistor1._R_actual = bulb1.resistor1.R * (1.0 + bulb1.resistor1.alpha * (bulb1.resistor1.T - bulb1.resistor1.T_ref))
 */
void PhotoVoltaicTest_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */ = (data->simulationInfo->realParameter[21]) * (1.0 + (data->simulationInfo->realParameter[24]) * (data->simulationInfo->realParameter[22] - data->simulationInfo->realParameter[23]));
  TRACE_POP
}

/*
 equation index: 14
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Ion = DIVISION(basicPV1.pVDiode1.Isc, -1.0 + exp(1.062e-19 * DIVISION(basicPV1.pVDiode1.V_oc, 2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns)))
 */
void PhotoVoltaicTest_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  data->localData[0]->realVars[3] /* basicPV1._pVDiode1._Ion variable */ = DIVISION_SIM(data->simulationInfo->realParameter[0],-1.0 + exp((1.062e-19) * (DIVISION_SIM(data->simulationInfo->realParameter[7],((2.070975e-23) * (data->simulationInfo->realParameter[6])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns",equationIndexes))),"-1.0 + exp(1.062e-19 * DIVISION(basicPV1.pVDiode1.V_oc, 2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns))",equationIndexes);
  TRACE_POP
}

/*
 equation index: 15
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Ids = basicPV1.pVDiode1.Ion * DIVISION(basicPV1.pVDiode1.To, basicPV1.pVDiode1.Tn) ^ 3.0 * exp(1.1682e-19 * (DIVISION(1.0, basicPV1.pVDiode1.Tn * 2.070975e-23) + DIVISION(-1.0, basicPV1.pVDiode1.To * 2.070975e-23)))
 */
void PhotoVoltaicTest_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(data->simulationInfo->realParameter[6],data->simulationInfo->realParameter[5],"basicPV1.pVDiode1.Tn",equationIndexes);
  data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */ = (data->localData[0]->realVars[3] /* basicPV1._pVDiode1._Ion variable */) * (((tmp0 * tmp0 * tmp0)) * (exp((1.1682e-19) * (DIVISION_SIM(1.0,(data->simulationInfo->realParameter[5]) * (2.070975e-23),"basicPV1.pVDiode1.Tn * 2.070975e-23",equationIndexes) + DIVISION_SIM(-1.0,(data->simulationInfo->realParameter[6]) * (2.070975e-23),"basicPV1.pVDiode1.To * 2.070975e-23",equationIndexes)))));
  TRACE_POP
}

void PhotoVoltaicTest_eqFunction_16(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_17(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_18(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_19(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_20(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_21(DATA*,threadData_t*);
void PhotoVoltaicTest_eqFunction_22(DATA*,threadData_t*);
/*
 equation index: 30
 indexNonlinear: 0
 type: NONLINEAR
 
 vars: {bulb1._I}
 eqns: {16, 17, 18, 19, 20, 21, 22}
 */
void PhotoVoltaicTest_eqFunction_30(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,30};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 30 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = data->localData[0]->realVars[23] /* bulb1._I variable */;
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,30};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 30 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[23] /* bulb1._I variable */ = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  TRACE_POP
}

/*
 equation index: 31
 type: SIMPLE_ASSIGN
 bulb1._P = bulb1.V * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_31(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,31};
  data->localData[0]->realVars[24] /* bulb1._P variable */ = (data->localData[0]->realVars[25] /* bulb1._V variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}

/*
 equation index: 32
 type: SIMPLE_ASSIGN
 bulb1._resistor1._LossPower = bulb1.V * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  data->localData[0]->realVars[26] /* bulb1._resistor1._LossPower variable */ = (data->localData[0]->realVars[25] /* bulb1._V variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}

/*
 equation index: 33
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._LossPower = basicPV1.signalPhotoVoltaicCurrent1.v * basicPV1.resistor3.i
 */
void PhotoVoltaicTest_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  data->localData[0]->realVars[13] /* basicPV1._resistor3._LossPower variable */ = (data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */) * (data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */);
  TRACE_POP
}

/*
 equation index: 34
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._LossPower = (-basicPV1.signalPhotoVoltaicCurrent1.v) * basicPV1.pVDiode1.i
 */
void PhotoVoltaicTest_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  data->localData[0]->realVars[5] /* basicPV1._pVDiode1._LossPower variable */ = ((-data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */)) * (data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */);
  TRACE_POP
}

/*
 equation index: 35
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._LossPower = basicPV1.signalPhotoVoltaicCurrent1.v * basicPV1.signalPhotoVoltaicCurrent1.i
 */
void PhotoVoltaicTest_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  data->localData[0]->realVars[18] /* basicPV1._signalPhotoVoltaicCurrent1._LossPower variable */ = (data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */) * (data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */);
  TRACE_POP
}

/*
 equation index: 36
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._LossPower = (-basicPV1.resistor2.v) * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  data->localData[0]->realVars[11] /* basicPV1._resistor2._LossPower variable */ = ((-data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */)) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}

/*
 equation index: 37
 type: SIMPLE_ASSIGN
 ground1._p._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  data->localData[0]->realVars[28] /* ground1._p._i variable */ = 0.0;
  TRACE_POP
}
void PhotoVoltaicTest_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  PhotoVoltaicTest_eqFunction_1(data, threadData);
  PhotoVoltaicTest_eqFunction_2(data, threadData);
  PhotoVoltaicTest_eqFunction_3(data, threadData);
  PhotoVoltaicTest_eqFunction_4(data, threadData);
  PhotoVoltaicTest_eqFunction_5(data, threadData);
  PhotoVoltaicTest_eqFunction_6(data, threadData);
  PhotoVoltaicTest_eqFunction_7(data, threadData);
  PhotoVoltaicTest_eqFunction_8(data, threadData);
  PhotoVoltaicTest_eqFunction_9(data, threadData);
  PhotoVoltaicTest_eqFunction_10(data, threadData);
  PhotoVoltaicTest_eqFunction_11(data, threadData);
  PhotoVoltaicTest_eqFunction_12(data, threadData);
  PhotoVoltaicTest_eqFunction_13(data, threadData);
  PhotoVoltaicTest_eqFunction_14(data, threadData);
  PhotoVoltaicTest_eqFunction_15(data, threadData);
  PhotoVoltaicTest_eqFunction_30(data, threadData);
  PhotoVoltaicTest_eqFunction_31(data, threadData);
  PhotoVoltaicTest_eqFunction_32(data, threadData);
  PhotoVoltaicTest_eqFunction_33(data, threadData);
  PhotoVoltaicTest_eqFunction_34(data, threadData);
  PhotoVoltaicTest_eqFunction_35(data, threadData);
  PhotoVoltaicTest_eqFunction_36(data, threadData);
  PhotoVoltaicTest_eqFunction_37(data, threadData);
  TRACE_POP
}


int PhotoVoltaicTest_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  PhotoVoltaicTest_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int PhotoVoltaicTest_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

