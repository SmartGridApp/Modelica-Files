/* Inline equation file is empty */
#include "PhotoVoltaicTest_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int PhotoVoltaicTest_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
