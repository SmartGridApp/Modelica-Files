/* Non Linear Systems */
#include "PhotoVoltaicTest_model.h"
#include "PhotoVoltaicTest_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

/*
 equation index: 16
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._v = (-basicPV1.pVDiode1.R_s) * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */ = ((-data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 17
 type: SIMPLE_ASSIGN
 bulb1._V = bulb1.resistor1.R_actual * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_17(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,17};
  data->localData[0]->realVars[25] /* bulb1._V variable */ = (data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 18
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._i = basicPV1.pVDiode1.Ids * (-1.0 + exp(1.062e-19 * DIVISION(bulb1.V + bulb1.I * basicPV1.pVDiode1.R_s, 2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns)))
 */
void PhotoVoltaicTest_eqFunction_18(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,18};
  data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */ = (data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */) * (-1.0 + exp((1.062e-19) * (DIVISION_SIM(data->localData[0]->realVars[25] /* bulb1._V variable */ + (data->localData[0]->realVars[23] /* bulb1._I variable */) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */),((2.070975e-23) * (data->simulationInfo->realParameter[5])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns",equationIndexes))));
  TRACE_POP
}
/*
 equation index: 19
 type: SIMPLE_ASSIGN
 basicPV1._pin_n._i = bulb1.I
 */
void PhotoVoltaicTest_eqFunction_19(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,19};
  data->localData[0]->realVars[10] /* basicPV1._pin_n._i variable */ = data->localData[0]->realVars[23] /* bulb1._I variable */;
  TRACE_POP
}
/*
 equation index: 20
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._i = basicPV1.pVDiode1.i - (basicPV1.signalPhotoVoltaicCurrent1.i - basicPV1.pin_n.i)
 */
void PhotoVoltaicTest_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */ = data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */ - (data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */ - data->localData[0]->realVars[10] /* basicPV1._pin_n._i variable */);
  TRACE_POP
}
/*
 equation index: 21
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._v = basicPV1.resistor3.R_actual * basicPV1.resistor3.i
 */
void PhotoVoltaicTest_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */ = (data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */) * (data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */);
  TRACE_POP
}

void residualFunc30(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,30};
  /* iteration variables */
  data->localData[0]->realVars[23] /* bulb1._I variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  PhotoVoltaicTest_eqFunction_16(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_17(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_18(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_19(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_20(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_21(data, threadData);
  /* body */
  res[0] = data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */ + data->localData[0]->realVars[25] /* bulb1._V variable */ - data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */;
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS30(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 1;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.maxColors = 1;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[0] = 1;
}
void initializeStaticDataNLS30(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for bulb1.I */
  sysData->nominal[i] = data->modelData->realVarsData[23].attribute /* bulb1._I */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[23].attribute /* bulb1._I */.min;
  sysData->max[i++]   = data->modelData->realVarsData[23].attribute /* bulb1._I */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS30(sysData);
}

void getIterationVarsNLS30(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[23] /* bulb1._I variable */;
}

/* inner equations */

/*
 equation index: 39
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._v = (-basicPV1.pVDiode1.R_s) * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */ = ((-data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */)) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 40
 type: SIMPLE_ASSIGN
 bulb1._V = bulb1.resistor1.R_actual * bulb1.I
 */
void PhotoVoltaicTest_eqFunction_40(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,40};
  data->localData[0]->realVars[25] /* bulb1._V variable */ = (data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */) * (data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 41
 type: SIMPLE_ASSIGN
 $cse2 = exp(1.062e-19 * DIVISION(bulb1.V + bulb1.I * basicPV1.pVDiode1.R_s, 2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns))
 */
void PhotoVoltaicTest_eqFunction_41(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,41};
  data->localData[0]->realVars[0] /* $cse2 variable */ = exp((1.062e-19) * (DIVISION_SIM(data->localData[0]->realVars[25] /* bulb1._V variable */ + (data->localData[0]->realVars[23] /* bulb1._I variable */) * (data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */),((2.070975e-23) * (data->simulationInfo->realParameter[5])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.Tn * basicPV1.pVDiode1.Ns",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 42
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._i = basicPV1.pVDiode1.Ids * (-1.0 + $cse2)
 */
void PhotoVoltaicTest_eqFunction_42(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,42};
  data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */ = (data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */) * (-1.0 + data->localData[0]->realVars[0] /* $cse2 variable */);
  TRACE_POP
}
/*
 equation index: 43
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._i = basicPV1.pVDiode1.i - (basicPV1.signalPhotoVoltaicCurrent1.i - bulb1.I)
 */
void PhotoVoltaicTest_eqFunction_43(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,43};
  data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */ = data->localData[0]->realVars[8] /* basicPV1._pVDiode1._i variable */ - (data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */ - data->localData[0]->realVars[23] /* bulb1._I variable */);
  TRACE_POP
}
/*
 equation index: 44
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._v = basicPV1.resistor3.R_actual * basicPV1.resistor3.i
 */
void PhotoVoltaicTest_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */ = (data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */) * (data->localData[0]->realVars[15] /* basicPV1._resistor3._i variable */);
  TRACE_POP
}

void residualFunc54(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,54};
  /* iteration variables */
  data->localData[0]->realVars[23] /* bulb1._I variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  PhotoVoltaicTest_eqFunction_39(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_40(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_41(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_42(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_43(data, threadData);

  /* local constraints */
  PhotoVoltaicTest_eqFunction_44(data, threadData);
  /* body */
  res[0] = data->localData[0]->realVars[20] /* basicPV1._signalPhotoVoltaicCurrent1._v variable */ + data->localData[0]->realVars[25] /* bulb1._V variable */ - data->localData[0]->realVars[12] /* basicPV1._resistor2._v variable */;
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS54(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 1;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.maxColors = 1;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[0] = 1;
}
void initializeStaticDataNLS54(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for bulb1.I */
  sysData->nominal[i] = data->modelData->realVarsData[23].attribute /* bulb1._I */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[23].attribute /* bulb1._I */.min;
  sysData->max[i++]   = data->modelData->realVarsData[23].attribute /* bulb1._I */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS54(sysData);
}

void getIterationVarsNLS54(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[23] /* bulb1._I variable */;
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void PhotoVoltaicTest_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[0].equationIndex = 30;
  nonLinearSystemData[0].size = 1;
  nonLinearSystemData[0].homotopySupport = 0;
  nonLinearSystemData[0].mixedSystem = 0;
  nonLinearSystemData[0].residualFunc = residualFunc30;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = PhotoVoltaicTest_functionJacNLSJac0_column;
  nonLinearSystemData[0].initialAnalyticalJacobian = PhotoVoltaicTest_initialAnalyticJacobianNLSJac0;
  nonLinearSystemData[0].jacobianIndex = 0;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS30;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS30;
  nonLinearSystemData[0].checkConstraints = NULL;
  
  nonLinearSystemData[1].equationIndex = 54;
  nonLinearSystemData[1].size = 1;
  nonLinearSystemData[1].homotopySupport = 0;
  nonLinearSystemData[1].mixedSystem = 0;
  nonLinearSystemData[1].residualFunc = residualFunc54;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = PhotoVoltaicTest_functionJacNLSJac1_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = PhotoVoltaicTest_initialAnalyticJacobianNLSJac1;
  nonLinearSystemData[1].jacobianIndex = 1;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS54;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS54;
  nonLinearSystemData[1].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

