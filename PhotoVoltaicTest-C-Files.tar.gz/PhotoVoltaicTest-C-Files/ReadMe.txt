All the files in this directory corresponds to PhotoVoltaicTest.mo

Please make the current directory "PhotoVoltaicTest-C-Files" and 
type the following command to compile the program:

	make -f PhotoVoltaicTest.makefile

Please type the following to run the program.

	./PhotoVoltaicTest


################################################################################
(Note: While working with the .mo files in modelica please load the
Buildings library [not added in https://github.com/SmartGridApp/Modelica-Files)]
and all the .mo files present in https://github.com/SmartGridApp/Modelica-Files)
################################################################################
