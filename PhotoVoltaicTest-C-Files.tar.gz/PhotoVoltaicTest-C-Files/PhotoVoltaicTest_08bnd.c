/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "PhotoVoltaicTest_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int PhotoVoltaicTest_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}


/*
 equation index: 65
 type: SIMPLE_ASSIGN
 bulb1._resistor1._T = bulb1.resistor1.T_ref
 */
void PhotoVoltaicTest_eqFunction_65(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,65};
  data->simulationInfo->realParameter[22] = data->simulationInfo->realParameter[23];
  TRACE_POP
}

/*
 equation index: 66
 type: SIMPLE_ASSIGN
 bulb1._resistor1._useHeatPort = false
 */
void PhotoVoltaicTest_eqFunction_66(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,66};
  data->simulationInfo->booleanParameter[4] = 0;
  TRACE_POP
}

/*
 equation index: 67
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._T = basicPV1.resistor2.T_ref
 */
void PhotoVoltaicTest_eqFunction_67(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,67};
  data->simulationInfo->realParameter[9] = data->simulationInfo->realParameter[10];
  TRACE_POP
}

/*
 equation index: 68
 type: SIMPLE_ASSIGN
 basicPV1._resistor2._useHeatPort = false
 */
void PhotoVoltaicTest_eqFunction_68(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,68};
  data->simulationInfo->booleanParameter[1] = 0;
  TRACE_POP
}

/*
 equation index: 69
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._T = basicPV1.resistor3.T_ref
 */
void PhotoVoltaicTest_eqFunction_69(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,69};
  data->simulationInfo->realParameter[13] = data->simulationInfo->realParameter[14];
  TRACE_POP
}

/*
 equation index: 70
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._useHeatPort = false
 */
void PhotoVoltaicTest_eqFunction_70(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,70};
  data->simulationInfo->booleanParameter[2] = 0;
  TRACE_POP
}

/*
 equation index: 71
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._useHeatPort = false
 */
void PhotoVoltaicTest_eqFunction_71(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,71};
  data->simulationInfo->booleanParameter[0] = 0;
  TRACE_POP
}

/*
 equation index: 72
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._useHeatPort = false
 */
void PhotoVoltaicTest_eqFunction_72(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,72};
  data->simulationInfo->booleanParameter[3] = 0;
  TRACE_POP
}

/*
 equation index: 73
 type: SIMPLE_ASSIGN
 ground1._p._v = 0.0
 */
void PhotoVoltaicTest_eqFunction_73(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,73};
  data->localData[0]->realVars[29] /* ground1._p._v variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 74
 type: SIMPLE_ASSIGN
 basicPV1._voltageSensor1._n._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_74(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,74};
  data->localData[0]->realVars[21] /* basicPV1._voltageSensor1._n._i variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 75
 type: SIMPLE_ASSIGN
 basicPV1._voltageSensor1._p._i = 0.0
 */
void PhotoVoltaicTest_eqFunction_75(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,75};
  data->localData[0]->realVars[22] /* basicPV1._voltageSensor1._p._i variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 76
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Eg = 1.1
 */
void PhotoVoltaicTest_eqFunction_76(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,76};
  data->localData[0]->realVars[1] /* basicPV1._pVDiode1._Eg variable */ = 1.1;
  TRACE_POP
}

/*
 equation index: 77
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._a = 1.5
 */
void PhotoVoltaicTest_eqFunction_77(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,77};
  data->localData[0]->realVars[7] /* basicPV1._pVDiode1._a variable */ = 1.5;
  TRACE_POP
}

/*
 equation index: 78
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._q = 1.062e-19
 */
void PhotoVoltaicTest_eqFunction_78(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,78};
  data->localData[0]->realVars[9] /* basicPV1._pVDiode1._q variable */ = 1.062e-19;
  TRACE_POP
}

/*
 equation index: 79
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._K = 1.38065e-23
 */
void PhotoVoltaicTest_eqFunction_79(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,79};
  data->localData[0]->realVars[4] /* basicPV1._pVDiode1._K variable */ = 1.38065e-23;
  TRACE_POP
}

/*
 equation index: 80
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._Gn = 1000.0
 */
void PhotoVoltaicTest_eqFunction_80(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,80};
  data->localData[0]->realVars[16] /* basicPV1._signalPhotoVoltaicCurrent1._Gn variable */ = 1000.0;
  TRACE_POP
}

/*
 equation index: 81
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._Ki = 0.0032
 */
void PhotoVoltaicTest_eqFunction_81(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,81};
  data->localData[0]->realVars[17] /* basicPV1._signalPhotoVoltaicCurrent1._Ki variable */ = 0.0032;
  TRACE_POP
}

/*
 equation index: 82
 type: SIMPLE_ASSIGN
 basicPV1._signalPhotoVoltaicCurrent1._i = 0.001 * (basicPV1.signalPhotoVoltaicCurrent1.Isc + 0.0032 * (basicPV1.signalPhotoVoltaicCurrent1.To - basicPV1.signalPhotoVoltaicCurrent1.Tref)) * basicPV1.signalPhotoVoltaicCurrent1.G
 */
void PhotoVoltaicTest_eqFunction_82(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,82};
  data->localData[0]->realVars[19] /* basicPV1._signalPhotoVoltaicCurrent1._i variable */ = (0.001) * ((data->simulationInfo->realParameter[17] + (0.0032) * (data->simulationInfo->realParameter[19] - data->simulationInfo->realParameter[20])) * (data->simulationInfo->realParameter[16]));
  TRACE_POP
}

/*
 equation index: 83
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Ion = DIVISION(basicPV1.pVDiode1.Isc, -1.0 + exp(1.062e-19 * DIVISION(basicPV1.pVDiode1.V_oc, 2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns)))
 */
void PhotoVoltaicTest_eqFunction_83(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,83};
  data->localData[0]->realVars[3] /* basicPV1._pVDiode1._Ion variable */ = DIVISION_SIM(data->simulationInfo->realParameter[0],-1.0 + exp((1.062e-19) * (DIVISION_SIM(data->simulationInfo->realParameter[7],((2.070975e-23) * (data->simulationInfo->realParameter[6])) * (data->simulationInfo->realParameter[2]),"2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns",equationIndexes))),"-1.0 + exp(1.062e-19 * DIVISION(basicPV1.pVDiode1.V_oc, 2.070975e-23 * basicPV1.pVDiode1.To * basicPV1.pVDiode1.Ns))",equationIndexes);
  TRACE_POP
}

/*
 equation index: 84
 type: SIMPLE_ASSIGN
 basicPV1._resistor3._R_actual = basicPV1.resistor3.R * (1.0 + basicPV1.resistor3.alpha * (basicPV1.resistor3.T - basicPV1.resistor3.T_ref))
 */
void PhotoVoltaicTest_eqFunction_84(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,84};
  data->localData[0]->realVars[14] /* basicPV1._resistor3._R_actual variable */ = (data->simulationInfo->realParameter[12]) * (1.0 + (data->simulationInfo->realParameter[15]) * (data->simulationInfo->realParameter[13] - data->simulationInfo->realParameter[14]));
  TRACE_POP
}

/*
 equation index: 85
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._R_s = basicPV1.resistor2.R * (1.0 + basicPV1.resistor2.alpha * (basicPV1.resistor2.T - basicPV1.resistor2.T_ref))
 */
void PhotoVoltaicTest_eqFunction_85(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,85};
  data->localData[0]->realVars[6] /* basicPV1._pVDiode1._R_s variable */ = (data->simulationInfo->realParameter[8]) * (1.0 + (data->simulationInfo->realParameter[11]) * (data->simulationInfo->realParameter[9] - data->simulationInfo->realParameter[10]));
  TRACE_POP
}

/*
 equation index: 86
 type: SIMPLE_ASSIGN
 bulb1._resistor1._R_actual = bulb1.resistor1.R * (1.0 + bulb1.resistor1.alpha * (bulb1.resistor1.T - bulb1.resistor1.T_ref))
 */
void PhotoVoltaicTest_eqFunction_86(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,86};
  data->localData[0]->realVars[27] /* bulb1._resistor1._R_actual variable */ = (data->simulationInfo->realParameter[21]) * (1.0 + (data->simulationInfo->realParameter[24]) * (data->simulationInfo->realParameter[22] - data->simulationInfo->realParameter[23]));
  TRACE_POP
}

/*
 equation index: 87
 type: SIMPLE_ASSIGN
 basicPV1._pVDiode1._Ids = basicPV1.pVDiode1.Ion * DIVISION(basicPV1.pVDiode1.To, basicPV1.pVDiode1.Tn) ^ 3.0 * exp(1.1682e-19 * (DIVISION(1.0, basicPV1.pVDiode1.Tn * 2.070975e-23) + DIVISION(-1.0, basicPV1.pVDiode1.To * 2.070975e-23)))
 */
void PhotoVoltaicTest_eqFunction_87(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,87};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(data->simulationInfo->realParameter[6],data->simulationInfo->realParameter[5],"basicPV1.pVDiode1.Tn",equationIndexes);
  data->localData[0]->realVars[2] /* basicPV1._pVDiode1._Ids variable */ = (data->localData[0]->realVars[3] /* basicPV1._pVDiode1._Ion variable */) * (((tmp0 * tmp0 * tmp0)) * (exp((1.1682e-19) * (DIVISION_SIM(1.0,(data->simulationInfo->realParameter[5]) * (2.070975e-23),"basicPV1.pVDiode1.Tn * 2.070975e-23",equationIndexes) + DIVISION_SIM(-1.0,(data->simulationInfo->realParameter[6]) * (2.070975e-23),"basicPV1.pVDiode1.To * 2.070975e-23",equationIndexes)))));
  TRACE_POP
}

/*
 equation index: 88
 type: ALGORITHM
 
   assert(bulb1.resistor1.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= bulb1.resistor1.T_ref, has value: " + String(bulb1.resistor1.T_ref, "g"));
 */
void PhotoVoltaicTest_eqFunction_88(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,88};
  modelica_boolean tmp1;
  static const MMC_DEFSTRINGLIT(tmp2,76,"Variable violating min constraint: 0.0 <= bulb1.resistor1.T_ref, has value: ");
  modelica_string tmp3;
  static int tmp4 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp4)
  {
    tmp1 = GreaterEq(data->simulationInfo->realParameter[23],0.0);
    if(!tmp1)
    {
      tmp3 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[23], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp2),tmp3);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Basic.mo",56,5,56,66,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbulb1.resistor1.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp4 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 89
 type: ALGORITHM
 
   assert(bulb1.resistor1.T >= 0.0, "Variable violating min constraint: 0.0 <= bulb1.resistor1.T, has value: " + String(bulb1.resistor1.T, "g"));
 */
void PhotoVoltaicTest_eqFunction_89(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,89};
  modelica_boolean tmp5;
  static const MMC_DEFSTRINGLIT(tmp6,72,"Variable violating min constraint: 0.0 <= bulb1.resistor1.T, has value: ");
  modelica_string tmp7;
  static int tmp8 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp8)
  {
    tmp5 = GreaterEq(data->simulationInfo->realParameter[22],0.0);
    if(!tmp5)
    {
      tmp7 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[22], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp6),tmp7);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbulb1.resistor1.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp8 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 90
 type: ALGORITHM
 
   assert(basicPV1.resistor2.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.resistor2.T_ref, has value: " + String(basicPV1.resistor2.T_ref, "g"));
 */
void PhotoVoltaicTest_eqFunction_90(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,90};
  modelica_boolean tmp9;
  static const MMC_DEFSTRINGLIT(tmp10,79,"Variable violating min constraint: 0.0 <= basicPV1.resistor2.T_ref, has value: ");
  modelica_string tmp11;
  static int tmp12 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp12)
  {
    tmp9 = GreaterEq(data->simulationInfo->realParameter[10],0.0);
    if(!tmp9)
    {
      tmp11 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[10], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp10),tmp11);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",204,5,204,82,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.resistor2.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp12 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 91
 type: ALGORITHM
 
   assert(basicPV1.resistor2.T >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.resistor2.T, has value: " + String(basicPV1.resistor2.T, "g"));
 */
void PhotoVoltaicTest_eqFunction_91(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,91};
  modelica_boolean tmp13;
  static const MMC_DEFSTRINGLIT(tmp14,75,"Variable violating min constraint: 0.0 <= basicPV1.resistor2.T, has value: ");
  modelica_string tmp15;
  static int tmp16 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp16)
  {
    tmp13 = GreaterEq(data->simulationInfo->realParameter[9],0.0);
    if(!tmp13)
    {
      tmp15 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[9], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp14),tmp15);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.resistor2.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp16 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 92
 type: ALGORITHM
 
   assert(basicPV1.resistor3.T_ref >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.resistor3.T_ref, has value: " + String(basicPV1.resistor3.T_ref, "g"));
 */
void PhotoVoltaicTest_eqFunction_92(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,92};
  modelica_boolean tmp17;
  static const MMC_DEFSTRINGLIT(tmp18,79,"Variable violating min constraint: 0.0 <= basicPV1.resistor3.T_ref, has value: ");
  modelica_string tmp19;
  static int tmp20 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp20)
  {
    tmp17 = GreaterEq(data->simulationInfo->realParameter[14],0.0);
    if(!tmp17)
    {
      tmp19 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[14], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp18),tmp19);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Basic.mo",56,5,56,66,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.resistor3.T_ref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp20 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 93
 type: ALGORITHM
 
   assert(basicPV1.resistor3.T >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.resistor3.T, has value: " + String(basicPV1.resistor3.T, "g"));
 */
void PhotoVoltaicTest_eqFunction_93(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,93};
  modelica_boolean tmp21;
  static const MMC_DEFSTRINGLIT(tmp22,75,"Variable violating min constraint: 0.0 <= basicPV1.resistor3.T, has value: ");
  modelica_string tmp23;
  static int tmp24 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp24)
  {
    tmp21 = GreaterEq(data->simulationInfo->realParameter[13],0.0);
    if(!tmp21)
    {
      tmp23 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[13], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp22),tmp23);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.resistor3.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp24 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 94
 type: ALGORITHM
 
   assert(basicPV1.pVDiode1.To >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.To, has value: " + String(basicPV1.pVDiode1.To, "g"));
 */
void PhotoVoltaicTest_eqFunction_94(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,94};
  modelica_boolean tmp25;
  static const MMC_DEFSTRINGLIT(tmp26,75,"Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.To, has value: ");
  modelica_string tmp27;
  static int tmp28 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp28)
  {
    tmp25 = GreaterEq(data->simulationInfo->realParameter[6],0.0);
    if(!tmp25)
    {
      tmp27 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[6], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp26),tmp27);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",26,3,26,78,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.pVDiode1.To >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp28 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 95
 type: ALGORITHM
 
   assert(basicPV1.pVDiode1.Tn >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.Tn, has value: " + String(basicPV1.pVDiode1.Tn, "g"));
 */
void PhotoVoltaicTest_eqFunction_95(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,95};
  modelica_boolean tmp29;
  static const MMC_DEFSTRINGLIT(tmp30,75,"Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.Tn, has value: ");
  modelica_string tmp31;
  static int tmp32 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp32)
  {
    tmp29 = GreaterEq(data->simulationInfo->realParameter[5],0.0);
    if(!tmp29)
    {
      tmp31 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[5], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp30),tmp31);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",25,3,25,81,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.pVDiode1.Tn >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp32 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 96
 type: ALGORITHM
 
   assert(basicPV1.pVDiode1.Maxexp >= 1e-60, "Variable violating min constraint: 1e-60 <= basicPV1.pVDiode1.Maxexp, has value: " + String(basicPV1.pVDiode1.Maxexp, "g"));
 */
void PhotoVoltaicTest_eqFunction_96(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,96};
  modelica_boolean tmp33;
  static const MMC_DEFSTRINGLIT(tmp34,81,"Variable violating min constraint: 1e-60 <= basicPV1.pVDiode1.Maxexp, has value: ");
  modelica_string tmp35;
  static int tmp36 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp36)
  {
    tmp33 = GreaterEq(data->simulationInfo->realParameter[1],1e-60);
    if(!tmp33)
    {
      tmp35 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[1], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp34),tmp35);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",22,3,22,107,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.pVDiode1.Maxexp >= 1e-60", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp36 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 97
 type: ALGORITHM
 
   assert(basicPV1.pVDiode1.T >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.T, has value: " + String(basicPV1.pVDiode1.T, "g"));
 */
void PhotoVoltaicTest_eqFunction_97(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,97};
  modelica_boolean tmp37;
  static const MMC_DEFSTRINGLIT(tmp38,74,"Variable violating min constraint: 0.0 <= basicPV1.pVDiode1.T, has value: ");
  modelica_string tmp39;
  static int tmp40 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp40)
  {
    tmp37 = GreaterEq(data->simulationInfo->realParameter[4],0.0);
    if(!tmp37)
    {
      tmp39 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[4], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp38),tmp39);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.pVDiode1.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp40 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 98
 type: ALGORITHM
 
   assert(basicPV1.signalPhotoVoltaicCurrent1.Tref >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.Tref, has value: " + String(basicPV1.signalPhotoVoltaicCurrent1.Tref, "g"));
 */
void PhotoVoltaicTest_eqFunction_98(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,98};
  modelica_boolean tmp41;
  static const MMC_DEFSTRINGLIT(tmp42,95,"Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.Tref, has value: ");
  modelica_string tmp43;
  static int tmp44 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp44)
  {
    tmp41 = GreaterEq(data->simulationInfo->realParameter[20],0.0);
    if(!tmp41)
    {
      tmp43 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[20], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp42),tmp43);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",175,3,175,80,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.signalPhotoVoltaicCurrent1.Tref >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp44 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 99
 type: ALGORITHM
 
   assert(basicPV1.signalPhotoVoltaicCurrent1.To >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.To, has value: " + String(basicPV1.signalPhotoVoltaicCurrent1.To, "g"));
 */
void PhotoVoltaicTest_eqFunction_99(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,99};
  modelica_boolean tmp45;
  static const MMC_DEFSTRINGLIT(tmp46,93,"Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.To, has value: ");
  modelica_string tmp47;
  static int tmp48 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp48)
  {
    tmp45 = GreaterEq(data->simulationInfo->realParameter[19],0.0);
    if(!tmp45)
    {
      tmp47 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[19], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp46),tmp47);
      {
        FILE_INFO info = {"/home/bhaskar/Modelica/Modelica-Files/PVCell.mo",174,3,174,79,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.signalPhotoVoltaicCurrent1.To >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp48 = 1;
    }
  }
  TRACE_POP
}

/*
 equation index: 100
 type: ALGORITHM
 
   assert(basicPV1.signalPhotoVoltaicCurrent1.T >= 0.0, "Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.T, has value: " + String(basicPV1.signalPhotoVoltaicCurrent1.T, "g"));
 */
void PhotoVoltaicTest_eqFunction_100(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,100};
  modelica_boolean tmp49;
  static const MMC_DEFSTRINGLIT(tmp50,92,"Variable violating min constraint: 0.0 <= basicPV1.signalPhotoVoltaicCurrent1.T, has value: ");
  modelica_string tmp51;
  static int tmp52 = 0;
  modelica_metatype tmpMeta[1] __attribute__((unused)) = {0};
  if(!tmp52)
  {
    tmp49 = GreaterEq(data->simulationInfo->realParameter[18],0.0);
    if(!tmp49)
    {
      tmp51 = modelica_real_to_modelica_string_format(data->simulationInfo->realParameter[18], (modelica_string) mmc_strings_len1[103]);
      tmpMeta[0] = stringAppend(MMC_REFSTRINGLIT(tmp50),tmp51);
      {
        FILE_INFO info = {"/usr/lib/omlibrary/Modelica 3.2.2/Electrical/Analog/Interfaces.mo",309,5,310,99,1};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f\nbasicPV1.signalPhotoVoltaicCurrent1.T >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta[0]));
      }
      tmp52 = 1;
    }
  }
  TRACE_POP
}
int PhotoVoltaicTest_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  PhotoVoltaicTest_eqFunction_65(data, threadData);

  PhotoVoltaicTest_eqFunction_66(data, threadData);

  PhotoVoltaicTest_eqFunction_67(data, threadData);

  PhotoVoltaicTest_eqFunction_68(data, threadData);

  PhotoVoltaicTest_eqFunction_69(data, threadData);

  PhotoVoltaicTest_eqFunction_70(data, threadData);

  PhotoVoltaicTest_eqFunction_71(data, threadData);

  PhotoVoltaicTest_eqFunction_72(data, threadData);

  PhotoVoltaicTest_eqFunction_73(data, threadData);

  PhotoVoltaicTest_eqFunction_74(data, threadData);

  PhotoVoltaicTest_eqFunction_75(data, threadData);

  PhotoVoltaicTest_eqFunction_76(data, threadData);

  PhotoVoltaicTest_eqFunction_77(data, threadData);

  PhotoVoltaicTest_eqFunction_78(data, threadData);

  PhotoVoltaicTest_eqFunction_79(data, threadData);

  PhotoVoltaicTest_eqFunction_80(data, threadData);

  PhotoVoltaicTest_eqFunction_81(data, threadData);

  PhotoVoltaicTest_eqFunction_82(data, threadData);

  PhotoVoltaicTest_eqFunction_83(data, threadData);

  PhotoVoltaicTest_eqFunction_84(data, threadData);

  PhotoVoltaicTest_eqFunction_85(data, threadData);

  PhotoVoltaicTest_eqFunction_86(data, threadData);

  PhotoVoltaicTest_eqFunction_87(data, threadData);

  PhotoVoltaicTest_eqFunction_88(data, threadData);

  PhotoVoltaicTest_eqFunction_89(data, threadData);

  PhotoVoltaicTest_eqFunction_90(data, threadData);

  PhotoVoltaicTest_eqFunction_91(data, threadData);

  PhotoVoltaicTest_eqFunction_92(data, threadData);

  PhotoVoltaicTest_eqFunction_93(data, threadData);

  PhotoVoltaicTest_eqFunction_94(data, threadData);

  PhotoVoltaicTest_eqFunction_95(data, threadData);

  PhotoVoltaicTest_eqFunction_96(data, threadData);

  PhotoVoltaicTest_eqFunction_97(data, threadData);

  PhotoVoltaicTest_eqFunction_98(data, threadData);

  PhotoVoltaicTest_eqFunction_99(data, threadData);

  PhotoVoltaicTest_eqFunction_100(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

